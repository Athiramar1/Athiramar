// ... existing code ...

// In the table where you display products, add an Edit button in the Actions column
echo "<td>
        <a href='edit_product.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
        <a href='delete_product.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this product?\")'>Delete</a>
      </td>";

// ... existing code ...