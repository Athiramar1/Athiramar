<?php
require_once 'includes/header.php';

// Handle reorder functionality
if (isset($_GET['reorder']) && !empty($_GET['reorder'])) {
    $order_id = intval($_GET['reorder']);
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
    
    if ($user_id > 0) {
        // Verify the order belongs to the current user
        $check_query = "SELECT id FROM orders WHERE id = $order_id AND user_id = $user_id";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            // Get order items
            $items_query = "SELECT oi.product_id, oi.quantity, p.name, p.price 
                           FROM order_items oi 
                           LEFT JOIN products p ON oi.product_id = p.id 
                           WHERE oi.order_id = $order_id";
            $items_result = mysqli_query($conn, $items_query);
            
            // Clear current cart
            if (isset($_SESSION['cart'])) {
                unset($_SESSION['cart']);
            }
            
            // Initialize cart if needed
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = array();
            }
            
            // Add items to cart
            while ($item = mysqli_fetch_assoc($items_result)) {
                $_SESSION['cart'][] = array(
                    'product_id' => $item['product_id'],
                    'name' => $item['name'],
                    'price' => $item['price'],
                    'quantity' => $item['quantity']
                );
            }
            
            // Redirect to cart page
            echo '<div class="alert alert-success">Your previous order has been added to the cart.</div>';
            echo '<script>setTimeout(function() { window.location.href = "cart.php"; }, 2000);</script>';
        }
    }
}

// Get all categories
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_query);

// Get all products
$products_query = "SELECT p.*, c.name as category_name 
                  FROM products p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  ORDER BY p.category_id, p.name";
$products_result = mysqli_query($conn, $products_query);
?>

<!-- Breadcrumb Section -->
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <h2>Shop</h2>
                    <div class="breadcrumb-option">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <span>Shop</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<!-- Shop Section -->
<section class="shop-section spad">
    <div class="container">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-3">
                <div class="shop-sidebar">
                    <div class="sidebar-categories">
                        <h4>Categories</h4>
                        <ul>
                            <li><a href="shop.php">All Products</a></li>
                            <?php while ($category = mysqli_fetch_assoc($categories_result)): ?>
                            <li><a href="shop.php?category=<?php echo $category['id']; ?>"><?php echo $category['name']; ?></a></li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Products -->
            <div class="col-lg-9">
                <div class="row">
                    <?php if (mysqli_num_rows($products_result) > 0): ?>
                        <?php while ($product = mysqli_fetch_assoc($products_result)): ?>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="product-item">
                                <div class="product-img">
                                    <?php if (!empty($product['image'])): ?>
                                    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                                    <?php else: ?>
                                    <img src="assets/images/product-placeholder.jpg" alt="<?php echo $product['name']; ?>">
                                    <?php endif; ?>
                                    <div class="product-hover">
                                        <a href="product.php?id=<?php echo $product['id']; ?>" class="primary-btn">View Details</a>
                                        <a href="add_to_cart.php?id=<?php echo $product['id']; ?>" class="secondary-btn">Add to Cart</a>
                                    </div>
                                </div>
                                <div class="product-info">
                                    <h6><?php echo $product['name']; ?></h6>
                                    <div class="price">₹<?php echo number_format($product['price'], 2); ?></div>
                                    <div class="category"><?php echo $product['category_name']; ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="alert alert-info">No products found. Check back later!</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shop Section End -->

<?php
require_once 'includes/footer.php';
?> 