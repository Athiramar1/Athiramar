<?php
session_start();
require_once 'includes/db_connection.php';

// Return JSON response
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to cancel a service request.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if ID is provided
if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid service request ID.']);
    exit;
}

$request_id = intval($_POST['id']);

// Get the service request to check if it belongs to the user and can be cancelled
$request_query = "SELECT * FROM service_orders WHERE id = $request_id AND user_id = $user_id";
$request_result = mysqli_query($conn, $request_query);

if (mysqli_num_rows($request_result) == 0) {
    echo json_encode(['success' => false, 'message' => 'Service request not found or you don\'t have permission to cancel it.']);
    exit;
}

$request = mysqli_fetch_assoc($request_result);

// Check if request can be cancelled (only pending or confirmed requests)
if ($request['status'] > 2) {
    echo json_encode(['success' => false, 'message' => 'Only pending or confirmed service requests can be cancelled.']);
    exit;
}

// Update service request status to cancelled (status = 7)
$update_query = "UPDATE service_orders SET status = 7, updated_at = NOW() WHERE id = $request_id";
$update_result = mysqli_query($conn, $update_query);

if (!$update_result) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    exit;
}

// Add entry to service messages if table exists
$check_service_messages = mysqli_query($conn, "SHOW TABLES LIKE 'service_messages'");
if (mysqli_num_rows($check_service_messages) > 0) {
    $message_query = "INSERT INTO service_messages (service_order_id, user_id, message, is_admin, created_at) 
                     VALUES ($request_id, $user_id, 'Service request cancelled by customer', 0, NOW())";
    mysqli_query($conn, $message_query);
}

// Success response
echo json_encode(['success' => true, 'message' => 'Service request cancelled successfully.']);
?> 