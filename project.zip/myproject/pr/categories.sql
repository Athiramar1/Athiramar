-- Table structure for table `categories`
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample categories based on the product data
INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Business Cards', 'Professional business cards in various styles and finishes'),
(2, 'Brochures', 'Informative brochures in different fold types and sizes'),
(3, 'Flyers', 'Promotional flyers for marketing and advertising'),
(4, 'Posters', 'Eye-catching posters for promotions and events'),
(5, 'Banners', 'Durable banners for indoor and outdoor advertising'),
(6, 'Stationery', 'Professional stationery items for business use'),
(7, 'Postcards', 'Custom postcards for marketing and personal use'),
(8, 'Letterheads', 'Professional letterheads for business correspondence');