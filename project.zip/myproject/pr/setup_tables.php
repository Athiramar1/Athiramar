<?php
// Include database connection
require_once 'includes/db_connection.php';

// Create order_status table
$create_order_status = "CREATE TABLE IF NOT EXISTS `order_status` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(50) NOT NULL,
    `color` varchar(20) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Create service_status table
$create_service_status = "CREATE TABLE IF NOT EXISTS `service_status` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(50) NOT NULL,
    `color` varchar(20) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Create service_orders table if it doesn't exist
$create_service_orders = "CREATE TABLE IF NOT EXISTS `service_orders` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `service_id` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    `order_number` varchar(20) NOT NULL,
    `name` varchar(100) NOT NULL,
    `email` varchar(100) NOT NULL,
    `phone` varchar(20) NOT NULL,
    `address` text NOT NULL,
    `preferred_date` date NOT NULL,
    `preferred_time` varchar(50) NOT NULL,
    `scheduled_date` date DEFAULT NULL,
    `scheduled_time` varchar(50) DEFAULT NULL,
    `requirements` text DEFAULT NULL,
    `status_id` int(11) NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    KEY `service_id` (`service_id`),
    KEY `user_id` (`user_id`),
    KEY `status_id` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Create service_messages table
$create_service_messages = "CREATE TABLE IF NOT EXISTS `service_messages` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `service_order_id` int(11) NOT NULL,
    `message` text NOT NULL,
    `is_admin` tinyint(1) NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    KEY `service_order_id` (`service_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Create services table if it doesn't exist
$create_services = "CREATE TABLE IF NOT EXISTS `services` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
    `description` text NOT NULL,
    `image` varchar(255) DEFAULT NULL,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Success and error messages
$messages = [];

// Execute queries
if (mysqli_query($conn, $create_order_status)) {
    $messages[] = ["type" => "success", "text" => "order_status table created successfully"];
    
    // Check if order_status table is empty
    $check_status = mysqli_query($conn, "SELECT COUNT(*) as count FROM order_status");
    $status_count = mysqli_fetch_assoc($check_status)['count'];
    
    if ($status_count == 0) {
        // Insert default statuses
        $insert_order_statuses = "INSERT INTO `order_status` (`id`, `name`, `color`) VALUES
            (1, 'Pending', 'warning'),
            (2, 'Processing', 'primary'),
            (3, 'Shipped', 'info'),
            (4, 'Delivered', 'success'),
            (5, 'Cancelled', 'danger');";
        
        if (mysqli_query($conn, $insert_order_statuses)) {
            $messages[] = ["type" => "success", "text" => "Default order statuses inserted successfully"];
        } else {
            $messages[] = ["type" => "danger", "text" => "Error inserting default order statuses: " . mysqli_error($conn)];
        }
    }
} else {
    $messages[] = ["type" => "danger", "text" => "Error creating order_status table: " . mysqli_error($conn)];
}

if (mysqli_query($conn, $create_service_status)) {
    $messages[] = ["type" => "success", "text" => "service_status table created successfully"];
    
    // Check if service_status table is empty
    $check_status = mysqli_query($conn, "SELECT COUNT(*) as count FROM service_status");
    $status_count = mysqli_fetch_assoc($check_status)['count'];
    
    if ($status_count == 0) {
        // Insert default statuses
        $insert_service_statuses = "INSERT INTO `service_status` (`id`, `name`, `color`) VALUES
            (1, 'Pending', 'warning'),
            (2, 'Confirmed', 'primary'),
            (3, 'Awaiting Customer', 'info'),
            (4, 'Customer Replied', 'secondary'),
            (5, 'In Progress', 'primary'),
            (6, 'Completed', 'success'),
            (7, 'Cancelled', 'danger');";
        
        if (mysqli_query($conn, $insert_service_statuses)) {
            $messages[] = ["type" => "success", "text" => "Default service statuses inserted successfully"];
        } else {
            $messages[] = ["type" => "danger", "text" => "Error inserting default service statuses: " . mysqli_error($conn)];
        }
    }
} else {
    $messages[] = ["type" => "danger", "text" => "Error creating service_status table: " . mysqli_error($conn)];
}

if (mysqli_query($conn, $create_service_orders)) {
    $messages[] = ["type" => "success", "text" => "service_orders table created successfully"];
} else {
    $messages[] = ["type" => "danger", "text" => "Error creating service_orders table: " . mysqli_error($conn)];
}

if (mysqli_query($conn, $create_service_messages)) {
    $messages[] = ["type" => "success", "text" => "service_messages table created successfully"];
} else {
    $messages[] = ["type" => "danger", "text" => "Error creating service_messages table: " . mysqli_error($conn)];
}

if (mysqli_query($conn, $create_services)) {
    $messages[] = ["type" => "success", "text" => "services table created successfully"];
    
    // Check if services table is empty
    $check_services = mysqli_query($conn, "SELECT COUNT(*) as count FROM services");
    $services_count = mysqli_fetch_assoc($check_services)['count'];
    
    if ($services_count == 0) {
        // Insert sample services
        $insert_services = "INSERT INTO `services` (`name`, `description`, `status`, `created_at`) VALUES
            ('Offset Printing', 'Professional offset printing for high volume printing needs with superior quality.', 1, NOW()),
            ('Digital Printing', 'Quick turnaround digital printing services for small to medium volume requirements.', 1, NOW()),
            ('Large Format Printing', 'Eye-catching banners, posters, and signage for indoor and outdoor use.', 1, NOW()),
            ('Business Card Printing', 'Make a lasting impression with our premium business card printing options.', 1, NOW()),
            ('Brochure Design & Printing', 'Custom brochure design and printing services for marketing materials.', 1, NOW());";
        
        if (mysqli_query($conn, $insert_services)) {
            $messages[] = ["type" => "success", "text" => "Sample services inserted successfully"];
        } else {
            $messages[] = ["type" => "danger", "text" => "Error inserting sample services: " . mysqli_error($conn)];
        }
    }
} else {
    $messages[] = ["type" => "danger", "text" => "Error creating services table: " . mysqli_error($conn)];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container py-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0">Database Setup</h3>
            </div>
            <div class="card-body">
                <h4 class="mb-4">Setup Results:</h4>
                
                <?php foreach ($messages as $message): ?>
                    <div class="alert alert-<?php echo $message['type']; ?>">
                        <?php echo $message['text']; ?>
                    </div>
                <?php endforeach; ?>
                
                <div class="mt-4">
                    <p>Setup has been completed. You can now return to the website.</p>
                    <div class="d-grid gap-2 d-md-flex">
                        <a href="index.php" class="btn btn-primary">Go to Homepage</a>
                        <a href="my_orders.php" class="btn btn-success">Go to My Orders</a>
                        <a href="services.php" class="btn btn-info">View Services</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 