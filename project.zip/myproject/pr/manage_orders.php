<?php
// Include header
require_once 'includes/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page
    echo '<script>window.location.href = "login.php?redirect=manage_orders.php";</script>';
    exit;
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Handle adding service to orders
if (isset($_GET['add_service']) && !empty($_GET['add_service'])) {
    $service_id = intval($_GET['add_service']);
    
    // Check if service exists
    $service_check = "SELECT * FROM services WHERE id = $service_id AND status = 1";
    $service_result = mysqli_query($conn, $service_check);
    
    if (mysqli_num_rows($service_result) > 0) {
        $service = mysqli_fetch_assoc($service_result);
        
        // Generate order number
        $order_number = 'SRV-' . date('Ymd') . '-' . rand(1000, 9999);
        
        // Get user info
        $user_query = "SELECT * FROM users WHERE id = $user_id";
        $user_result = mysqli_query($conn, $user_query);
        $user = mysqli_fetch_assoc($user_result);
        
        // Insert service order with default values
        $insert_query = "INSERT INTO service_orders (service_id, user_id, order_number, name, email, phone, address, 
                        preferred_date, preferred_time, requirements, status, created_at) 
                        VALUES ($service_id, $user_id, '$order_number', '" . $user['name'] . "', '" . $user['email'] . "', 
                        '" . ($user['phone'] ?? '') . "', '" . ($user['address'] ?? '') . "', 
                        '" . date('Y-m-d', strtotime('+3 days')) . "', 'Morning (9AM - 12PM)', 'Added from services page. Please contact to confirm details.', 1, NOW())";
        
        if (mysqli_query($conn, $insert_query)) {
            $success_message = "Service '{$service['name']}' has been added to your orders. You can view it in your service requests.";
        } else {
            $error_message = "Error adding service to your orders: " . mysqli_error($conn);
        }
    } else {
        $error_message = "Invalid service selected";
    }
}

// Handle service order update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_service_order'])) {
    $order_id = intval($_POST['order_id']);
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    $preferred_date = sanitize_input($_POST['preferred_date']);
    $preferred_time = sanitize_input($_POST['preferred_time']);
    $requirements = sanitize_input($_POST['requirements']);
    
    // Verify the order belongs to the current user
    $check_query = "SELECT id FROM service_orders WHERE id = $order_id AND user_id = $user_id";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        // Update service order
        $update_query = "UPDATE service_orders SET 
                        name = '$name',
                        email = '$email',
                        phone = '$phone',
                        address = '$address',
                        preferred_date = '$preferred_date',
                        preferred_time = '$preferred_time',
                        requirements = '$requirements'
                        WHERE id = $order_id AND user_id = $user_id";
        
        if (mysqli_query($conn, $update_query)) {
            $success_message = "Service request updated successfully";
        } else {
            $error_message = "Error updating service request: " . mysqli_error($conn);
        }
    } else {
        $error_message = "You do not have permission to update this service request";
    }
}

// Get user's service orders
$service_orders_query = "SELECT so.*, s.name as service_name,
                        CASE so.status 
                            WHEN 1 THEN 'Pending' 
                            WHEN 2 THEN 'Confirmed' 
                            WHEN 3 THEN 'Awaiting Customer' 
                            WHEN 4 THEN 'Customer Replied' 
                            WHEN 5 THEN 'In Progress'
                            WHEN 6 THEN 'Completed'
                            WHEN 7 THEN 'Cancelled'
                            ELSE 'Unknown' 
                        END as status_name,
                        CASE so.status 
                            WHEN 1 THEN 'warning' 
                            WHEN 2 THEN 'primary' 
                            WHEN 3 THEN 'info' 
                            WHEN 4 THEN 'secondary' 
                            WHEN 5 THEN 'primary'
                            WHEN 6 THEN 'success'
                            WHEN 7 THEN 'danger'
                            ELSE 'secondary' 
                        END as status_color
                        FROM service_orders so 
                        LEFT JOIN services s ON so.service_id = s.id 
                        WHERE so.user_id = $user_id 
                        ORDER BY so.created_at DESC";
$service_orders_result = mysqli_query($conn, $service_orders_query);
?>

<!-- Breadcrumb Section -->
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <h2>Manage Orders</h2>
                    <div class="breadcrumb-option">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <span>Manage Orders</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<!-- Manage Orders Section -->
<section class="manage-orders-section spad">
    <div class="container">
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Your Service Requests</h4>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($service_orders_result) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Request #</th>
                                            <th>Date</th>
                                            <th>Service</th>
                                            <th>Preferred Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($order = mysqli_fetch_assoc($service_orders_result)): ?>
                                            <tr>
                                                <td><?php echo $order['order_number']; ?></td>
                                                <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                                <td><?php echo $order['service_name']; ?></td>
                                                <td><?php echo date('d M Y', strtotime($order['preferred_date'])); ?> (<?php echo $order['preferred_time']; ?>)</td>
                                                <td>
                                                    <span class="badge bg-<?php echo $order['status_color']; ?>">
                                                        <?php echo $order['status_name']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-info view-order" data-bs-toggle="modal" data-bs-target="#viewOrderModal" 
                                                            data-order-id="<?php echo $order['id']; ?>"
                                                            data-order-number="<?php echo $order['order_number']; ?>"
                                                            data-service-name="<?php echo $order['service_name']; ?>"
                                                            data-name="<?php echo $order['name']; ?>"
                                                            data-email="<?php echo $order['email']; ?>"
                                                            data-phone="<?php echo $order['phone']; ?>"
                                                            data-address="<?php echo $order['address']; ?>"
                                                            data-preferred-date="<?php echo $order['preferred_date']; ?>"
                                                            data-preferred-time="<?php echo $order['preferred_time']; ?>"
                                                            data-requirements="<?php echo $order['requirements']; ?>"
                                                            data-status="<?php echo $order['status_name']; ?>">
                                                        View
                                                    </button>
                                                    
                                                    <?php if ($order['status'] == 1): ?>
                                                    <button class="btn btn-sm btn-primary edit-order" data-bs-toggle="modal" data-bs-target="#editOrderModal" 
                                                            data-order-id="<?php echo $order['id']; ?>"
                                                            data-order-number="<?php echo $order['order_number']; ?>"
                                                            data-service-name="<?php echo $order['service_name']; ?>"
                                                            data-name="<?php echo $order['name']; ?>"
                                                            data-email="<?php echo $order['email']; ?>"
                                                            data-phone="<?php echo $order['phone']; ?>"
                                                            data-address="<?php echo $order['address']; ?>"
                                                            data-preferred-date="<?php echo $order['preferred_date']; ?>"
                                                            data-preferred-time="<?php echo $order['preferred_time']; ?>"
                                                            data-requirements="<?php echo $order['requirements']; ?>">
                                                        Edit
                                                    </button>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($order['status'] <= 2): // Only show cancel button for pending/confirmed requests ?>
                                                    <button class="btn btn-sm btn-danger delete-service-request" data-id="<?php echo $order['id']; ?>">
                                                        Cancel
                                                    </button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <p class="mb-0">You haven't requested any services yet.</p>
                                <a href="services.php" class="btn btn-primary mt-3">Browse Services</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- View Order Modal -->
<div class="modal fade" id="viewOrderModal" tabindex="-1" aria-labelledby="viewOrderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewOrderModalLabel">Service Request Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Request #</h6>
                        <p id="view-order-number"></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Service</h6>
                        <p id="view-service-name"></p>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Name</h6>
                        <p id="view-name"></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Email</h6>
                        <p id="view-email"></p>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Phone</h6>
                        <p id="view-phone"></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Address</h6>
                        <p id="view-address"></p>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Preferred Date</h6>
                        <p id="view-preferred-date"></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Preferred Time</h6>
                        <p id="view-preferred-time"></p>
                    </div>
                </div>
                
                <div class="mb-3">
                    <h6>Requirements</h6>
                    <p id="view-requirements"></p>
                </div>
                
                <div class="mb-3">
                    <h6>Status</h6>
                    <p id="view-status"></p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Order Modal -->
<div class="modal fade" id="editOrderModal" tabindex="-1" aria-labelledby="editOrderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editOrderModalLabel">Edit Service Request</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="manage_orders.php" method="post">
                    <input type="hidden" name="order_id" id="edit-order-id">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Request #</label>
                            <input type="text" class="form-control" id="edit-order-number" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Service</label>
                            <input type="text" class="form-control" id="edit-service-name" readonly>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit-name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="edit-name" name="name" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit-email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit-email" name="email" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit-phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="edit-phone" name="phone" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit-address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="edit-address" name="address" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit-preferred-date" class="form-label">Preferred Date</label>
                            <input type="date" class="form-control" id="edit-preferred-date" name="preferred_date" required min="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="edit-preferred-time" class="form-label">Preferred Time</label>
                            <select class="form-select" id="edit-preferred-time" name="preferred_time" required>
                                <option value="Morning (9AM - 12PM)">Morning (9AM - 12PM)</option>
                                <option value="Afternoon (12PM - 3PM)">Afternoon (12PM - 3PM)</option>
                                <option value="Evening (3PM - 6PM)">Evening (3PM - 6PM)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit-requirements" class="form-label">Requirements</label>
                        <textarea class="form-control" id="edit-requirements" name="requirements" rows="4"></textarea>
                    </div>
                    
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" name="update_service_order">Update Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for Manage Orders Page -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle view order button clicks
    document.querySelectorAll('.view-order').forEach(button => {
        button.addEventListener('click', function() {
            // Get data from button attributes
            const orderNumber = this.getAttribute('data-order-number');
            const serviceName = this.getAttribute('data-service-name');
            const name = this.getAttribute('data-name');
            const email = this.getAttribute('data-email');
            const phone = this.getAttribute('data-phone');
            const address = this.getAttribute('data-address');
            const preferredDate = this.getAttribute('data-preferred-date');
            const preferredTime = this.getAttribute('data-preferred-time');
            const requirements = this.getAttribute('data-requirements');
            const status = this.getAttribute('data-status');
            
            // Set values in modal
            document.getElementById('view-order-number').textContent = orderNumber;
            document.getElementById('view-service-name').textContent = serviceName;
            document.getElementById('view-name').textContent = name;
            document.getElementById('view-email').textContent = email;
            document.getElementById('view-phone').textContent = phone;
            document.getElementById('view-address').textContent = address;
            document.getElementById('view-preferred-date').textContent = new Date(preferredDate).toLocaleDateString();
            document.getElementById('view-preferred-time').textContent = preferredTime;
            document.getElementById('view-requirements').textContent = requirements || 'No special requirements';
            document.getElementById('view-status').textContent = status;
        });
    });
    
    // Handle edit order button clicks
    document.querySelectorAll('.edit-order').forEach(button => {
        button.addEventListener('click', function() {
            // Get data from button attributes
            const orderId = this.getAttribute('data-order-id');
            const orderNumber = this.getAttribute('data-order-number');
            const serviceName = this.getAttribute('data-service-name');
            const name = this.getAttribute('data-name');
            const email = this.getAttribute('data-email');
            const phone = this.getAttribute('data-phone');
            const address = this.getAttribute('data-address');
            const preferredDate = this.getAttribute('data-preferred-date');
            const preferredTime = this.getAttribute('data-preferred-time');
            const requirements = this.getAttribute('data-requirements');
            
            // Set values in modal
            document.getElementById('edit-order-id').value = orderId;
            document.getElementById('edit-order-number').value = orderNumber;
            document.getElementById('edit-service-name').value = serviceName;
            document.getElementById('edit-name').value = name;
            document.getElementById('edit-email').value = email;
            document.getElementById('edit-phone').value = phone;
            document.getElementById('edit-address').value = address;
            document.getElementById('edit-preferred-date').value = preferredDate;
            document.getElementById('edit-preferred-time').value = preferredTime;
            document.getElementById('edit-requirements').value = requirements;
        });
    });
    
    // Handle service request delete buttons
    document.querySelectorAll('.delete-service-request').forEach(button => {
        button.addEventListener('click', function() {
            const requestId = this.getAttribute('data-id');
            if (confirm('Are you sure you want to cancel this service request? This action cannot be undone.')) {
                // Send AJAX request to cancel the service request
                fetch('delete_service_request.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'id=' + requestId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Refresh the page to show updated status
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the service request.');
                });
            }
        });
    });
});
</script>

<?php
require_once 'includes/footer.php';
?> 