<?php
// Include header which loads the database connection
require_once 'includes/header.php';

// Create services table if it doesn't exist
$create_services = "CREATE TABLE IF NOT EXISTS `services` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
    `description` text NOT NULL,
    `image` varchar(255) DEFAULT NULL,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute query to create table
if (mysqli_query($conn, $create_services)) {
    echo "<div class='alert alert-success'>Services table created successfully</div>";
    
    // Check if services table is empty
    $check_services = mysqli_query($conn, "SELECT COUNT(*) as count FROM services");
    $services_count = mysqli_fetch_assoc($check_services)['count'];
    
    if ($services_count == 0) {
        // Insert sample services
        $insert_services = "INSERT INTO `services` (`name`, `description`, `status`, `created_at`) VALUES
            ('Offset Printing', 'Professional offset printing for high volume printing needs with superior quality.', 1, NOW()),
            ('Digital Printing', 'Quick turnaround digital printing services for small to medium volume requirements.', 1, NOW()),
            ('Large Format Printing', 'Eye-catching banners, posters, and signage for indoor and outdoor use.', 1, NOW()),
            ('Business Card Printing', 'Make a lasting impression with our premium business card printing options.', 1, NOW()),
            ('Brochure Design & Printing', 'Custom brochure design and printing services for marketing materials.', 1, NOW());";
        
        if (mysqli_query($conn, $insert_services)) {
            echo "<div class='alert alert-success'>Sample services inserted successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error inserting sample services: " . mysqli_error($conn) . "</div>";
        }
    }
} else {
    echo "<div class='alert alert-danger'>Error creating services table: " . mysqli_error($conn) . "</div>";
}

echo "<p><a href='services.php' class='btn btn-primary'>Go to Services Page</a></p>";

// Include footer
require_once 'includes/footer.php';
?> 