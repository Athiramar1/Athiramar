    </main>
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h4 class="mb-3">
                        <span class="text-primary">Multi</span> 
                        <span class="text-danger">Color</span> 
                        <span class="text-success">Offset</span> 
                        <span class="text-warning">Printing</span>
                    </h4>
                    <p>We provide high-quality offset printing services for all your business needs. From business cards to brochures, we've got you covered.</p>
                </div>
                <div class="col-md-4">
                    <h4 class="mb-3">Product Categories</h4>
                    <ul class="list-unstyled">
                        <li><a href="services.php#business-cards" class="text-white text-decoration-none">Business Cards</a></li>
                        <li><a href="services.php#brochures" class="text-white text-decoration-none">Brochures</a></li>
                        <li><a href="services.php#flyers" class="text-white text-decoration-none">Flyers</a></li>
                        <li><a href="services.php#postcards" class="text-white text-decoration-none">Postcards</a></li>
                        <li><a href="services.php#letterheads" class="text-white text-decoration-none">Letterheads</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4 class="mb-3">Contact</h4>
                    <address>
                        <p><i class="fas fa-map-marker-alt me-2"></i> #1050, Sathi Road, Opp. LMW<br>
                        (Near Textool Bridge)<br>
                        Ganapathy Pudur, Ganapathy,<br>
                        Coimbatore - 641 006.</p>
                        <p><i class="fas fa-phone me-2"></i> +91 989 404 9627/28</p>
                        <p><i class="fas fa-envelope me-2"></i> athiramar@saiprinters.com</p>
                    </address>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> Multi Color Offset Printing. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/script1.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
