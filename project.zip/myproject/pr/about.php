<?php 
require_once 'includes/header.php';
?>

<!-- About Us Banner -->
<div class="container-fluid p-0">
    <div class="banner">
        <img src="assets/images/about1.jpg" alt="About Our Company">
        <div class="banner-content">
            <h1>About Our Company</h1>
            <p>Learn more about Multi Color Offset Printing</p>
        </div>
    </div>
</div>

<!-- About Us Content -->
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-6">
            <h2 class="mb-4">Our Story</h2>
            <p>Founded in 2005, Multi Color Offset Printing has grown to become one of the leading offset printing companies in Coimbatore, Tamil Nadu. With a commitment to quality and customer satisfaction, we have built a reputation for delivering exceptional printing services to businesses of all sizes.</p>
            
            <p>Our journey began with a small printing press and a team of dedicated professionals who shared a passion for print excellence. Over the years, we have expanded our facilities and upgraded our technology to meet the growing demands of our clients.</p>
            
            <p>Today, we are proud to serve a diverse clientele across Tamil Nadu and beyond, providing comprehensive offset printing solutions that help businesses communicate effectively with their audiences.</p>
        </div>
        
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Company Details</h3>
                    <p><strong>Company Name:</strong> Multi Color Offset Printing Pvt. Ltd.</p>
                    <p><strong>Contact:</strong><br>
                    Landline: +91 422 4373087 / 4371087<br>
                    Mobile: +91 989 404 9627 / 989 404 9628</p>
                    <p><strong>Email:</strong> athiramar@saiprinters.com</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>
