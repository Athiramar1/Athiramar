<?php
require_once 'includes/config.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Check if product ID is provided
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $product_id = intval($_GET['id']);
    
    // Get product details
    $product_query = "SELECT * FROM products WHERE id = $product_id";
    $product_result = mysqli_query($conn, $product_query);
    
    if (mysqli_num_rows($product_result) > 0) {
        $product = mysqli_fetch_assoc($product_result);
        
        // Check if product is already in cart
        $item_exists = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['product_id'] == $product_id) {
                // Increment quantity
                $item['quantity']++;
                $item_exists = true;
                break;
            }
        }
        
        // If product is not in cart, add it
        if (!$item_exists) {
            $_SESSION['cart'][] = array(
                'product_id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => 1
            );
        }
        
        // Set success message
        $_SESSION['success_message'] = "Product added to cart.";
    } else {
        // Set error message
        $_SESSION['error_message'] = "Product not found.";
    }
} else {
    // Set error message
    $_SESSION['error_message'] = "Invalid product.";
}

// Redirect back to the referring page or to shop
$redirect = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'shop.php';
header("Location: $redirect");
exit;
?> 