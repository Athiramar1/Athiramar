<?php
session_start();
require_once 'includes/db_connection.php';

// Return JSON response
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to cancel an order.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if ID is provided
if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid order ID.']);
    exit;
}

$order_id = intval($_POST['id']);

// Get the order to check if it belongs to the user and can be cancelled
$order_query = "SELECT * FROM orders WHERE id = $order_id AND user_id = $user_id";
$order_result = mysqli_query($conn, $order_query);

if (mysqli_num_rows($order_result) == 0) {
    echo json_encode(['success' => false, 'message' => 'Order not found or you don\'t have permission to cancel it.']);
    exit;
}

$order = mysqli_fetch_assoc($order_result);

// Check if order can be cancelled (only pending orders)
if ($order['status'] != 1) {
    echo json_encode(['success' => false, 'message' => 'Only pending orders can be cancelled.']);
    exit;
}

// Update order status to cancelled (status = 5)
$update_query = "UPDATE orders SET status = 5, updated_at = NOW() WHERE id = $order_id";
$update_result = mysqli_query($conn, $update_query);

if (!$update_result) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    exit;
}

// Check if order_status_history table exists
$check_history_table = mysqli_query($conn, "SHOW TABLES LIKE 'order_status_history'");
if (mysqli_num_rows($check_history_table) > 0) {
    // Add entry to order status history
    $history_query = "INSERT INTO order_status_history (order_id, status, comments, created_at) 
                     VALUES ($order_id, 5, 'Order cancelled by customer', NOW())";
    mysqli_query($conn, $history_query);
} else {
    // Create the order_status_history table and then add the entry
    $create_history_table = "CREATE TABLE order_status_history (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT NOT NULL,
        status INT NOT NULL,
        comments TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (mysqli_query($conn, $create_history_table)) {
        $history_query = "INSERT INTO order_status_history (order_id, status, comments, created_at) 
                         VALUES ($order_id, 5, 'Order cancelled by customer', NOW())";
        mysqli_query($conn, $history_query);
    }
}

// Success response
echo json_encode(['success' => true, 'message' => 'Order cancelled successfully.']);
?> 