<?php
require_once 'includes/header.php';

// Check if contact_messages table exists
$table_check_query = "SHOW TABLES LIKE 'contact_messages'";
$table_check_result = mysqli_query($conn, $table_check_query);

if (mysqli_num_rows($table_check_result) == 0) {
    // Create contact_messages table with new structure
    $create_table_query = "CREATE TABLE contact_messages (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        subject VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    if (mysqli_query($conn, $create_table_query)) {
        echo '<div class="alert alert-success">Contact messages table created successfully.</div>';
    } else {
        echo '<div class="alert alert-danger">Error creating contact messages table: ' . mysqli_error($conn) . '</div>';
    }
}

// Get product details from query parameters
$product_name = isset($_GET['product_name']) ? $_GET['product_name'] : '';
$product_id = isset($_GET['product']) ? $_GET['product'] : '';
$product_price = isset($_GET['price']) ? $_GET['price'] : '';

// Set default subject based on product details
$default_subject = '';
if (!empty($product_name)) {
    $default_subject = "Order Inquiry: " . $product_name;
}

// Set default message based on product details
$default_message = '';
if (!empty($product_name)) {
    $default_message = "I would like to order the following product:\n";
    $default_message .= "Product: " . $product_name . "\n";
    if (!empty($product_price)) {
        $default_message .= "Price: ₹" . number_format($product_price, 2) . "\n";
    }
    $default_message .= "\nPlease let me know the next steps to complete my order.";
}

// Handle direct order for logged-in users
if (isset($_SESSION['user_id']) && !empty($product_name) && !empty($product_price)) {
    // Show direct order option
    $direct_order_available = true;
    
    // Process direct order if submitted
    if (isset($_POST['direct_order'])) {
        $user_id = $_SESSION['user_id'];
        
        // Get product ID if available, otherwise try to find it by name
        if (empty($product_id) && !empty($product_name)) {
            $find_product_query = "SELECT id FROM products WHERE name = '" . sanitize_input($product_name) . "'";
            $find_product_result = mysqli_query($conn, $find_product_query);
            if (mysqli_num_rows($find_product_result) > 0) {
                $product_id = mysqli_fetch_assoc($find_product_result)['id'];
            }
        }
        
        // Check if orders table exists
        $check_orders_table = mysqli_query($conn, "SHOW TABLES LIKE 'orders'");
        if (mysqli_num_rows($check_orders_table) == 0) {
            // Create orders table
            $create_orders_table = "CREATE TABLE orders (
                id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT NOT NULL,
                order_number VARCHAR(20) NOT NULL,
                total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
                shipping_cost DECIMAL(10,2) DEFAULT 0,
                tax_amount DECIMAL(10,2) DEFAULT 0,
                shipping_address TEXT,
                billing_address TEXT,
                status INT NOT NULL DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";
            mysqli_query($conn, $create_orders_table);
        } else {
            // Check if order_number column exists
            $check_column = mysqli_query($conn, "SHOW COLUMNS FROM orders LIKE 'order_number'");
            if (mysqli_num_rows($check_column) == 0) {
                // Add order_number column
                mysqli_query($conn, "ALTER TABLE orders ADD COLUMN order_number VARCHAR(20) NOT NULL AFTER user_id");
            }
        }
        
        // Check if order_items table exists
        $check_items_table = mysqli_query($conn, "SHOW TABLES LIKE 'order_items'");
        if (mysqli_num_rows($check_items_table) == 0) {
            // Create order_items table
            $create_items_table = "CREATE TABLE order_items (
                id INT PRIMARY KEY AUTO_INCREMENT,
                order_id INT NOT NULL,
                product_id INT,
                product_name VARCHAR(255),
                quantity INT NOT NULL DEFAULT 1,
                price DECIMAL(10,2) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            mysqli_query($conn, $create_items_table);
        }
        
        // Generate order number
        $order_number = 'ORD-' . date('Ymd') . '-' . rand(1000, 9999);
        
        // Insert order
        $insert_order_query = "INSERT INTO orders (user_id, order_number, total_amount, status, created_at) 
                              VALUES ($user_id, '$order_number', " . floatval($product_price) . ", 1, NOW())";
        
        if (mysqli_query($conn, $insert_order_query)) {
            $order_id = mysqli_insert_id($conn);
            
            // Insert order item
            if (!empty($product_id)) {
                $insert_item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                                     VALUES ($order_id, $product_id, 1, " . floatval($product_price) . ")";
            } else {
                // If product doesn't exist in database, create a custom order item
                $insert_item_query = "INSERT INTO order_items (order_id, product_name, quantity, price) 
                                     VALUES ($order_id, '" . sanitize_input($product_name) . "', 1, " . floatval($product_price) . ")";
            }
            
            if (mysqli_query($conn, $insert_item_query)) {
                $_SESSION['success'] = "Your order has been placed successfully! You can track it in your orders page.";
                header("Location: my_orders.php");
                exit();
            } else {
                $_SESSION['error'] = "Failed to process order item. Please try again. Error: " . mysqli_error($conn);
            }
        } else {
            $_SESSION['error'] = "Failed to process order. Please try again. Error: " . mysqli_error($conn);
        }
    }
} else {
    $direct_order_available = false;
}

// Process contact form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $subject = sanitize_input($_POST['subject']);
    $user_message = sanitize_input($_POST['message']);
    
    // Validate form data
    if (empty($name) || empty($email) || empty($subject) || empty($user_message)) {
        $message = '<div class="alert alert-danger">Please fill all required fields.</div>';
    } else {
        // Insert into contact_messages table
        $sql = "INSERT INTO contact_messages (name, email, subject, message, created_at) 
                VALUES ('$name', '$email', '$subject', '$user_message', NOW())";
        
        if (mysqli_query($conn, $sql)) {
            $_SESSION['success'] = "Your message has been sent successfully! We will get back to you soon.";
            header("Location: contact.php");
            exit();
        } else {
            $_SESSION['error'] = "Failed to send message. Please try again.";
        }
    }
}

// Display success/error messages
if (isset($_SESSION['success'])) {
    $message = '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    $message = '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
    unset($_SESSION['error']);
}
?>

<!-- Contact Banner -->
<div class="container-fluid p-0">
    <div class="banner">
        <img src="assets/images/contact1.jpg" alt="Contact Us">
        <div class="banner-content">
            <h1>Contact With Us</h1>
            <p>We'd love to hear from you</p>
        </div>
    </div>
</div>

<!-- Contact Content -->
<div class="container mt-5">
    <?php if (isset($direct_order_available) && $direct_order_available): ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Quick Order</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5>Product: <?php echo htmlspecialchars($product_name); ?></h5>
                            <p class="mb-0">Price: ₹<?php echo number_format(floatval($product_price), 2); ?></p>
                            <p class="text-muted small">This product will be directly added to your orders.</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="post">
                                <button type="submit" name="direct_order" class="btn btn-success">Order Now</button>
                                <a href="my_orders.php" class="btn btn-outline-secondary ms-2">View My Orders</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php elseif (!empty($product_name) && empty($_SESSION['user_id'])): ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Quick Order</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5>Product: <?php echo htmlspecialchars($product_name); ?></h5>
                            <p class="mb-0">Price: ₹<?php echo number_format(floatval($product_price), 2); ?></p>
                            <p class="text-muted small">Please log in to place an order directly, or use the contact form below.</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <a href="login.php?redirect=contact.php?product_name=<?php echo urlencode($product_name); ?>&price=<?php echo urlencode($product_price); ?>" class="btn btn-primary">Log In to Order</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-7">
            <div class="contact-form">
                <h2 class="mb-4">Send Message</h2>
                <?php echo $message; ?>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label for="name" class="form-label">Your full name*</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                        <div class="invalid-feedback">
                            Please enter your name.
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Your email address*</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                        <div class="invalid-feedback">
                            Please enter a valid email address.
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="subject" class="form-label">Subject*</label>
                        <input type="text" class="form-control" id="subject" name="subject" value="<?php echo htmlspecialchars($default_subject); ?>" required>
                        <div class="invalid-feedback">
                            Please provide a subject.
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="message" class="form-label">Message*</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required><?php echo htmlspecialchars($default_message); ?></textarea>
                        <div class="invalid-feedback">
                            Please provide a message.
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="contact-info h-100">
                <h2 class="mb-4">Contact Info</h2>
                <div class="mb-4">
                    <h5>Details</h5>
                    <p>Feel free to contact us anytime. We're here to help you with all your printing needs.</p>
                </div>
                
                <div class="mb-4">
                    <h5>Address</h5>
                    <p>
                        #1050, Sathi Road, Opp. LMW<br>
                        (Near Textool Bridge)<br>
                        Ganapathy Pudur, Ganapathy,<br>
                        Coimbatore - 641 006.<br>
                        TamilNadu, India.
                    </p>
                </div>
                
                <div class="mb-4">
                    <h5>Phone</h5>
                    <p>
                        Landline: +91 422 4373087 / 4371087<br>
                        Mobile: +91 989 404 9627 / 989 404 9628
                    </p>
                </div>
                
                <div class="mb-4">
                    <h5>Email</h5>
                    <p>athiramar@saiprinters.com</p>
                </div>
                
                <div class="mb-4">
                    <h5>Working Hours</h5>
                    <p>
                        Monday - Saturday: 9:00 AM - 6:00 PM<br>
                        Sunday: Closed
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>
