<?php
// Include admin header
require_once 'includes/admin_header.php';

$message = '';
$product = null;

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $message = '<div class="alert alert-danger">Product ID is required.</div>';
} else {
    $product_id = intval($_GET['id']);
    
    // Fetch product details
    $product_query = "SELECT * FROM products WHERE id = $product_id";
    $product_result = mysqli_query($conn, $product_query);
    
    if (mysqli_num_rows($product_result) == 0) {
        $message = '<div class="alert alert-danger">Product not found.</div>';
    } else {
        $product = mysqli_fetch_assoc($product_result);
    }
}

// Process form submission for editing product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_product']) && $product) {
    $product_name = sanitize_input($_POST['name']);
    $product_code = sanitize_input($_POST['product_code']);
    $category_id = sanitize_input($_POST['category_id']);
    $product_size = sanitize_input($_POST['size']);
    $product_price = sanitize_input($_POST['price']);
    $product_stock = sanitize_input($_POST['stock']);
    $product_description = sanitize_input($_POST['description']);
    
    // Validate form data
    if (empty($product_name) || empty($product_code) || empty($category_id) || empty($product_price)) {
        $message = '<div class="alert alert-danger">Please fill all required fields.</div>';
    } else {
        // Check if product code already exists (excluding current product)
        $check_query = "SELECT * FROM products WHERE product_code = '$product_code' AND id != $product_id";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $message = '<div class="alert alert-danger">Product code already exists.</div>';
        } else {
            // Handle image upload
            $image_path = $product['image']; // Keep existing image by default
            
            if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {
                $target_dir = "../assets/images/products/";
                
                // Create directory if it doesn't exist
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                $file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
                $new_filename = $product_code . "_" . time() . "." . $file_extension;
                $target_file = $target_dir . $new_filename;
                
                // Check if image file is a actual image
                $check = getimagesize($_FILES["image"]["tmp_name"]);
                if ($check !== false) {
                    // Delete old image if exists
                    if (!empty($product['image']) && file_exists("../" . $product['image'])) {
                        unlink("../" . $product['image']);
                    }
                    
                    // Upload file
                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        $image_path = "assets/images/products/" . $new_filename;
                    } else {
                        $message = '<div class="alert alert-danger">Sorry, there was an error uploading your file.</div>';
                    }
                } else {
                    $message = '<div class="alert alert-danger">File is not an image.</div>';
                }
            }
            
            if (empty($message)) {
                // Update product
                $update_query = "UPDATE products SET 
                                name = '$product_name', 
                                product_code = '$product_code', 
                                category_id = '$category_id', 
                                description = '$product_description', 
                                size = '$product_size', 
                                price = '$product_price', 
                                stock = '$product_stock', 
                                image = '$image_path' 
                                WHERE id = $product_id";
                
                if (mysqli_query($conn, $update_query)) {
                    $message = '<div class="alert alert-success">Product updated successfully.</div>';
                    
                    // Refresh product data
                    $product_result = mysqli_query($conn, $product_query);
                    $product = mysqli_fetch_assoc($product_result);
                } else {
                    $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
                }
            }
        }
    }
}

// Get categories for dropdown
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_query);
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Edit Product</h2>
        <a href="manage_product.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Products
        </a>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <?php if ($product): ?>
    <!-- Edit Product Form -->
    <div class="card">
        <div class="card-body">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">Product Name*</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="product_code" class="form-label">Product Code*</label>
                        <input type="text" class="form-control" id="product_code" name="product_code" value="<?php echo htmlspecialchars($product['product_code']); ?>" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="category_id" class="form-label">Category*</label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <?php 
                            mysqli_data_seek($categories_result, 0);
                            while ($category = mysqli_fetch_assoc($categories_result)) {
                                $selected = ($category['id'] == $product['category_id']) ? 'selected' : '';
                                echo '<option value="' . $category['id'] . '" ' . $selected . '>' . htmlspecialchars($category['name']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="size" class="form-label">Product Size</label>
                        <input type="text" class="form-control" id="size" name="size" value="<?php echo htmlspecialchars($product['size']); ?>" placeholder="e.g. A4, 5x7, etc.">
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="price" class="form-label">Price (₹)*</label>
                        <input type="number" class="form-control" id="price" name="price" value="<?php echo $product['price']; ?>" step="0.01" min="0" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="stock" class="form-label">Stock*</label>
                        <input type="number" class="form-control" id="stock" name="stock" value="<?php echo $product['stock']; ?>" min="0" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="image" class="form-label">Product Image</label>
                        <input type="file" class="form-control image-input" id="image" name="image" data-preview="imagePreview">
                        <small class="form-text text-muted">Leave empty to keep current image.</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <?php if (!empty($product['image'])): ?>
                        <label class="form-label">Current Image</label>
                        <div>
                            <img src="../<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="img-thumbnail" style="max-height: 150px;">
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" name="edit_product" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <a href="manage_product.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
    // Image preview script
    document.addEventListener('DOMContentLoaded', function() {
        const imageInput = document.querySelector('.image-input');
        const imagePreview = document.getElementById('imagePreview');
        
        if (imageInput && imagePreview) {
            imageInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        imagePreview.style.display = 'block';
                    }
                    
                    reader.readAsDataURL(this.files[0]);
                }
            });
        }
    });
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>