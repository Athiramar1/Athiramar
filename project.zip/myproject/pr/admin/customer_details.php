<?php
// Include admin header
require_once 'includes/admin_header.php';

// Process customer deletion
$message = '';
if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];
    
    // Check if user has orders
    $check_orders = "SELECT COUNT(*) as order_count FROM orders WHERE user_id = $user_id";
    $order_result = mysqli_query($conn, $check_orders);
    $order_data = mysqli_fetch_assoc($order_result);
    
    if ($order_data['order_count'] > 0) {
        $message = '<div class="alert alert-danger">Cannot delete customer. They have orders associated with their account.</div>';
    } else {
        // Delete user
        $delete_query = "DELETE FROM users WHERE id = $user_id AND is_admin = 0";
        if (mysqli_query($conn, $delete_query)) {
            $message = '<div class="alert alert-success">Customer deleted successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total number of customers (non-admin users)
$total_query = "SELECT COUNT(*) as total FROM users WHERE is_admin = 0";
$total_result = mysqli_query($conn, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_records = $total_data['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get customers with pagination
$paginated_query = "SELECT * FROM users WHERE is_admin = 0 ORDER BY created_at DESC LIMIT $offset, $records_per_page";
$paginated_result = mysqli_query($conn, $paginated_query);

// Search functionality
$search_query = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = sanitize_input($_GET['search']);
    $search_query = "AND (username LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%')";
    
    // Update queries with search
    $total_query = "SELECT COUNT(*) as total FROM users WHERE is_admin = 0 $search_query";
    $total_result = mysqli_query($conn, $total_query);
    $total_data = mysqli_fetch_assoc($total_result);
    $total_records = $total_data['total'];
    $total_pages = ceil($total_records / $records_per_page);
    
    $paginated_query = "SELECT * FROM users WHERE is_admin = 0 $search_query ORDER BY created_at DESC LIMIT $offset, $records_per_page";
    $paginated_result = mysqli_query($conn, $paginated_query);
}
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Customer Details</h2>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <!-- Customer Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <span class="me-2">Show</span>
                        <select class="form-select form-select-sm w-auto" id="entriesSelect" onchange="changeEntries(this.value)">
                            <option value="50" <?php echo $records_per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $records_per_page == 100 ? 'selected' : ''; ?>>100</option>
                            <option value="200" <?php echo $records_per_page == 200 ? 'selected' : ''; ?>>200</option>
                        </select>
                        <span class="ms-2">entries</span>
                    </div>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Registered On</th>
                            <th>Orders</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($paginated_result) > 0) {
                            $counter = $offset + 1;
                            while ($customer = mysqli_fetch_assoc($paginated_result)) {
                                // Get order count for this customer
                                $order_count_query = "SELECT COUNT(*) as order_count FROM orders WHERE user_id = " . $customer['id'];
                                $order_count_result = mysqli_query($conn, $order_count_query);
                                $order_count_data = mysqli_fetch_assoc($order_count_result);
                        ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo htmlspecialchars($customer['username']); ?></td>
                                <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                <td><?php echo htmlspecialchars($customer['phone']); ?></td>
                                <td><?php echo date('d M Y', strtotime($customer['created_at'])); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo $order_count_data['order_count']; ?></span>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewCustomerModal<?php echo $customer['id']; ?>">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <a href="customer_details.php?delete=<?php echo $customer['id']; ?>" class="btn btn-sm btn-danger delete-btn" onclick="return confirm('Are you sure you want to delete this customer?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    
                                    <!-- View Customer Modal -->
                                    <div class="modal fade" id="viewCustomerModal<?php echo $customer['id']; ?>" tabindex="-1" aria-labelledby="viewCustomerModalLabel<?php echo $customer['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="viewCustomerModalLabel<?php echo $customer['id']; ?>">Customer Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <p><strong>Username:</strong> <?php echo htmlspecialchars($customer['username']); ?></p>
                                                            <p><strong>Email:</strong> <?php echo htmlspecialchars($customer['email']); ?></p>
                                                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($customer['phone']); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><strong>Registered On:</strong> <?php echo date('d M Y h:i A', strtotime($customer['created_at'])); ?></p>
                                                            <p><strong>Total Orders:</strong> <?php echo $order_count_data['order_count']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p><strong>Address:</strong></p>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo !empty($customer['address']) ? nl2br(htmlspecialchars($customer['address'])) : 'No address provided'; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="7" class="text-center">No customers found.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function changeEntries(entries) {
        window.location.href = 'customer_details.php?entries=' + entries + '<?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>';
    }
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
