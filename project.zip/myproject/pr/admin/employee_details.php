<?php
// Include admin header
require_once 'includes/admin_header.php';

// Process form submission for editing employee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_employee'])) {
    $employee_id = intval($_POST['employee_id']);
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    $role = sanitize_input($_POST['role']);
    
    // Check if email already exists for other employees
    $check_query = "SELECT * FROM users WHERE email = '$email' AND id != $employee_id";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        echo '<div class="alert alert-danger">Email already exists for another employee.</div>';
    } else {
        // Prepare update query
        $update_query = "UPDATE users SET 
                        username = '$username', 
                        email = '$email', 
                        phone = '$phone', 
                        address = '$address', 
                        role = '$role'";
        
        // Check if password should be changed
        if (isset($_POST['change_password']) && !empty($_POST['password'])) {
            $password = sanitize_input($_POST['password']);
            $confirm_password = sanitize_input($_POST['confirm_password']);
            
            if ($password != $confirm_password) {
                echo '<div class="alert alert-danger">New passwords do not match.</div>';
            } else {
                // Hash new password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Add password to update query
                $update_query .= ", password = '$hashed_password'";
            }
        }
        
        // Finalize query and execute
        $update_query .= " WHERE id = $employee_id";
        
        if (mysqli_query($conn, $update_query)) {
            echo '<div class="alert alert-success">Employee updated successfully.</div>';
        } else {
            echo '<div class="alert alert-danger">Error updating employee: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Check if users table exists
$table_check_query = "SHOW TABLES LIKE 'users'";
$table_check_result = mysqli_query($conn, $table_check_query);

if (mysqli_num_rows($table_check_result) == 0) {
    // Create users table with new structure
    $create_table_query = "CREATE TABLE users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        address TEXT,
        is_admin BOOLEAN DEFAULT FALSE,
        role VARCHAR(50) DEFAULT 'Admin',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    if (mysqli_query($conn, $create_table_query)) {
        echo '<div class="alert alert-success">Users table created successfully.</div>';
    } else {
        echo '<div class="alert alert-danger">Error creating users table: ' . mysqli_error($conn) . '</div>';
    }
} else {
    // Check if role column exists
    $column_check_query = "SHOW COLUMNS FROM users LIKE 'role'";
    $column_check_result = mysqli_query($conn, $column_check_query);

    if (mysqli_num_rows($column_check_result) == 0) {
        // Add role column if it doesn't exist
        $add_column_query = "ALTER TABLE users ADD COLUMN role VARCHAR(50) DEFAULT 'Admin'";
        if (mysqli_query($conn, $add_column_query)) {
            echo '<div class="alert alert-success">Role column added to users table successfully.</div>';
        } else {
            echo '<div class="alert alert-danger">Error adding role column to users table: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Check if current user is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    // Redirect to login page if not admin
    header("Location: login.php");
    exit;
}

// Process form submission for adding new employee
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_employee'])) {
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $password = sanitize_input($_POST['password']);
    $confirm_password = sanitize_input($_POST['confirm_password']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    $role = sanitize_input($_POST['role']);
    
    // Validate form data
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = '<div class="alert alert-danger">Please fill all required fields.</div>';
    } elseif ($password != $confirm_password) {
        $message = '<div class="alert alert-danger">Passwords do not match.</div>';
    } else {
        // Check if email already exists
        $check_query = "SELECT * FROM users WHERE email = '$email'";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $message = '<div class="alert alert-danger">Email already exists.</div>';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new employee
            $insert_query = "INSERT INTO users (username, email, password, phone, address, is_admin, role) 
                            VALUES ('$username', '$email', '$hashed_password', '$phone', '$address', 1, '$role')";
            
            if (mysqli_query($conn, $insert_query)) {
                $message = '<div class="alert alert-success">Employee added successfully.</div>';
            } else {
                $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
            }
        }
    }
}

// Add remove functionality
if(isset($_GET['remove_id']) && !empty($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    
    // Prevent removing your own account
    if($remove_id == $_SESSION['user_id']) {
        echo '<div class="alert alert-danger">You cannot remove your own account!</div>';
    } else {
        // Instead of deleting, we'll set is_admin to 0 to deactivate the employee account
        $update_query = "UPDATE users SET is_admin = 0 WHERE id = $remove_id";
        if(mysqli_query($conn, $update_query)) {
            echo '<div class="alert alert-success">Employee removed successfully!</div>';
        } else {
            echo '<div class="alert alert-danger">Error removing employee: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Add delete functionality
if(isset($_GET['delete_id']) && !empty($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    
    // Prevent deleting your own account
    if($delete_id == $_SESSION['user_id']) {
        echo '<div class="alert alert-danger">You cannot delete your own account!</div>';
    } else {
        $delete_query = "DELETE FROM users WHERE id = $delete_id";
        if(mysqli_query($conn, $delete_query)) {
            echo '<div class="alert alert-success">Employee deleted successfully!</div>';
        } else {
            echo '<div class="alert alert-danger">Error deleting employee: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total number of employees (admin users)
$total_query = "SELECT COUNT(*) as total FROM users WHERE is_admin = 1";
$total_result = mysqli_query($conn, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_records = $total_data['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get employees with pagination
$paginated_query = "SELECT * FROM users WHERE is_admin = 1 ORDER BY username LIMIT $offset, $records_per_page";
$paginated_result = mysqli_query($conn, $paginated_query);

// Search functionality
$search_query = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = sanitize_input($_GET['search']);
    $search_query = "AND (username LIKE '%$search%' OR email LIKE '%$search%' OR role LIKE '%$search%')";
    
    // Update queries with search
    $total_query = "SELECT COUNT(*) as total FROM users WHERE is_admin = 1 $search_query";
    $total_result = mysqli_query($conn, $total_query);
    $total_data = mysqli_fetch_assoc($total_result);
    $total_records = $total_data['total'];
    $total_pages = ceil($total_records / $records_per_page);
    
    $paginated_query = "SELECT * FROM users WHERE is_admin = 1 $search_query ORDER BY username LIMIT $offset, $records_per_page";
    $paginated_result = mysqli_query($conn, $paginated_query);
}
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Employee Details</h2>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
            <i class="fas fa-plus"></i> Add Employee
        </button>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <!-- Employee Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <span class="me-2">Show</span>
                        <select class="form-select form-select-sm w-auto" id="entriesSelect" onchange="changeEntries(this.value)">
                            <option value="50" <?php echo $records_per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $records_per_page == 100 ? 'selected' : ''; ?>>100</option>
                            <option value="200" <?php echo $records_per_page == 200 ? 'selected' : ''; ?>>200</option>
                        </select>
                        <span class="ms-2">entries</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <form action="" method="get" class="d-flex">
                        <input type="text" class="form-control" name="search" placeholder="Search employees..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit" class="btn btn-primary ms-2">Search</button>
                        <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
                            <a href="employee_details.php" class="btn btn-secondary ms-2">Clear</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Phone</th>
                            <th>Joined On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($paginated_result) > 0) {
                            $counter = $offset + 1;
                            while ($employee = mysqli_fetch_assoc($paginated_result)) {
                        ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo htmlspecialchars($employee['username']); ?></td>
                                <td><?php echo htmlspecialchars($employee['email']); ?></td>
                                <td><?php echo !empty($employee['role']) ? htmlspecialchars($employee['role']) : 'Admin'; ?></td>
                                <td><?php echo htmlspecialchars($employee['phone']); ?></td>
                                <td><?php echo date('d M Y', strtotime($employee['created_at'])); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewEmployeeModal<?php echo $employee['id']; ?>">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editEmployeeModal<?php echo $employee['id']; ?>">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    
                                    <?php if ($employee['id'] != $_SESSION['user_id']): ?>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $employee['id']; ?>">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                    
                                    <button type="button" class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#removeModal<?php echo $employee['id']; ?>">
                                        <i class="fas fa-times-circle"></i> Remove
                                    </button>
                                    
                                    <!-- Edit Employee Modal -->
                                    <div class="modal fade" id="editEmployeeModal<?php echo $employee['id']; ?>" tabindex="-1" aria-labelledby="editEmployeeModalLabel<?php echo $employee['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editEmployeeModalLabel<?php echo $employee['id']; ?>">Edit Employee</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="" method="post">
                                                    <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-6 mb-3">
                                                                <label for="edit_username<?php echo $employee['id']; ?>" class="form-label">Name*</label>
                                                                <input type="text" class="form-control" id="edit_username<?php echo $employee['id']; ?>" name="username" value="<?php echo htmlspecialchars($employee['username']); ?>" required>
                                                            </div>
                                                            <div class="col-md-6 mb-3">
                                                                <label for="edit_email<?php echo $employee['id']; ?>" class="form-label">Email*</label>
                                                                <input type="email" class="form-control" id="edit_email<?php echo $employee['id']; ?>" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>" required>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row">
                                                            <div class="col-md-6 mb-3">
                                                                <label for="edit_phone<?php echo $employee['id']; ?>" class="form-label">Phone</label>
                                                                <input type="text" class="form-control" id="edit_phone<?php echo $employee['id']; ?>" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>">
                                                            </div>
                                                            <div class="col-md-6 mb-3">
                                                                <label for="edit_role<?php echo $employee['id']; ?>" class="form-label">Role</label>
                                                                <select class="form-select" id="edit_role<?php echo $employee['id']; ?>" name="role">
                                                                    <option value="Admin" <?php echo $employee['role'] == 'Admin' ? 'selected' : ''; ?>>Admin</option>
                                                                    <option value="Manager" <?php echo $employee['role'] == 'Manager' ? 'selected' : ''; ?>>Manager</option>
                                                                    <option value="Sales" <?php echo $employee['role'] == 'Sales' ? 'selected' : ''; ?>>Sales</option>
                                                                    <option value="Support" <?php echo $employee['role'] == 'Support' ? 'selected' : ''; ?>>Support</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <label for="edit_address<?php echo $employee['id']; ?>" class="form-label">Address</label>
                                                            <textarea class="form-control" id="edit_address<?php echo $employee['id']; ?>" name="address" rows="3"><?php echo htmlspecialchars($employee['address']); ?></textarea>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="change_password<?php echo $employee['id']; ?>" name="change_password">
                                                                <label class="form-check-label" for="change_password<?php echo $employee['id']; ?>">
                                                                    Change Password
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                        <div id="password_fields<?php echo $employee['id']; ?>" style="display: none;">
                                                            <div class="row">
                                                                <div class="col-md-6 mb-3">
                                                                    <label for="edit_password<?php echo $employee['id']; ?>" class="form-label">New Password</label>
                                                                    <input type="password" class="form-control" id="edit_password<?php echo $employee['id']; ?>" name="password">
                                                                </div>
                                                                <div class="col-md-6 mb-3">
                                                                    <label for="edit_confirm_password<?php echo $employee['id']; ?>" class="form-label">Confirm New Password</label>
                                                                    <input type="password" class="form-control" id="edit_confirm_password<?php echo $employee['id']; ?>" name="confirm_password">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" name="edit_employee" class="btn btn-primary">Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Delete Modal -->
                                    <div class="modal fade" id="deleteModal<?php echo $employee['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $employee['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModalLabel<?php echo $employee['id']; ?>">Confirm Delete</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete employee: <strong><?php echo htmlspecialchars($employee['username']); ?></strong>?</p>
                                                    <p class="text-danger">This action cannot be undone!</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <a href="employee_details.php?delete_id=<?php echo $employee['id']; ?>" class="btn btn-danger">Delete</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- View Employee Modal -->
                                    <div class="modal fade" id="viewEmployeeModal<?php echo $employee['id']; ?>" tabindex="-1" aria-labelledby="viewEmployeeModalLabel<?php echo $employee['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="viewEmployeeModalLabel<?php echo $employee['id']; ?>">Employee Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <p><strong>Name:</strong> <?php echo htmlspecialchars($employee['username']); ?></p>
                                                            <p><strong>Email:</strong> <?php echo htmlspecialchars($employee['email']); ?></p>
                                                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($employee['phone']); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><strong>Role:</strong> <?php echo !empty($employee['role']) ? htmlspecialchars($employee['role']) : 'Admin'; ?></p>
                                                            <p><strong>Joined On:</strong> <?php echo date('d M Y h:i A', strtotime($employee['created_at'])); ?></p>
                                                            <p><strong>Last Login:</strong> <?php echo !empty($employee['last_login']) ? date('d M Y h:i A', strtotime($employee['last_login'])) : 'Never'; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p><strong>Address:</strong></p>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo !empty($employee['address']) ? nl2br(htmlspecialchars($employee['address'])) : 'No address provided'; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Remove Modal -->
                                    <div class="modal fade" id="removeModal<?php echo $employee['id']; ?>" tabindex="-1" aria-labelledby="removeModalLabel<?php echo $employee['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="removeModalLabel<?php echo $employee['id']; ?>">Remove Employee</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to remove <strong><?php echo htmlspecialchars($employee['username']); ?></strong> from the employees list?</p>
                                                    <p class="text-danger">This employee account will be deactivated but not deleted.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <a href="employee_details.php?remove_id=<?php echo $employee['id']; ?>" class="btn btn-dark">Remove Employee</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="7" class="text-center">No employees found.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Employee Modal -->
<div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEmployeeModalLabel">Add New Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Name*</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email*</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password*</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password*</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-select" id="role" name="role">
                                <option value="Admin">Admin</option>
                                <option value="Manager">Manager</option>
                                <option value="Sales">Sales</option>
                                <option value="Support">Support</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="add_employee" class="btn btn-primary">Add Employee</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function changeEntries(entries) {
        window.location.href = 'employee_details.php?entries=' + entries + '<?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>';
    }
    
    // Add event listeners for all change password checkboxes
    document.addEventListener('DOMContentLoaded', function() {
        // Get all edit modals
        const editModals = document.querySelectorAll('[id^="editEmployeeModal"]');
        
        // Add event listeners to each modal
        editModals.forEach(function(modal) {
            const modalId = modal.id;
            const employeeId = modalId.replace('editEmployeeModal', '');
            
            // Get the checkbox and password fields container
            const checkbox = modal.querySelector('#change_password' + employeeId);
            const passwordFields = modal.querySelector('#password_fields' + employeeId);
            
            // Add event listener to checkbox
            if (checkbox && passwordFields) {
                checkbox.addEventListener('change', function() {
                    passwordFields.style.display = this.checked ? 'block' : 'none';
                });
            }
        });
    });
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
