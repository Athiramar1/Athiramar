<?php
// Include necessary files
require_once 'includes/admin_header.php';
session_start();

// Redirect if not accessed via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage_orders.php');
    exit();
}

// Handle order status update
if (isset($_POST['update_status']) && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    $status = intval($_POST['status']);
    $comments = isset($_POST['comments']) ? mysqli_real_escape_string($conn, $_POST['comments']) : 'Status updated by admin';
    
    // Update order status
    $update_query = "UPDATE orders SET status = $status, updated_at = NOW() WHERE id = $order_id";
    
    if (mysqli_query($conn, $update_query)) {
        // Check if order_status_history table exists
        $check_history_table = mysqli_query($conn, "SHOW TABLES LIKE 'order_status_history'");
        
        if (mysqli_num_rows($check_history_table) > 0) {
            // Add entry to order status history
            $history_query = "INSERT INTO order_status_history (order_id, status, comments, created_at) 
                             VALUES ($order_id, $status, '$comments', NOW())";
            mysqli_query($conn, $history_query);
        } else {
            // Create the order_status_history table
            $create_history_table = "CREATE TABLE order_status_history (
                id INT PRIMARY KEY AUTO_INCREMENT,
                order_id INT NOT NULL,
                status INT NOT NULL,
                comments TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            if (mysqli_query($conn, $create_history_table)) {
                // Add entry to the newly created table
                $history_query = "INSERT INTO order_status_history (order_id, status, comments, created_at) 
                                 VALUES ($order_id, $status, '$comments', NOW())";
                mysqli_query($conn, $history_query);
            }
        }
        
        $_SESSION['success'] = "Order status updated successfully.";
    } else {
        $_SESSION['error'] = "Error updating order status: " . mysqli_error($conn);
    }
    
    header("Location: view_order.php?id=$order_id");
    exit();
}

// Handle admin notes update
if (isset($_POST['save_notes']) && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    $admin_notes = mysqli_real_escape_string($conn, $_POST['admin_notes']);
    
    // Check if admin_notes column exists
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM orders LIKE 'admin_notes'");
    
    if (mysqli_num_rows($check_column) == 0) {
        // Add admin_notes column if it doesn't exist
        mysqli_query($conn, "ALTER TABLE orders ADD COLUMN admin_notes TEXT AFTER total_amount");
    }
    
    // Update admin notes
    $update_query = "UPDATE orders SET admin_notes = '$admin_notes', updated_at = NOW() WHERE id = $order_id";
    
    if (mysqli_query($conn, $update_query)) {
        $_SESSION['success'] = "Admin notes saved successfully.";
    } else {
        $_SESSION['error'] = "Error saving admin notes: " . mysqli_error($conn);
    }
    
    header("Location: view_order.php?id=$order_id");
    exit();
}

// If we get here, something went wrong
$_SESSION['error'] = "Invalid request.";
header('Location: manage_orders.php');
exit();
?> 