<?php
// Include admin header
require_once 'includes/admin_header.php';

// Check if user ID is provided
if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    // Redirect to customers page if no ID provided
    header("Location: customer_details.php");
    exit;
}

$user_id = $_GET['user_id'];

// Get customer details
$customer_query = "SELECT * FROM users WHERE id = $user_id AND is_admin = 0";
$customer_result = mysqli_query($conn, $customer_query);

// Check if customer exists
if (mysqli_num_rows($customer_result) == 0) {
    // Redirect to customers page if customer not found
    header("Location: customer_details.php");
    exit;
}

$customer = mysqli_fetch_assoc($customer_result);

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total number of orders for this customer
$total_query = "SELECT COUNT(*) as total FROM orders WHERE user_id = $user_id";
$total_result = mysqli_query($conn, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_records = $total_data['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get orders with pagination
$paginated_query = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY created_at DESC LIMIT $offset, $records_per_page";
$paginated_result = mysqli_query($conn, $paginated_query);

// Filter by status
$status_query = '';
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status_filter = sanitize_input($_GET['status']);
    $status_query = "AND status = '$status_filter'";
    
    // Update queries with status filter
    $total_query = "SELECT COUNT(*) as total FROM orders WHERE user_id = $user_id $status_query";
    $total_result = mysqli_query($conn, $total_query);
    $total_data = mysqli_fetch_assoc($total_result);
    $total_records = $total_data['total'];
    $total_pages = ceil($total_records / $records_per_page);
    
    $paginated_query = "SELECT * FROM orders WHERE user_id = $user_id $status_query ORDER BY created_at DESC LIMIT $offset, $records_per_page";
    $paginated_result = mysqli_query($conn, $paginated_query);
}
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Orders for <?php echo htmlspecialchars($customer['username']); ?></h2>
        <a href="customer_details.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Customers
        </a>
    </div>
    
    <!-- Customer Info Card -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Customer Information</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($customer['username']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($customer['email']); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($customer['phone']); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Registered On:</strong> <?php echo date('d M Y', strtotime($customer['created_at'])); ?></p>
                    <p><strong>Total Orders:</strong> <?php echo $total_records; ?></p>
                    <p><strong>Address:</strong> <?php echo !empty($customer['address']) ? htmlspecialchars($customer['address']) : 'Not provided'; ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Orders Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <span class="me-2">Show</span>
                        <select class="form-select form-select-sm w-auto" id="entriesSelect" onchange="changeEntries(this.value)">
                            <option value="50" <?php echo $records_per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $records_per_page == 100 ? 'selected' : ''; ?>>100</option>
                            <option value="200" <?php echo $records_per_page == 200 ? 'selected' : ''; ?>>200</option>
                        </select>
                        <span class="ms-2">entries</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <select class="form-select" id="statusFilter" onchange="filterByStatus(this.value)">
                        <option value="">All Statuses</option>
                        <option value="pending" <?php echo (isset($_GET['status']) && $_GET['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="processing" <?php echo (isset($_GET['status']) && $_GET['status'] == 'processing') ? 'selected' : ''; ?>>Processing</option>
                        <option value="shipped" <?php echo (isset($_GET['status']) && $_GET['status'] == 'shipped') ? 'selected' : ''; ?>>Shipped</option>
                        <option value="delivered" <?php echo (isset($_GET['status']) && $_GET['status'] == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                        <option value="cancelled" <?php echo (isset($_GET['status']) && $_GET['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total Amount</th>
                            <th>Payment Method</th>
                            <th>Payment Status</th>
                            <th>Order Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($paginated_result) > 0) {
                            while ($order = mysqli_fetch_assoc($paginated_result)) {
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td><?php echo ucfirst($order['payment_method']); ?></td>
                                <td>
                                    <?php if ($order['payment_status'] == 'paid'): ?>
                                        <span class="badge bg-success">Paid</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    switch ($order['status']) {
                                        case 'pending':
                                            $status_class = 'bg-warning';
                                            break;
                                        case 'processing':
                                            $status_class = 'bg-info';
                                            break;
                                        case 'shipped':
                                            $status_class = 'bg-primary';
                                            break;
                                        case 'delivered':
                                            $status_class = 'bg-success';
                                            break;
                                        case 'cancelled':
                                            $status_class = 'bg-danger';
                                            break;
                                        default:
                                            $status_class = 'bg-secondary';
                                    }
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span>
                                </td>
                                <td>
                                    <a href="view_order.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="print_invoice.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-success" target="_blank">
                                        <i class="fas fa-print"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="7" class="text-center">No orders found for this customer.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?user_id=<?php echo $user_id; ?>&page=<?php echo $page - 1; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['status']) ? '&status=' . urlencode($_GET['status']) : ''; ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?user_id=<?php echo $user_id; ?>&page=<?php echo $i; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['status']) ? '&status=' . urlencode($_GET['status']) : ''; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?user_id=<?php echo $user_id; ?>&page=<?php echo $page + 1; ?>&entries=<?php echo $records_per_page; ?><?php echo isset($_GET['status']) ? '&status=' . urlencode($_GET['status']) : ''; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Order Summary -->
    <div class="card mt-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Order Summary</h5>
        </div>
        <div class="card-body">
            <?php
            // Get order summary by status
            $summary_query = "SELECT status, COUNT(*) as count, SUM(total_amount) as total 
                             FROM orders 
                             WHERE user_id = $user_id 
                             GROUP BY status";
            $summary_result = mysqli_query($conn, $summary_query);
            
            // Get total spent
            $total_spent_query = "SELECT SUM(total_amount) as total_spent FROM orders WHERE user_id = $user_id";
            $total_spent_result = mysqli_query($conn, $total_spent_query);
            $total_spent_data = mysqli_fetch_assoc($total_spent_result);
            ?>
            
            <div class="row">
                <?php
                $status_colors = [
                    'pending' => 'warning',
                    'processing' => 'info',
                    'shipped' => 'primary',
                    'delivered' => 'success',
                    'cancelled' => 'danger'
                ];
                
                while ($summary = mysqli_fetch_assoc($summary_result)) {
                    $status = $summary['status'];
                    $color = isset($status_colors[$status]) ? $status_colors[$status] : 'secondary';
                ?>
                <div class="col-md-4 mb-3">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo ucfirst($status); ?> Orders</h5>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-<?php echo $color; ?> fs-5"><?php echo $summary['count']; ?></span>
                                <span class="fs-5">₹<?php echo number_format($summary['total'], 2); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
                <div class="col-md-4 mb-3">
                    <div class="card bg-dark text-white">
                        <div class="card-body">
                            <h5 class="card-title">Total Spent</h5>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-light text-dark fs-5"><?php echo $total_records; ?> Orders</span>
                                <span class="fs-5">₹<?php echo number_format($total_spent_data['total_spent'], 2); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function changeEntries(entries) {
        let url = new URL(window.location.href);
        url.searchParams.set('entries', entries);
        window.location.href = url.toString();
    }
    
    function filterByStatus(status) {
        let url = new URL(window.location.href);
        if (status) {
            url.searchParams.set('status', status);
        } else {
            url.searchParams.delete('status');
        }
        window.location.href = url.toString();
    }
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
