<?php
// Include admin header
require_once 'includes/admin_header.php';

// Check if category ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Redirect to categories page if no ID provided
    header("Location: manage_category.php");
    exit;
}

$category_id = $_GET['id'];

// Get category details
$category_query = "SELECT * FROM categories WHERE id = $category_id";
$category_result = mysqli_query($conn, $category_query);

// Check if category exists
if (mysqli_num_rows($category_result) == 0) {
    // Redirect to categories page if category not found
    header("Location: manage_category.php");
    exit;
}

$category = mysqli_fetch_assoc($category_result);

// Process form submission for updating category
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_category'])) {
    $category_name = sanitize_input($_POST['category_name']);
    
    if (empty($category_name)) {
        $message = '<div class="alert alert-danger">Please enter category name.</div>';
    } else {
        // Check if category name already exists (excluding current category)
        $check_query = "SELECT * FROM categories WHERE name = '$category_name' AND id != $category_id";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $message = '<div class="alert alert-danger">Category name already exists.</div>';
        } else {
            // Update category
            $update_query = "UPDATE categories SET name = '$category_name' WHERE id = $category_id";
            if (mysqli_query($conn, $update_query)) {
                $message = '<div class="alert alert-success">Category updated successfully.</div>';
                // Refresh category data
                $category_result = mysqli_query($conn, $category_query);
                $category = mysqli_fetch_assoc($category_result);
            } else {
                $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
            }
        }
    }
}
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Edit Category</h2>
        <a href="manage_category.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Categories
        </a>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <!-- Edit Category Form -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Edit Category Details</h5>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <div class="mb-3">
                    <label for="category_name" class="form-label">Category Name</label>
                    <input type="text" class="form-control" id="category_name" name="category_name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Created On</label>
                    <input type="text" class="form-control" value="<?php echo date('d M Y', strtotime($category['created_at'])); ?>" readonly>
                </div>
                <button type="submit" name="update_category" class="btn btn-primary">Update Category</button>
            </form>
        </div>
    </div>
    
    <!-- Category Products -->
    <div class="card mt-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Products in this Category</h5>
        </div>
        <div class="card-body">
            <?php
            // Get products in this category
            $products_query = "SELECT * FROM products WHERE category_id = $category_id ORDER BY name";
            $products_result = mysqli_query($conn, $products_query);
            
            if (mysqli_num_rows($products_result) > 0) {
            ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Code</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $counter = 1;
                            while ($product = mysqli_fetch_assoc($products_result)) {
                            ?>
                                <tr>
                                    <td><?php echo $counter++; ?></td>
                                    <td><?php echo htmlspecialchars($product['code']); ?></td>
                                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td>₹<?php echo number_format($product['price'], 2); ?></td>
                                    <td>
                                        <?php if ($product['stock'] < 10): ?>
                                            <span class="badge bg-danger"><?php echo $product['stock']; ?></span>
                                        <?php elseif ($product['stock'] < 20): ?>
                                            <span class="badge bg-warning"><?php echo $product['stock']; ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-success"><?php echo $product['stock']; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            <?php
            } else {
                echo '<div class="alert alert-info">No products found in this category.</div>';
            }
            ?>
        </div>
    </div>
</div>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
