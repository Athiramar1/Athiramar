<?php
// Include database connection
require_once 'includes/db_connection.php';

// Check if the 'code' column exists in the products table
$check_column_query = "SHOW COLUMNS FROM products LIKE 'code'";
$column_result = mysqli_query($conn, $check_column_query);

if (mysqli_num_rows($column_result) == 0) {
    // Add 'code' column if it doesn't exist
    $add_column_query = "ALTER TABLE products ADD COLUMN code VARCHAR(50) UNIQUE AFTER name";
    
    if (mysqli_query($conn, $add_column_query)) {
        // Generate and update product codes for existing products
        $update_query = "UPDATE products SET code = CONCAT('PROD', id) WHERE code IS NULL";
        if (mysqli_query($conn, $update_query)) {
            echo "The 'code' column has been added to the products table and product codes have been updated successfully.";
        } else {
            echo "Error updating product codes: " . mysqli_error($conn);
        }
    } else {
        echo "Error adding 'code' column: " . mysqli_error($conn);
    }
} else {
    echo "The 'code' column already exists in the products table.";
}

// Redirect back to reports page after execution
header("Location: reports.php");
exit;
?> 