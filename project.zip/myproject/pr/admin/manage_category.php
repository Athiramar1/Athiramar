<?php
// Include admin header
require_once 'includes/admin_header.php';

// Process form submission for adding new category
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $category_name = sanitize_input($_POST['category_name']);
    
    if (empty($category_name)) {
        $message = '<div class="alert alert-danger">Please enter category name.</div>';
    } else {
        // Check if category already exists
        $check_query = "SELECT * FROM categories WHERE name = '$category_name'";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $message = '<div class="alert alert-danger">Category already exists.</div>';
        } else {
            // Insert new category
            $insert_query = "INSERT INTO categories (name) VALUES ('$category_name')";
            if (mysqli_query($conn, $insert_query)) {
                $message = '<div class="alert alert-success">Category added successfully.</div>';
            } else {
                $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
            }
        }
    }
}

// Process category deletion
if (isset($_GET['delete'])) {
    $category_id = $_GET['delete'];
    
    // Check if category has products
    $check_products = "SELECT COUNT(*) as product_count FROM products WHERE category_id = $category_id";
    $product_result = mysqli_query($conn, $check_products);
    $product_data = mysqli_fetch_assoc($product_result);
    
    if ($product_data['product_count'] > 0) {
        $message = '<div class="alert alert-danger">Cannot delete category. It has products associated with it.</div>';
    } else {
        // Delete category
        $delete_query = "DELETE FROM categories WHERE id = $category_id";
        if (mysqli_query($conn, $delete_query)) {
            $message = '<div class="alert alert-success">Category deleted successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Get categories from database
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_query);

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total number of categories
$total_query = "SELECT COUNT(*) as total FROM categories";
$total_result = mysqli_query($conn, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_records = $total_data['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get categories with pagination
$paginated_query = "SELECT * FROM categories ORDER BY name LIMIT $offset, $records_per_page";
$paginated_result = mysqli_query($conn, $paginated_query);
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Manage Categories</h2>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
            <i class="fas fa-plus"></i> Add Category
        </button>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <!-- Category Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <span class="me-2">Show</span>
                        <select class="form-select form-select-sm w-auto" id="entriesSelect" onchange="changeEntries(this.value)">
                            <option value="50" <?php echo $records_per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $records_per_page == 100 ? 'selected' : ''; ?>>100</option>
                            <option value="200" <?php echo $records_per_page == 200 ? 'selected' : ''; ?>>200</option>
                        </select>
                        <span class="ms-2">entries</span>
                    </div>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Product Category</th>
                            <th>Created On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($paginated_result) > 0) {
                            $counter = $offset + 1;
                            while ($category = mysqli_fetch_assoc($paginated_result)) {
                        ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo htmlspecialchars($category['name']); ?></td>
                                <td><?php echo date('d M Y', strtotime($category['created_at'])); ?></td>
                                <td>
                                    <a href="manage_category.php?delete=<?php echo $category['id']; ?>" class="btn btn-sm btn-danger delete-btn" onclick="return confirm('Are you sure you want to delete this category?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="4" class="text-center">No categories found.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&entries=<?php echo $records_per_page; ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&entries=<?php echo $records_per_page; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&entries=<?php echo $records_per_page; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Category Modal -->
<div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCategoryModalLabel">Add New Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="category_name" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="category_name" name="category_name" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function changeEntries(entries) {
        window.location.href = 'manage_category.php?entries=' + entries;
    }
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
