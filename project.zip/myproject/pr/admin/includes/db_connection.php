<?php
/**
 * Database Connection
 * 
 * This file establishes a connection to the MySQL database
 * for the Offset Printing Shop admin panel.
 */

// Database configuration
$db_host = 'localhost';
$db_user = 'root';     // Change to your MySQL username
$db_password = '';     // Change to your MySQL password
$db_name = 'offset_printing';

// Create connection
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set character set
mysqli_set_charset($conn, "utf8mb4");
?>
