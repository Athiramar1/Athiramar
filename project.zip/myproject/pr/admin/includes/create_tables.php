<?php
// Include database connection
require_once 'db_connection.php';

// Create order_status table
$create_order_status = "CREATE TABLE IF NOT EXISTS `order_status` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(50) NOT NULL,
    `color` varchar(20) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Create service_status table
$create_service_status = "CREATE TABLE IF NOT EXISTS `service_status` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(50) NOT NULL,
    `color` varchar(20) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Create service_messages table
$create_service_messages = "CREATE TABLE IF NOT EXISTS `service_messages` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `service_order_id` int(11) NOT NULL,
    `message` text NOT NULL,
    `is_admin` tinyint(1) NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    KEY `service_order_id` (`service_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute queries
if (mysqli_query($conn, $create_order_status)) {
    echo "order_status table created successfully<br>";
    
    // Insert default statuses
    $insert_order_statuses = "INSERT INTO `order_status` (`id`, `name`, `color`) VALUES
        (1, 'Pending', 'warning'),
        (2, 'Processing', 'primary'),
        (3, 'Shipped', 'info'),
        (4, 'Delivered', 'success'),
        (5, 'Cancelled', 'danger');";
    
    if (mysqli_query($conn, $insert_order_statuses)) {
        echo "Default order statuses inserted successfully<br>";
    } else {
        echo "Error inserting default order statuses: " . mysqli_error($conn) . "<br>";
    }
} else {
    echo "Error creating order_status table: " . mysqli_error($conn) . "<br>";
}

if (mysqli_query($conn, $create_service_status)) {
    echo "service_status table created successfully<br>";
    
    // Insert default statuses
    $insert_service_statuses = "INSERT INTO `service_status` (`id`, `name`, `color`) VALUES
        (1, 'Pending', 'warning'),
        (2, 'Confirmed', 'primary'),
        (3, 'Awaiting Customer', 'info'),
        (4, 'Customer Replied', 'secondary'),
        (5, 'In Progress', 'primary'),
        (6, 'Completed', 'success'),
        (7, 'Cancelled', 'danger');";
    
    if (mysqli_query($conn, $insert_service_statuses)) {
        echo "Default service statuses inserted successfully<br>";
    } else {
        echo "Error inserting default service statuses: " . mysqli_error($conn) . "<br>";
    }
} else {
    echo "Error creating service_status table: " . mysqli_error($conn) . "<br>";
}

if (mysqli_query($conn, $create_service_messages)) {
    echo "service_messages table created successfully<br>";
} else {
    echo "Error creating service_messages table: " . mysqli_error($conn) . "<br>";
}

echo "<p>Tables setup completed. <a href='../index.php'>Go to Dashboard</a></p>";
?> 