<?php
/**
 * Utility Functions
 * 
 * This file contains helper functions used throughout the admin panel
 * for the Offset Printing Shop.
 */

/**
 * Get a setting from the settings table
 *
 * @param string $key The setting key to retrieve
 * @param string $default Default value if setting doesn't exist
 * @return string The setting value or default
 */
function get_setting($key, $default = '') {
    global $conn;
    
    // Check if settings table exists
    $table_check_query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'offset_printing' AND table_name = 'settings'";
    $table_check_result = mysqli_query($conn, $table_check_query);
    $table_exists = mysqli_fetch_array($table_check_result)[0];
    
    if (!$table_exists) {
        return $default;
    }
    
    $key = sanitize_input($key);
    $query = "SELECT setting_value FROM settings WHERE setting_key = '$key' LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['setting_value'];
    }
    
    return $default;
}

/**
 * Sanitize user input to prevent SQL injection and XSS attacks
 * 
 * @param string $data The input data to sanitize
 * @return string The sanitized data
 */
if (!function_exists('sanitize_input')) {
    function sanitize_input($data) {
        global $conn;
        
        // Remove whitespace from beginning and end
        $data = trim($data);
        
        // Remove backslashes
        $data = stripslashes($data);
        
        // Convert HTML special characters
        $data = htmlspecialchars($data);
        
        // Escape special characters for SQL
        if ($conn) {
            $data = mysqli_real_escape_string($conn, $data);
        }
        
        return $data;
    }
}

/**
 * Generate a random string
 * 
 * @param int $length The length of the string to generate
 * @return string The generated random string
 */
function generate_random_string($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    
    return $randomString;
}

/**
 * Format date and time
 * 
 * @param string $datetime The datetime string to format
 * @param string $format The format to use (default: 'd M Y, h:i A')
 * @return string The formatted date and time
 */
function format_datetime($datetime, $format = 'd M Y, h:i A') {
    $date = new DateTime($datetime);
    return $date->format($format);
}

/**
 * Format currency
 * 
 * @param float $amount The amount to format
 * @param string $currency The currency symbol (default: '₹')
 * @return string The formatted currency
 */
function format_currency($amount, $currency = '₹') {
    return $currency . ' ' . number_format($amount, 2);
}

/**
 * Check if user has admin privileges
 * 
 * @return bool True if user is admin, false otherwise
 */
function is_admin() {
    return isset($_SESSION['user_id']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

/**
 * Redirect to another page
 * 
 * @param string $url The URL to redirect to
 * @return void
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Generate pagination links
 * 
 * @param int $total_records Total number of records
 * @param int $records_per_page Number of records per page
 * @param int $current_page Current page number
 * @param string $url Base URL for pagination links
 * @return string HTML for pagination links
 */
function generate_pagination($total_records, $records_per_page, $current_page, $url) {
    $total_pages = ceil($total_records / $records_per_page);
    
    if ($total_pages <= 1) {
        return '';
    }
    
    $pagination = '<nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">';
    
    // Previous button
    if ($current_page > 1) {
        $pagination .= '<li class="page-item">
                            <a class="page-link" href="' . $url . '&page=' . ($current_page - 1) . '" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>';
    } else {
        $pagination .= '<li class="page-item disabled">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>';
    }
    
    // Page numbers
    $start_page = max(1, $current_page - 2);
    $end_page = min($total_pages, $current_page + 2);
    
    if ($start_page > 1) {
        $pagination .= '<li class="page-item"><a class="page-link" href="' . $url . '&page=1">1</a></li>';
        if ($start_page > 2) {
            $pagination .= '<li class="page-item disabled"><a class="page-link" href="#">...</a></li>';
        }
    }
    
    for ($i = $start_page; $i <= $end_page; $i++) {
        if ($i == $current_page) {
            $pagination .= '<li class="page-item active"><a class="page-link" href="#">' . $i . '</a></li>';
        } else {
            $pagination .= '<li class="page-item"><a class="page-link" href="' . $url . '&page=' . $i . '">' . $i . '</a></li>';
        }
    }
    
    if ($end_page < $total_pages) {
        if ($end_page < $total_pages - 1) {
            $pagination .= '<li class="page-item disabled"><a class="page-link" href="#">...</a></li>';
        }
        $pagination .= '<li class="page-item"><a class="page-link" href="' . $url . '&page=' . $total_pages . '">' . $total_pages . '</a></li>';
    }
    
    // Next button
    if ($current_page < $total_pages) {
        $pagination .= '<li class="page-item">
                            <a class="page-link" href="' . $url . '&page=' . ($current_page + 1) . '" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>';
    } else {
        $pagination .= '<li class="page-item disabled">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>';
    }
    
    $pagination .= '</ul></nav>';
    
    return $pagination;
}

/**
 * Upload file with validation
 * 
 * @param array $file The $_FILES array element
 * @param string $upload_dir The directory to upload to
 * @param array $allowed_types Array of allowed MIME types
 * @param int $max_size Maximum file size in bytes
 * @return array Array with status and message/filename
 */
function upload_file($file, $upload_dir, $allowed_types = [], $max_size = 2097152) {
    // Check if file was uploaded without errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error_messages = [
            UPLOAD_ERR_INI_SIZE => 'The uploaded file exceeds the upload_max_filesize directive in php.ini',
            UPLOAD_ERR_FORM_SIZE => 'The uploaded file exceeds the MAX_FILE_SIZE directive in the HTML form',
            UPLOAD_ERR_PARTIAL => 'The uploaded file was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
        ];
        
        $error_message = isset($error_messages[$file['error']]) ? $error_messages[$file['error']] : 'Unknown upload error';
        return ['status' => false, 'message' => $error_message];
    }
    
    // Check file size
    if ($file['size'] > $max_size) {
        return ['status' => false, 'message' => 'File size exceeds the maximum limit of ' . ($max_size / 1024 / 1024) . 'MB'];
    }
    
    // Check file type
    if (!empty($allowed_types) && !in_array($file['type'], $allowed_types)) {
        return ['status' => false, 'message' => 'File type not allowed. Allowed types: ' . implode(', ', $allowed_types)];
    }
    
    // Create upload directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Generate unique filename
    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
    $upload_path = $upload_dir . '/' . $new_filename;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        return ['status' => true, 'filename' => $new_filename, 'path' => $upload_path];
    } else {
        return ['status' => false, 'message' => 'Failed to move uploaded file'];
    }
}

/**
 * Log user activity
 * 
 * @param int $user_id The user ID
 * @param string $action The action performed
 * @param string $details Additional details about the action
 * @return bool True if logged successfully, false otherwise
 */
function log_activity($user_id, $action, $details = '') {
    global $conn;
    
    // Check if activity_log table exists
    $table_check_query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'offset_printing' AND table_name = 'activity_log'";
    $table_check_result = mysqli_query($conn, $table_check_query);
    $table_exists = mysqli_fetch_array($table_check_result)[0];
    
    // Create table if it doesn't exist
    if (!$table_exists) {
        $create_table_query = "CREATE TABLE activity_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            action VARCHAR(100) NOT NULL,
            details TEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        )";
        
        if (!mysqli_query($conn, $create_table_query)) {
            return false;
        }
    }
    
    // Get IP address and user agent
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    // Sanitize inputs
    $user_id = (int)$user_id;
    $action = sanitize_input($action);
    $details = sanitize_input($details);
    $ip_address = sanitize_input($ip_address);
    $user_agent = sanitize_input($user_agent);
    
    // Insert log entry
    $query = "INSERT INTO activity_log (user_id, action, details, ip_address, user_agent) 
              VALUES ($user_id, '$action', '$details', '$ip_address', '$user_agent')";
    
    return mysqli_query($conn, $query);
}

?>
