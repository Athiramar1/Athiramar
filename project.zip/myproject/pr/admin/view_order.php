<?php
// Include admin header
require_once 'includes/admin_header.php';

// Check if order ID is provided
if (!isset($_GET['id']) && !isset($_GET['order_id'])) {
    echo '<div class="alert alert-danger">No order ID provided.</div>';
    echo '<a href="manage_orders.php" class="btn btn-primary">Back to Orders</a>';
    exit;
}

$order_id = isset($_GET['id']) ? intval($_GET['id']) : intval($_GET['order_id']);

// Get order details
$order_query = "SELECT o.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
               CASE o.status 
                   WHEN 1 THEN 'Pending' 
                   WHEN 2 THEN 'Processing' 
                   WHEN 3 THEN 'Shipped' 
                   WHEN 4 THEN 'Delivered' 
                   WHEN 5 THEN 'Cancelled'
                   ELSE 'Unknown' 
               END as status_name,
               CASE o.status 
                   WHEN 1 THEN 'warning' 
                   WHEN 2 THEN 'primary' 
                   WHEN 3 THEN 'info' 
                   WHEN 4 THEN 'success' 
                   WHEN 5 THEN 'danger'
                   ELSE 'secondary' 
               END as status_color
               FROM orders o
               LEFT JOIN users u ON o.user_id = u.id
               WHERE o.id = $order_id";
$order_result = mysqli_query($conn, $order_query);

if (mysqli_num_rows($order_result) == 0) {
    echo '<div class="alert alert-danger">Order not found.</div>';
    echo '<a href="manage_orders.php" class="btn btn-primary">Back to Orders</a>';
    exit;
}

$order = mysqli_fetch_assoc($order_result);

// Get order items
$items_query = "SELECT oi.*, p.name as product_name, p.code as product_code, p.description as product_description, p.image as product_image
               FROM order_items oi
               LEFT JOIN products p ON oi.product_id = p.id
               WHERE oi.order_id = $order_id";
$items_result = mysqli_query($conn, $items_query);

// Check if order_status_history table exists
$check_history_table = mysqli_query($conn, "SHOW TABLES LIKE 'order_status_history'");
$history_table_exists = mysqli_num_rows($check_history_table) > 0;

// Get order status history if available
if ($history_table_exists) {
    $history_query = "SELECT * FROM order_status_history WHERE order_id = $order_id ORDER BY created_at DESC";
    $history_result = mysqli_query($conn, $history_query);
    $has_history = ($history_result && mysqli_num_rows($history_result) > 0);
} else {
    $has_history = false;
}

// Check if admin_notes column exists in orders table
$check_notes = mysqli_query($conn, "SHOW COLUMNS FROM orders LIKE 'admin_notes'");
if (mysqli_num_rows($check_notes) == 0) {
    // Add admin_notes column
    mysqli_query($conn, "ALTER TABLE orders ADD COLUMN admin_notes TEXT AFTER total_amount");
}
?>

<div class="container-fluid px-4 mt-4">
    <h1 class="mt-4">Order Details</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="manage_orders.php">Orders</a></li>
        <li class="breadcrumb-item active">Order #<?php echo $order['order_number']; ?></li>
    </ol>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-file-invoice me-1"></i>
                Order #<?php echo $order['order_number']; ?>
            </div>
            <div>
                <a href="manage_orders.php" class="btn btn-primary btn-sm">Back to Orders</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-6">
                    <h5 class="card-title mb-3">Order Information</h5>
                    <table class="table table-borderless">
                        <tr>
                            <th width="150">Order Number:</th>
                            <td><?php echo $order['order_number']; ?></td>
                        </tr>
                        <tr>
                            <th>Date:</th>
                            <td><?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></td>
                        </tr>
                        <tr>
                            <th>Status:</th>
                            <td><span class="badge bg-<?php echo $order['status_color']; ?>"><?php echo $order['status_name']; ?></span></td>
                        </tr>
                        <tr>
                            <th>Total Amount:</th>
                            <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h5 class="card-title mb-3">Customer Information</h5>
                    <table class="table table-borderless">
                        <tr>
                            <th width="150">Name:</th>
                            <td><?php echo $order['customer_name']; ?></td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo $order['customer_email']; ?></td>
                        </tr>
                        <?php if (!empty($order['customer_phone'])): ?>
                        <tr>
                            <th>Phone:</th>
                            <td><?php echo $order['customer_phone']; ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($order['shipping_address'])): ?>
                        <tr>
                            <th>Shipping Address:</th>
                            <td><?php echo nl2br($order['shipping_address']); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($order['billing_address'])): ?>
                        <tr>
                            <th>Billing Address:</th>
                            <td><?php echo nl2br($order['billing_address']); ?></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            
            <h5 class="card-title mb-3">Order Items</h5>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th width="80">Image</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $subtotal = 0;
                        while ($item = mysqli_fetch_assoc($items_result)): 
                            $product_name = !empty($item['product_name']) ? $item['product_name'] : $item['product_name'];
                            $item_total = $item['price'] * $item['quantity'];
                            $subtotal += $item_total;
                        ?>
                        <tr>
                            <td>
                                <?php if (!empty($item['product_image'])): ?>
                                    <img src="../<?php echo $item['product_image']; ?>" alt="<?php echo $product_name; ?>" class="img-thumbnail" width="60">
                                <?php else: ?>
                                    <img src="../assets/images/product-placeholder.jpg" alt="<?php echo $product_name; ?>" class="img-thumbnail" width="60">
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo $product_name; ?></strong>
                                <?php if (!empty($item['product_code'])): ?>
                                    <br><small>SKU: <?php echo $item['product_code']; ?></small>
                                <?php endif; ?>
                                <?php if (!empty($item['product_description'])): ?>
                                    <br><small class="text-muted"><?php echo substr($item['product_description'], 0, 100); ?><?php echo (strlen($item['product_description']) > 100) ? '...' : ''; ?></small>
                                <?php endif; ?>
                            </td>
                            <td>₹<?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>₹<?php echo number_format($item_total, 2); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                            <td>₹<?php echo number_format($subtotal, 2); ?></td>
                        </tr>
                        <?php if (!empty($order['shipping_cost'])): ?>
                        <tr>
                            <td colspan="4" class="text-end"><strong>Shipping:</strong></td>
                            <td>₹<?php echo number_format($order['shipping_cost'], 2); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($order['tax_amount'])): ?>
                        <tr>
                            <td colspan="4" class="text-end"><strong>Tax:</strong></td>
                            <td>₹<?php echo number_format($order['tax_amount'], 2); ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="4" class="text-end"><strong>Grand Total:</strong></td>
                            <td><strong>₹<?php echo number_format($order['total_amount'], 2); ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <?php if ($has_history): ?>
            <h5 class="card-title mt-4 mb-3">Order Status History</h5>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Comments</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($history = mysqli_fetch_assoc($history_result)): ?>
                        <tr>
                            <td><?php echo date('d M Y, h:i A', strtotime($history['created_at'])); ?></td>
                            <td>
                                <?php 
                                $status_name = '';
                                $status_color = '';
                                switch ($history['status']) {
                                    case 1: $status_name = 'Pending'; $status_color = 'warning'; break;
                                    case 2: $status_name = 'Processing'; $status_color = 'primary'; break;
                                    case 3: $status_name = 'Shipped'; $status_color = 'info'; break;
                                    case 4: $status_name = 'Delivered'; $status_color = 'success'; break;
                                    case 5: $status_name = 'Cancelled'; $status_color = 'danger'; break;
                                    default: $status_name = 'Unknown'; $status_color = 'secondary'; break;
                                }
                                ?>
                                <span class="badge bg-<?php echo $status_color; ?>"><?php echo $status_name; ?></span>
                            </td>
                            <td><?php echo $history['comments']; ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <h5 class="card-title mb-3">Update Order Status</h5>
                    <form action="process_order.php" method="post">
                        <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                        <div class="row mb-3">
                            <div class="col-md-8">
                                <select name="status" class="form-select">
                                    <option value="1" <?php echo ($order['status'] == 1) ? 'selected' : ''; ?>>Pending</option>
                                    <option value="2" <?php echo ($order['status'] == 2) ? 'selected' : ''; ?>>Processing</option>
                                    <option value="3" <?php echo ($order['status'] == 3) ? 'selected' : ''; ?>>Shipped</option>
                                    <option value="4" <?php echo ($order['status'] == 4) ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="5" <?php echo ($order['status'] == 5) ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="comments" class="form-label">Comments</label>
                            <textarea name="comments" id="comments" class="form-control" rows="3"></textarea>
                            <div class="form-text">Internal comments about this status change</div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <h5 class="card-title mb-3">Admin Notes</h5>
                    <form action="process_order.php" method="post">
                        <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                        <div class="mb-3">
                            <textarea name="admin_notes" class="form-control" rows="5"><?php echo isset($order['admin_notes']) ? $order['admin_notes'] : ''; ?></textarea>
                            <div class="form-text">These notes are only visible to administrators</div>
                        </div>
                        <button type="submit" name="save_notes" class="btn btn-secondary">Save Notes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin_footer.php'; ?> 