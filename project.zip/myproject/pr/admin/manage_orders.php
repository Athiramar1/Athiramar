<?php
// Include admin header
require_once 'includes/admin_header.php';

// Check if admin is viewing a specific order from user side
if (isset($_GET['view_order']) && !empty($_GET['view_order'])) {
    $order_id = intval($_GET['view_order']);
    
    // Get order details
    $order_query = "SELECT o.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
                   CASE o.status 
                       WHEN 1 THEN 'Pending' 
                       WHEN 2 THEN 'Processing' 
                       WHEN 3 THEN 'Shipped' 
                       WHEN 4 THEN 'Delivered' 
                       WHEN 5 THEN 'Cancelled'
                       ELSE 'Unknown' 
                   END as status_name
                   FROM orders o
                   LEFT JOIN users u ON o.user_id = u.id
                   WHERE o.id = $order_id";
    $order_result = mysqli_query($conn, $order_query);
    
    if (mysqli_num_rows($order_result) > 0) {
        $order = mysqli_fetch_assoc($order_result);
        
        // Get order items
        $items_query = "SELECT oi.*, p.name as product_name, p.code as product_code, p.description as product_description, p.image as product_image
                       FROM order_items oi
                       LEFT JOIN products p ON oi.product_id = p.id
                       WHERE oi.order_id = $order_id";
        $items_result = mysqli_query($conn, $items_query);
        
        // Display order details
        ?>
        <div class="container-fluid px-4 mt-4">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between">
                    <div>
                        <i class="fas fa-table me-1"></i>
                        Order #<?php echo $order['order_number']; ?> Details
                    </div>
                    <div>
                        <a href="manage_orders.php" class="btn btn-sm btn-primary">Back to Orders</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5 class="mb-3">Order Information</h5>
                            <p><strong>Order Number:</strong> <?php echo $order['order_number']; ?></p>
                            <p><strong>Order Date:</strong> <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>
                            <p><strong>Status:</strong> <span class="badge bg-<?php echo get_status_color($order['status']); ?>"><?php echo $order['status_name']; ?></span></p>
                            <p><strong>Total Amount:</strong> ₹<?php echo number_format($order['total_amount'], 2); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h5 class="mb-3">Customer Information</h5>
                            <p><strong>Name:</strong> <?php echo $order['customer_name']; ?></p>
                            <p><strong>Email:</strong> <?php echo $order['customer_email']; ?></p>
                            <?php if (!empty($order['customer_phone'])): ?>
                            <p><strong>Phone:</strong> <?php echo $order['customer_phone']; ?></p>
                            <?php endif; ?>
                            <?php if (!empty($order['shipping_address'])): ?>
                            <p><strong>Shipping Address:</strong> <?php echo nl2br($order['shipping_address']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <h5 class="mb-3">Order Items</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="80">Image</th>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $subtotal = 0;
                                while ($item = mysqli_fetch_assoc($items_result)): 
                                    $product_name = !empty($item['product_name']) ? $item['product_name'] : $item['product_name'];
                                    $item_total = $item['price'] * $item['quantity'];
                                    $subtotal += $item_total;
                                ?>
                                <tr>
                                    <td>
                                        <?php if (!empty($item['product_image'])): ?>
                                            <img src="../<?php echo $item['product_image']; ?>" alt="<?php echo $product_name; ?>" class="img-thumbnail" width="70">
                                        <?php else: ?>
                                            <img src="../assets/images/product-placeholder.jpg" alt="<?php echo $product_name; ?>" class="img-thumbnail" width="70">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div><strong><?php echo $product_name; ?></strong></div>
                                        <?php if (!empty($item['product_code'])): ?>
                                            <small>SKU: <?php echo $item['product_code']; ?></small><br>
                                        <?php endif; ?>
                                        <?php if (!empty($item['product_description'])): ?>
                                            <small class="text-muted"><?php echo substr($item['product_description'], 0, 100); ?><?php echo (strlen($item['product_description']) > 100) ? '...' : ''; ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>₹<?php echo number_format($item_total, 2); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Total:</strong></td>
                                    <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <h5 class="mb-3">Update Order Status</h5>
                            <form action="manage_orders.php" method="post">
                                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                                <div class="row g-3">
                                    <div class="col-md-8">
                                        <select name="status" class="form-select">
                                            <option value="1" <?php echo ($order['status'] == 1) ? 'selected' : ''; ?>>Pending</option>
                                            <option value="2" <?php echo ($order['status'] == 2) ? 'selected' : ''; ?>>Processing</option>
                                            <option value="3" <?php echo ($order['status'] == 3) ? 'selected' : ''; ?>>Shipped</option>
                                            <option value="4" <?php echo ($order['status'] == 4) ? 'selected' : ''; ?>>Delivered</option>
                                            <option value="5" <?php echo ($order['status'] == 5) ? 'selected' : ''; ?>>Cancelled</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <h5 class="mb-3">Admin Notes</h5>
                            <form action="manage_orders.php" method="post">
                                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                                <div class="mb-3">
                                    <textarea name="admin_notes" class="form-control" rows="3" placeholder="Add notes about this order (only visible to admin)"><?php echo isset($order['admin_notes']) ? $order['admin_notes'] : ''; ?></textarea>
                                </div>
                                <button type="submit" name="update_notes" class="btn btn-secondary">Save Notes</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return; // End processing here
    } else {
        echo '<div class="alert alert-danger">Order not found.</div>';
    }
}

// Handle order status update
if (isset($_POST['update_status']) && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    $status = intval($_POST['status']);
    
    // Update order status
    $update_query = "UPDATE orders SET status = $status, updated_at = NOW() WHERE id = $order_id";
    if (mysqli_query($conn, $update_query)) {
        // Add to order history
        $check_history_table = mysqli_query($conn, "SHOW TABLES LIKE 'order_status_history'");
        if (mysqli_num_rows($check_history_table) > 0) {
            $comments = "Status updated by admin";
            $history_query = "INSERT INTO order_status_history (order_id, status, comments, created_at) 
                            VALUES ($order_id, $status, '$comments', NOW())";
            mysqli_query($conn, $history_query);
        }
        
        echo '<div class="alert alert-success">Order status updated successfully.</div>';
    } else {
        echo '<div class="alert alert-danger">Error updating order status: ' . mysqli_error($conn) . '</div>';
    }
}

// Handle admin notes update
if (isset($_POST['update_notes']) && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    $admin_notes = mysqli_real_escape_string($conn, $_POST['admin_notes']);
    
    // Check if admin_notes column exists
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM orders LIKE 'admin_notes'");
    if (mysqli_num_rows($check_column) == 0) {
        // Add admin_notes column if it doesn't exist
        mysqli_query($conn, "ALTER TABLE orders ADD COLUMN admin_notes TEXT");
    }
    
    // Update admin notes
    $update_query = "UPDATE orders SET admin_notes = '$admin_notes', updated_at = NOW() WHERE id = $order_id";
    if (mysqli_query($conn, $update_query)) {
        echo '<div class="alert alert-success">Admin notes updated successfully.</div>';
    } else {
        echo '<div class="alert alert-danger">Error updating admin notes: ' . mysqli_error($conn) . '</div>';
    }
}

// Check if orders table exists
$table_check_query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'offset_printing' AND table_name = 'orders'";
$table_check_result = mysqli_query($conn, $table_check_query);
$table_exists = mysqli_fetch_array($table_check_result)[0];

if (!$table_exists) {
    // Create orders table
    $create_orders_table = "CREATE TABLE `orders` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `order_number` varchar(50) NOT NULL,
        `total_amount` decimal(10,2) NOT NULL,
        `status` enum('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    mysqli_query($conn, $create_orders_table);
    
    // Check if order_items table exists
    $order_items_check_query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'offset_printing' AND table_name = 'order_items'";
    $order_items_check_result = mysqli_query($conn, $order_items_check_query);
    $order_items_exists = mysqli_fetch_array($order_items_check_result)[0];
    
    if (!$order_items_exists) {
        // Create order_items table
        $create_order_items_table = "CREATE TABLE `order_items` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `order_id` int(11) NOT NULL,
            `product_id` int(11) NOT NULL,
            `quantity` int(11) NOT NULL,
            `price` decimal(10,2) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `order_id` (`order_id`),
            KEY `product_id` (`product_id`),
            CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
            CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        mysqli_query($conn, $create_order_items_table);
    }
    
    // Display message
    echo '<div class="alert alert-info">Orders system has been set up. You can now start managing orders.</div>';
}

// Process order status update
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_status'])) {
        $order_id = sanitize_input($_POST['order_id']);
        $status = sanitize_input($_POST['status']);
        
        $update_query = "UPDATE orders SET status = '$status' WHERE id = $order_id";
        if (mysqli_query($conn, $update_query)) {
            $message = '<div class="alert alert-success">Order status updated successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
        }
    }
    
    // Handle order deletion
    if (isset($_POST['delete_order'])) {
        $order_id = sanitize_input($_POST['order_id']);
        
        // Begin transaction
        mysqli_begin_transaction($conn);
        
        try {
            // Delete order items first (due to foreign key constraint)
            $delete_items_query = "DELETE FROM order_items WHERE order_id = $order_id";
            mysqli_query($conn, $delete_items_query);
            
            // Delete the order
            $delete_order_query = "DELETE FROM orders WHERE id = $order_id";
            if (mysqli_query($conn, $delete_order_query)) {
                mysqli_commit($conn);
                $message = '<div class="alert alert-success">Order deleted successfully.</div>';
            } else {
                throw new Exception(mysqli_error($conn));
            }
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $message = '<div class="alert alert-danger">Error deleting order: ' . $e->getMessage() . '</div>';
        }
    }
}

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total number of orders
$total_records = 0;
$paginated_result = false;

if ($table_exists) {
    $total_query = "SELECT COUNT(*) as total FROM orders";
    $total_result = mysqli_query($conn, $total_query);
    $total_data = mysqli_fetch_assoc($total_result);
    $total_records = $total_data['total'];
    $total_pages = ceil($total_records / $records_per_page);

    // Get orders with pagination
    $paginated_query = "SELECT o.*, u.username, u.email, u.phone 
                       FROM orders o 
                       LEFT JOIN users u ON o.user_id = u.id 
                       ORDER BY o.created_at DESC 
                       LIMIT $offset, $records_per_page";
    $paginated_result = mysqli_query($conn, $paginated_query);

    // Filter by status
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $status_filter = sanitize_input($_GET['status']);
        $status_query = "AND o.status = '$status_filter'";
        
        // Update queries with status filter
        $total_query = "SELECT COUNT(*) as total 
                       FROM orders o 
                       LEFT JOIN users u ON o.user_id = u.id 
                       WHERE 1 $status_query";
        $total_result = mysqli_query($conn, $total_query);
        $total_data = mysqli_fetch_assoc($total_result);
        $total_records = $total_data['total'];
        $total_pages = ceil($total_records / $records_per_page);
        
        $paginated_query = "SELECT o.*, u.username, u.email, u.phone 
                           FROM orders o 
                           LEFT JOIN users u ON o.user_id = u.id 
                           WHERE 1 $status_query 
                           ORDER BY o.created_at DESC 
                           LIMIT $offset, $records_per_page";
        $paginated_result = mysqli_query($conn, $paginated_query);
    }
}
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Manage Orders</h2>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <?php if ($table_exists): ?>
    <!-- Order Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3">
                    <div class="d-flex align-items-center">
                        <span class="me-2">Show</span>
                        <select class="form-select form-select-sm w-auto" id="entriesSelect" onchange="changeEntries(this.value)">
                            <option value="50" <?php echo $records_per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $records_per_page == 100 ? 'selected' : ''; ?>>100</option>
                            <option value="200" <?php echo $records_per_page == 200 ? 'selected' : ''; ?>>200</option>
                        </select>
                        <span class="ms-2">entries</span>
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" id="statusFilter" onchange="filterByStatus(this.value)">
                        <option value="">All Statuses</option>
                        <option value="pending" <?php echo (isset($_GET['status']) && $_GET['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="processing" <?php echo (isset($_GET['status']) && $_GET['status'] == 'processing') ? 'selected' : ''; ?>>Processing</option>
                        <option value="shipped" <?php echo (isset($_GET['status']) && $_GET['status'] == 'shipped') ? 'selected' : ''; ?>>Shipped</option>
                        <option value="delivered" <?php echo (isset($_GET['status']) && $_GET['status'] == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                        <option value="cancelled" <?php echo (isset($_GET['status']) && $_GET['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th>Total Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($paginated_result && mysqli_num_rows($paginated_result) > 0) {
                            while ($order = mysqli_fetch_assoc($paginated_result)) {
                        ?>
                            <tr>
                                <td>#<?php echo htmlspecialchars($order['id']); ?></td>
                                <td><?php echo htmlspecialchars($order['username']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($order['email']); ?><br>
                                    <?php echo htmlspecialchars($order['phone']); ?>
                                </td>
                                <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    switch ($order['status']) {
                                        case 'pending':
                                            $status_class = 'bg-warning';
                                            break;
                                        case 'processing':
                                            $status_class = 'bg-info';
                                            break;
                                        case 'completed':
                                            $status_class = 'bg-success';
                                            break;
                                        case 'cancelled':
                                            $status_class = 'bg-danger';
                                            break;
                                        default:
                                            $status_class = 'bg-secondary';
                                    }
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateStatusModal<?php echo $order['id']; ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteOrderModal<?php echo $order['id']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    
                                    <!-- Delete Order Modal -->
                                    <div class="modal fade" id="deleteOrderModal<?php echo $order['id']; ?>" tabindex="-1" aria-labelledby="deleteOrderModalLabel<?php echo $order['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteOrderModalLabel<?php echo $order['id']; ?>">Delete Order</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete this order?</p>
                                                    <p class="text-danger">This action cannot be undone.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="" method="post">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" name="delete_order" class="btn btn-danger">Delete Order</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Update Status Modal -->
                                    <div class="modal fade" id="updateStatusModal<?php echo $order['id']; ?>" tabindex="-1" aria-labelledby="updateStatusModalLabel<?php echo $order['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="updateStatusModalLabel<?php echo $order['id']; ?>">Update Order Status</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="" method="post">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <div class="mb-3">
                                                            <label for="status<?php echo $order['id']; ?>" class="form-label">Status</label>
                                                            <select class="form-select" id="status<?php echo $order['id']; ?>" name="status">
                                                                <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                                <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                                                <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                                <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="7" class="text-center">No orders found.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($paginated_result && mysqli_num_rows($paginated_result) > 0): ?>
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="<?php echo generate_pagination_url($page - 1); ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $start_page + 4);
                            
                            if ($end_page - $start_page < 4 && $total_pages > 4) {
                                $start_page = max(1, $end_page - 4);
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="<?php echo generate_pagination_url($i); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="<?php echo generate_pagination_url($page + 1); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php else: ?>
    <!-- Display when table doesn't exist -->
    <div class="card">
        <div class="card-body">
            <div class="alert alert-info mb-0">
                <h5><i class="fas fa-info-circle me-2"></i> No Orders System Found</h5>
                <p>The orders system has been set up, but no orders have been placed yet. Once customers start placing orders, they will appear here.</p>
                <p>You can:</p>
                <ul>
                    <li>Encourage customers to place orders on the website</li>
                    <li>Check if the ordering system is functioning correctly</li>
                    <li>Add sample orders manually for testing purposes</li>
                </ul>
                <a href="index.php" class="btn btn-primary">Return to Dashboard</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
    function changeEntries(entries) {
        let url = new URL(window.location.href);
        url.searchParams.set('entries', entries);
        window.location.href = url.toString();
    }
    
    function filterByStatus(status) {
        let url = new URL(window.location.href);
        if (status) {
            url.searchParams.set('status', status);
        } else {
            url.searchParams.delete('status');
        }
        window.location.href = url.toString();
    }
</script>

<?php
// Helper function for pagination URLs
function generate_pagination_url($page) {
    $params = $_GET;
    $params['page'] = $page;
    return '?' . http_build_query($params);
}

// Include admin footer
require_once 'includes/admin_footer.php';
?>
