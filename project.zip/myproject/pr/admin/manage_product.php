<?php
// Include admin header
require_once 'includes/admin_header.php';

// Process form submission for adding new product
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $product_name = sanitize_input($_POST['product_name']);
    $product_code = sanitize_input($_POST['product_code']);
    $category_id = sanitize_input($_POST['category_id']);
    $product_size = sanitize_input($_POST['product_size']);
    $product_price = sanitize_input($_POST['product_price']);
    $product_stock = sanitize_input($_POST['product_stock']);
    $product_description = sanitize_input($_POST['product_description']);
    
    // Validate form data
    if (empty($product_name) || empty($product_code) || empty($category_id) || empty($product_price)) {
        $message = '<div class="alert alert-danger">Please fill all required fields.</div>';
    } else {
        // Check if product code already exists
        $check_query = "SELECT * FROM products WHERE product_code = '$product_code'";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $message = '<div class="alert alert-danger">Product code already exists.</div>';
        } else {
            // Handle image upload
            $image_path = '';
            if (isset($_FILES['product_image']) && $_FILES['product_image']['size'] > 0) {
                $target_dir = "../assets/images/products/";
                
                // Create directory if it doesn't exist
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                $file_extension = pathinfo($_FILES["product_image"]["name"], PATHINFO_EXTENSION);
                $new_filename = $product_code . "_" . time() . "." . $file_extension;
                $target_file = $target_dir . $new_filename;
                
                // Check if image file is a actual image
                $check = getimagesize($_FILES["product_image"]["tmp_name"]);
                if ($check !== false) {
                    // Upload file
                    if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
                        $image_path = "assets/images/products/" . $new_filename;
                    } else {
                        $message = '<div class="alert alert-danger">Sorry, there was an error uploading your file.</div>';
                    }
                } else {
                    $message = '<div class="alert alert-danger">File is not an image.</div>';
                }
            }
            
            if (empty($message)) {
                // Insert new product
                $insert_query = "INSERT INTO products (name, product_code, category_id, description, size, price, stock, image) 
                                VALUES ('$product_name', '$product_code', '$category_id', '$product_description', '$product_size', '$product_price', '$product_stock', '$image_path')";
                
                if (mysqli_query($conn, $insert_query)) {
                    $message = '<div class="alert alert-success">Product added successfully.</div>';
                } else {
                    $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
                }
            }
        }
    }
}

// Process product deletion
if (isset($_GET['delete'])) {
    $product_id = $_GET['delete'];
    
    // Check if product has orders
    $check_orders = "SELECT COUNT(*) as order_count FROM order_items WHERE product_id = $product_id";
    $order_result = mysqli_query($conn, $check_orders);
    $order_data = mysqli_fetch_assoc($order_result);
    
    if ($order_data['order_count'] > 0) {
        $message = '<div class="alert alert-danger">Cannot delete product. It has orders associated with it.</div>';
    } else {
        // Get product image path
        $image_query = "SELECT image FROM products WHERE id = $product_id";
        $image_result = mysqli_query($conn, $image_query);
        $image_data = mysqli_fetch_assoc($image_result);
        
        // Delete product image if exists
        if (!empty($image_data['image']) && file_exists("../" . $image_data['image'])) {
            unlink("../" . $image_data['image']);
        }
        
        // Delete product
        $delete_query = "DELETE FROM products WHERE id = $product_id";
        if (mysqli_query($conn, $delete_query)) {
            $message = '<div class="alert alert-success">Product deleted successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
        }
    }
}

// Get categories for dropdown
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_query);

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total records for pagination
$total_query = "SELECT COUNT(*) as total FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id";
$total_result = mysqli_query($conn, $total_query);
$total_records = mysqli_fetch_assoc($total_result)['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get products with pagination
$paginated_query = "SELECT p.*, c.name as category_name 
                   FROM products p 
                   LEFT JOIN categories c ON p.category_id = c.id 
                   ORDER BY p.name 
                   LIMIT $offset, $records_per_page";
$paginated_result = mysqli_query($conn, $paginated_query);
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Manage Products</h2>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
            <i class="fas fa-plus"></i> Add Product
        </button>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <!-- Product Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <span class="me-2">Show</span>
                        <select class="form-select form-select-sm w-auto" id="entriesSelect" onchange="changeEntries(this.value)">
                            <option value="50" <?php echo $records_per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $records_per_page == 100 ? 'selected' : ''; ?>>100</option>
                            <option value="200" <?php echo $records_per_page == 200 ? 'selected' : ''; ?>>200</option>
                        </select>
                        <span class="ms-2">entries</span>
                    </div>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Code</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Stock</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($paginated_result) > 0) {
                            $counter = $offset + 1;
                            while ($product = mysqli_fetch_assoc($paginated_result)) {
                        ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo htmlspecialchars($product['product_code']); ?></td>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                <td>
                                    <?php if ($product['stock'] < 10): ?>
                                        <span class="badge bg-danger"><?php echo $product['stock']; ?></span>
                                    <?php elseif ($product['stock'] < 20): ?>
                                        <span class="badge bg-warning"><?php echo $product['stock']; ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-success"><?php echo $product['stock']; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>₹<?php echo number_format($product['price'], 2); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewProductModal<?php echo $product['id']; ?>">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    
                                    <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteProductModal<?php echo $product['id']; ?>">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                    
                                    <!-- Delete Product Modal -->
                                    <div class="modal fade" id="deleteProductModal<?php echo $product['id']; ?>" tabindex="-1" aria-labelledby="deleteProductModalLabel<?php echo $product['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteProductModalLabel<?php echo $product['id']; ?>">Delete Product</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    Are you sure you want to delete this product?
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <a href="manage_product.php?delete=<?php echo $product['id']; ?>" class="btn btn-danger">Delete</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="7" class="text-center">No products found.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&entries=<?php echo $records_per_page; ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&entries=<?php echo $records_per_page; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&entries=<?php echo $records_per_page; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addProductModalLabel">Add New Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="product_name" class="form-label">Product Name*</label>
                            <input type="text" class="form-control" id="product_name" name="product_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="product_code" class="form-label">Product Code*</label>
                            <input type="text" class="form-control" id="product_code" name="product_code" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="category_id" class="form-label">Category*</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">Select Category</option>
                                <?php 
                                // Reset the pointer to the beginning of the result set
                                mysqli_data_seek($categories_result, 0);
                                while ($category = mysqli_fetch_assoc($categories_result)) {
                                    echo '<option value="' . $category['id'] . '">' . htmlspecialchars($category['name']) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="product_size" class="form-label">Product Size</label>
                            <input type="text" class="form-control" id="product_size" name="product_size" placeholder="e.g. A4, 5x7, etc.">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="product_price" class="form-label">Price (₹)*</label>
                            <input type="number" class="form-control" id="product_price" name="product_price" step="0.01" min="0" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="product_stock" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="product_stock" name="product_stock" min="0" value="0">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="product_description" class="form-label">Description</label>
                        <textarea class="form-control" id="product_description" name="product_description" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="product_image" class="form-label">Product Image</label>
                        <input type="file" class="form-control image-input" id="product_image" name="product_image" data-preview="imagePreview">
                        <div class="mt-2">
                            <img id="imagePreview" src="#" alt="Product Image Preview" style="max-width: 200px; max-height: 200px; display: none;">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="add_product" class="btn btn-primary">Add Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function changeEntries(entries) {
        window.location.href = 'manage_product.php?entries=' + entries;
    }
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
