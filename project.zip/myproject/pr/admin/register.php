<?php
// Include database connection and functions
require_once 'includes/db_connection.php';
require_once 'includes/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the is_admin column exists, if not add it
$check_column_query = "SELECT COUNT(*) as column_exists 
                      FROM information_schema.COLUMNS 
                      WHERE TABLE_SCHEMA = DATABASE() 
                      AND TABLE_NAME = 'users' 
                      AND COLUMN_NAME = 'is_admin'";
$result = mysqli_query($conn, $check_column_query);
$row = mysqli_fetch_assoc($result);

if ($row['column_exists'] == 0) {
    // Column doesn't exist, add it
    $alter_query = "ALTER TABLE users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0";
    mysqli_query($conn, $alter_query);
}

// Redirect to dashboard if already logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
    header("Location: dashboard.php");
    exit;
}

// Get site name from settings
$site_name = get_setting('site_name', 'Offset Printing Shop');

// Initialize variables
$username = '';
$email = '';
$message = '';
$registration_allowed = true; // Always allow registration for college project

// Process registration form
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password']; // Don't sanitize password before validation
    $confirm_password = $_POST['confirm_password']; // Don't sanitize password before validation
    
    // Validation
    $errors = [];
    
    // Validate username
    if (empty($username)) {
        $errors[] = "Username is required";
    } elseif (strlen($username) < 3 || strlen($username) > 50) {
        $errors[] = "Username must be between 3 and 50 characters";
    } else {
        // Check if username already exists
        $check_username_query = "SELECT * FROM users WHERE username = '$username'";
        $check_username_result = mysqli_query($conn, $check_username_query);
        if (mysqli_num_rows($check_username_result) > 0) {
            $errors[] = "Username already exists";
        }
    }
    
    // Validate email
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    } else {
        // Check if email already exists
        $check_email_query = "SELECT * FROM users WHERE email = '$email'";
        $check_email_result = mysqli_query($conn, $check_email_query);
        if (mysqli_num_rows($check_email_result) > 0) {
            $errors[] = "Email already exists";
        }
    }
    
    // Validate password
    if (empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < 6) { // Reduced password length requirement
        $errors[] = "Password must be at least 6 characters";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }
    
    // If no errors, proceed with registration
    if (empty($errors)) {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert user into database
        $insert_query = "INSERT INTO users (username, email, password, created_at, is_admin) 
                        VALUES ('$username', '$email', '$hashed_password', NOW(), 1)";
        
        if (mysqli_query($conn, $insert_query)) {
            // Get the new user ID
            $new_user_id = mysqli_insert_id($conn);
            
            // Log activity
            log_activity($new_user_id, 'registration', 'New admin account created');
            
            // Registration successful
            $message = '<div class="alert alert-success">Registration successful! You can now <a href="login.php">login</a>.</div>';
            
            // Clear form data
            $username = '';
            $email = '';
        } else {
            // Registration failed
            $message = '<div class="alert alert-danger">Registration failed: ' . mysqli_error($conn) . '</div>';
        }
    } else {
        // Display validation errors
        $message = '<div class="alert alert-danger"><ul>';
        foreach ($errors as $error) {
            $message .= '<li>' . $error . '</li>';
        }
        $message .= '</ul></div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration - <?php echo htmlspecialchars($site_name); ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        .register-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .register-header h2 {
            color: #343a40;
            font-weight: 600;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-register {
            background-color: #0d6efd;
            border-color: #0d6efd;
            width: 100%;
            padding: 10px;
            font-weight: 600;
        }
        .btn-register:hover {
            background-color: #0b5ed7;
            border-color: #0b5ed7;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 10px;
            z-index: 10;
        }
        .password-field {
            position: relative;
        }
        .password-strength {
            height: 5px;
            margin-top: 10px;
            background-color: #e9ecef;
            border-radius: 3px;
        }
        .password-strength-meter {
            height: 100%;
            border-radius: 3px;
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="register-container">
            <div class="register-header">
                <h2><i class="fas fa-user-plus"></i> Admin Registration</h2>
                <p>Create a new administrator account for <?php echo htmlspecialchars($site_name); ?></p>
            </div>
            
            <?php echo $message; ?>
            
            <form action="" method="post">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                        <div class="password-field">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="password" name="password" required>
                                <span class="password-toggle" onclick="togglePassword('password')">
                                    <i class="fas fa-eye"></i>
                                </span>
                            </div>
                            <div class="password-strength">
                                <div class="password-strength-meter" id="password-strength-meter"></div>
                            </div>
                            <small id="passwordHelp" class="form-text text-muted">At least 6 characters</small>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                        <div class="password-field">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                <span class="password-toggle" onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <button type="submit" name="register" class="btn btn-primary btn-register">
                            <i class="fas fa-user-plus me-2"></i> Register
                        </button>
                    </div>
                </div>
            </form>
            
            <div class="login-link">
                <p>Already have an account? <a href="login.php">Login</a></p>
                <p><a href="../index.php"><i class="fas fa-arrow-left me-1"></i> Back to Website</a></p>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Toggle password visibility
        function togglePassword(inputId) {
            const passwordInput = document.getElementById(inputId);
            const icon = passwordInput.nextElementSibling.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        // Password strength meter
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const meter = document.getElementById('password-strength-meter');
            const passwordHelp = document.getElementById('passwordHelp');
            
            // Calculate strength
            let strength = 0;
            
            if (password.length >= 6) {
                strength += 20;
            }
            
            if (password.length >= 8) {
                strength += 10;
            }
            
            if (/[A-Z]/.test(password)) {
                strength += 20;
            }
            
            if (/[a-z]/.test(password)) {
                strength += 20;
            }
            
            if (/[0-9]/.test(password)) {
                strength += 20;
            }
            
            if (/[^A-Za-z0-9]/.test(password)) {
                strength += 10;
            }
            
            // Update meter
            meter.style.width = strength + '%';
            
            // Update color and text
            if (strength <= 20) {
                meter.style.backgroundColor = '#dc3545'; // red
                passwordHelp.textContent = 'Very Weak';
            } else if (strength <= 40) {
                meter.style.backgroundColor = '#ffc107'; // yellow
                passwordHelp.textContent = 'Weak';
            } else if (strength <= 60) {
                meter.style.backgroundColor = '#fd7e14'; // orange
                passwordHelp.textContent = 'Fair';
            } else if (strength <= 80) {
                meter.style.backgroundColor = '#20c997'; // teal
                passwordHelp.textContent = 'Good';
            } else {
                meter.style.backgroundColor = '#198754'; // green
                passwordHelp.textContent = 'Strong';
            }
        });
        
        // Check password match
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (confirmPassword === password) {
                this.style.borderColor = '#198754';
            } else {
                this.style.borderColor = '#dc3545';
            }
        });
    </script>
</body>
</html>
