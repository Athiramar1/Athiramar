<?php
// Include admin header
require_once 'includes/admin_header.php';

// Initialize message variable
$message = '';

// Process message deletion
if (isset($_GET['delete_message'])) {
    $message_id = $_GET['delete_message'];
    
    $delete_query = "DELETE FROM contact_messages WHERE id = $message_id";
    if (mysqli_query($conn, $delete_query)) {
        $message = '<div class="alert alert-success">Message deleted successfully.</div>';
    } else {
        $message = '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
    }
}

// Pagination settings
$records_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 50;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Get total number of messages
$total_query = "SELECT COUNT(*) as total FROM contact_messages";
$total_result = mysqli_query($conn, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_records = $total_data['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get messages with pagination
$paginated_query = "SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT $offset, $records_per_page";
$paginated_result = mysqli_query($conn, $paginated_query);
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Manage Contact Messages</h2>
    </div>
    
    <!-- Display Messages -->
    <?php echo $message; ?>
    
    <!-- Messages Table -->
    <div class="card admin-table">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($paginated_result) > 0) {
                            $counter = $offset + 1;
                            while ($msg = mysqli_fetch_assoc($paginated_result)) {
                        ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo htmlspecialchars($msg['name']); ?></td>
                                <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                <td><?php echo htmlspecialchars($msg['subject']); ?></td>
                                <td><?php echo date('d M Y', strtotime($msg['created_at'])); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewMessageModal<?php echo $msg['id']; ?>">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteMessageModal<?php echo $msg['id']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    
                                    <!-- Delete Message Modal -->
                                    <div class="modal fade" id="deleteMessageModal<?php echo $msg['id']; ?>" tabindex="-1" aria-labelledby="deleteMessageModalLabel<?php echo $msg['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteMessageModalLabel<?php echo $msg['id']; ?>">Delete Message</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete this message from <?php echo htmlspecialchars($msg['name']); ?>?</p>
                                                    <p class="text-danger">This action cannot be undone.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <a href="manage_contactus.php?delete_message=<?php echo $msg['id']; ?>" class="btn btn-danger">Delete Message</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- View Message Modal -->
                                    <div class="modal fade" id="viewMessageModal<?php echo $msg['id']; ?>" tabindex="-1" aria-labelledby="viewMessageModalLabel<?php echo $msg['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="viewMessageModalLabel<?php echo $msg['id']; ?>">Message Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <p><strong>Name:</strong> <?php echo htmlspecialchars($msg['name']); ?></p>
                                                            <p><strong>Email:</strong> <?php echo htmlspecialchars($msg['email']); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><strong>Date:</strong> <?php echo date('d M Y h:i A', strtotime($msg['created_at'])); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p><strong>Subject:</strong> <?php echo htmlspecialchars($msg['subject']); ?></p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p><strong>Message:</strong></p>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="6" class="text-center">No messages found.</td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="row">
                <div class="col-md-6">
                    <p>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> entries</p>
                </div>
                <div class="col-md-6">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&entries=<?php echo $records_per_page; ?>">Previous</a>
                            </li>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&entries=<?php echo $records_per_page; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&entries=<?php echo $records_per_page; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
