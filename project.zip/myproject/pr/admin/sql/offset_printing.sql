-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2025 at 03:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `offset_printing`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `action`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 4, 'registration', 'New admin account created', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', '2025-03-25 02:25:48'),
(2, 4, 'login', 'Admin logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', '2025-03-25 02:26:12');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Business Cards', 'Professional business cards in various styles and finishes', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(2, 'Brochures', 'Informative brochures in different fold types and sizes', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(3, 'Flyers', 'Promotional flyers for marketing and advertising', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(4, 'Posters', 'Eye-catching posters for promotions and events', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(5, 'Banners', 'Durable banners for indoor and outdoor advertising', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(6, 'Stationery', 'Professional stationery items for business use', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(7, 'Postcards', 'Custom postcards for marketing and personal use', '2025-03-25 02:04:13', '2025-03-25 02:04:13'),
(8, 'Letterheads', 'Professional letterheads for business correspondence', '2025-03-25 02:04:13', '2025-03-25 02:04:13');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` enum('unread','read','replied') NOT NULL DEFAULT 'unread',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `phone`, `subject`, `message`, `status`, `created_at`) VALUES
(1, 'Robert Johnson', 'robert@example.com', '1112223333', 'Quote Request', 'I would like to request a quote for 1000 business cards with spot UV finish. Please let me know the pricing and turnaround time.', 'unread', '2025-03-22 19:51:32'),
(2, 'Mary Williams', 'mary@example.com', '4445556666', 'Custom Order Inquiry', 'Do you offer custom sizes for banners? I need a 3m x 1.5m banner for an upcoming event.', 'read', '2025-03-19 19:51:32'),
(3, 'David Brown', 'david@example.com', '7778889999', 'Bulk Order Discount', 'I\'m interested in placing a bulk order for flyers. Do you offer any discounts for orders over 5000 pieces?', 'replied', '2025-03-14 19:51:32'),
(4, 'molhan', 'athiramar2@gmail.com', NULL, 'Order Inquiry: Folded Business Card', 'I would like to order the following product:\r\nProduct: Folded Business Card\r\nPrice: ₹29.99\r\n\r\nPlease let me know the next steps to complete my order.', 'unread', '2025-03-25 02:26:45');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_number` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
  `shipping_address` text NOT NULL,
  `shipping_phone` varchar(20) NOT NULL,
  `payment_method` enum('credit_card','bank_transfer','cash_on_delivery') NOT NULL,
  `payment_status` enum('pending','paid','refunded') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_number`, `total_amount`, `status`, `shipping_address`, `shipping_phone`, `payment_method`, `payment_status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 2, '', 37.98, 'completed', '456 Customer Lane, Customer Town', '9876543210', 'credit_card', 'paid', 'Please deliver during business hours', '2025-02-22 19:51:27', '2025-03-24 19:51:27'),
(2, 2, '', 49.99, 'processing', '456 Customer Lane, Customer Town', '9876543210', 'bank_transfer', 'paid', NULL, '2025-03-17 19:51:27', '2025-03-24 19:51:27'),
(4, 4, 'ORD-20250325-7671', 29.99, 'completed', '', '', 'credit_card', 'pending', NULL, '2025-03-25 02:27:07', '2025-03-25 02:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`, `created_at`) VALUES
(1, 1, 1, 2, 12.99, '2025-02-22 19:51:29'),
(2, 1, 4, 1, 9.99, '2025-02-22 19:51:29'),
(3, 2, 6, 1, 49.99, '2025-03-17 19:51:29'),
(7, 4, 4, 1, 29.99, '2025-03-25 02:27:07');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `size` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `product_code`, `category_id`, `description`, `size`, `price`, `stock`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Standard Business Card', 'BC001', 1, 'Standard business cards printed on 350gsm art card with matte lamination', '90mm x 55mm', 12.99, 1000, 'standard_business_card.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(2, 'Premium Business Card', 'BC002', 1, 'Premium business cards printed on 400gsm art card with spot UV and matte lamination', '90mm x 55mm', 24.99, 500, 'premium_business_card.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(3, 'Rounded Corner Business Card', 'BC003', 1, 'Business cards with rounded corners on 350gsm art card', '90mm x 55mm', 14.99, 800, 'rounded_business_card.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(4, 'Folded Business Card', 'BC004', 1, 'Folded business cards with more space for information', '90mm x 55mm (folded)', 29.99, 400, 'folded_business_card.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(5, 'Metallic Business Card', 'BC005', 1, 'Luxury business cards with metallic finish', '90mm x 55mm', 34.99, 300, 'metallic_business_card.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(6, 'Tri-fold Brochure', 'BR001', 2, 'Tri-fold brochures printed on 150gsm art paper with full color printing on both sides', 'A4 (folded to DL)', 34.99, 200, 'trifold_brochure.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(7, 'Bi-fold Brochure', 'BR002', 2, 'Bi-fold brochures on 170gsm art paper with glossy finish', 'A4 (folded to A5)', 29.99, 250, 'bifold_brochure.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(8, 'Z-fold Brochure', 'BR003', 2, 'Z-fold brochures for creative presentation of content', 'A4 (z-folded)', 39.99, 180, 'zfold_brochure.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(9, 'Gate-fold Brochure', 'BR004', 2, 'Gate-fold brochures with dramatic opening effect', 'A4 (gate-folded)', 44.99, 150, 'gatefold_brochure.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(10, 'Square Brochure', 'BR005', 2, 'Square brochures for a modern look', '210mm x 210mm', 37.99, 200, 'square_brochure.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(11, 'DL Flyer', 'FL003', 3, 'DL size flyers perfect for mail distribution', 'DL (99mm x 210mm)', 8.99, 1000, 'dl_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(12, 'A4 Flyer', 'FL004', 3, 'A4 flyers with full color printing on premium paper', 'A4', 12.99, 800, 'a4_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(13, 'Square Flyer', 'FL005', 3, 'Square flyers for a unique look', '148mm x 148mm', 10.99, 900, 'square_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(14, 'Premium Flyer', 'FL006', 3, 'Premium flyers on 200gsm art paper with glossy finish', 'A5', 11.99, 800, 'premium_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(15, 'Double-sided Flyer', 'FL007', 3, 'Double-sided flyers with different designs on each side', 'A5', 10.99, 950, 'doublesided_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(16, 'Folded Flyer', 'FL008', 3, 'Folded flyers for more content space', 'A4 (folded to A5)', 13.99, 700, 'folded_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(17, 'Mini Flyer', 'FL009', 3, 'Mini flyers for cost-effective distribution', 'A7', 5.99, 1500, 'mini_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(18, 'Textured Flyer', 'FL010', 3, 'Flyers printed on textured paper for premium feel', 'A5', 12.99, 600, 'textured_flyer.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(19, 'A2 Poster', 'PO001', 4, 'A2 posters printed on 170gsm art paper with full color printing', 'A2', 19.99, 100, 'a2_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(20, 'A1 Poster', 'PO002', 4, 'A1 posters for maximum visibility', 'A1', 29.99, 80, 'a1_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(21, 'A0 Poster', 'PO003', 4, 'A0 posters for exhibitions and events', 'A0', 39.99, 50, 'a0_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(22, 'B2 Poster', 'PO004', 4, 'B2 size posters with vibrant colors', 'B2', 24.99, 90, 'b2_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(23, 'Custom Size Poster', 'PO005', 4, 'Custom size posters tailored to your needs', 'Custom', 34.99, 60, 'custom_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(24, 'Glossy Poster', 'PO006', 4, 'Posters with glossy finish for vibrant colors', 'A2', 21.99, 95, 'glossy_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(25, 'Matte Poster', 'PO007', 4, 'Posters with matte finish to reduce glare', 'A2', 21.99, 95, 'matte_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(26, 'Backlit Poster', 'PO008', 4, 'Translucent posters for illuminated displays', 'A1', 34.99, 70, 'backlit_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(27, 'Mounted Poster', 'PO009', 4, 'Posters mounted on 5mm foam board', 'A2', 29.99, 60, 'mounted_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(28, 'Framed Poster', 'PO010', 4, 'Posters in elegant black frames ready to hang', 'A2', 39.99, 40, 'framed_poster.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(29, 'Vinyl Banner', 'BN001', 5, 'Vinyl banners printed with full color printing and metal eyelets', '2m x 1m', 49.99, 20, 'vinyl_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(30, 'Outdoor Banner', 'BN002', 5, 'Weather-resistant outdoor banners with reinforced edges', '3m x 1m', 69.99, 15, 'outdoor_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(31, 'Roll-up Banner', 'BN003', 5, 'Portable roll-up banners with aluminum stand', '0.85m x 2m', 79.99, 25, 'rollup_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(32, 'Mesh Banner', 'BN004', 5, 'Mesh banners for windy conditions with reduced wind resistance', '2m x 1m', 59.99, 18, 'mesh_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(33, 'X-Banner', 'BN005', 5, 'X-frame banners for trade shows and exhibitions', '0.8m x 1.8m', 39.99, 30, 'x_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(34, 'Double-sided Banner', 'BN006', 5, 'Double-sided banners for visibility from both directions', '2m x 1m', 89.99, 12, 'doublesided_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(35, 'Mini Banner', 'BN007', 5, 'Compact banners for counter displays', '0.6m x 0.9m', 29.99, 40, 'mini_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(36, 'Custom Shape Banner', 'BN008', 5, 'Custom shaped banners for unique branding', 'Custom', 99.99, 10, 'custom_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(37, 'Backlit Banner', 'BN009', 5, 'Translucent banners for illuminated displays', '2m x 1m', 79.99, 15, 'backlit_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(38, 'Event Banner', 'BN010', 5, 'Event-specific banners with date and venue printing', '3m x 1.5m', 89.99, 20, 'event_banner.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(39, 'Letterhead', 'ST001', 6, 'Letterheads printed on 100gsm bond paper with full color printing', 'A4', 14.99, 500, 'letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(40, 'Business Envelope', 'ST002', 6, 'Business envelopes with company logo and address', 'DL', 9.99, 500, 'business_envelope.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(41, 'Compliment Slip', 'ST003', 6, 'Compliment slips for sending personal notes', 'DL', 7.99, 500, 'compliment_slip.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(42, 'Notepad', 'ST004', 6, 'Custom notepads with company branding', 'A5', 11.99, 200, 'notepad.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(43, 'Folder', 'ST005', 6, 'Presentation folders with pockets', 'A4', 19.99, 100, 'folder.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(44, 'Corporate Notebook', 'ST006', 6, 'Hard cover notebooks with company logo', 'A5', 15.99, 150, 'corporate_notebook.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(45, 'Appointment Card', 'ST007', 6, 'Appointment cards for scheduling client meetings', '90mm x 55mm', 6.99, 1000, 'appointment_card.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(46, 'Sticky Notes', 'ST008', 6, 'Custom printed sticky notes with company logo', '3\" x 3\"', 7.99, 300, 'sticky_notes.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(47, 'Memo Pad', 'ST009', 6, 'Memo pads for quick notes and reminders', 'A6', 9.99, 250, 'memo_pad.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(48, 'Complete Stationery Set', 'ST010', 6, 'Complete stationery set including letterheads, envelopes, and business cards', 'Various', 49.99, 50, 'stationery_set.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(49, 'Standard Postcard', 'PC001', 7, 'Standard postcards printed on 300gsm art card', '4\" x 6\"', 6.99, 1000, 'standard_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(50, 'Large Postcard', 'PC002', 7, 'Large postcards with more space for your message', '5\" x 7\"', 8.99, 800, 'large_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(51, 'Square Postcard', 'PC003', 7, 'Square postcards for a modern look', '5\" x 5\"', 7.99, 900, 'square_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(52, 'Double-sided Postcard', 'PC004', 7, 'Postcards printed on both sides with full color', '4\" x 6\"', 7.99, 950, 'doublesided_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(53, 'Premium Postcard', 'PC005', 7, 'Premium postcards with spot UV coating', '4\" x 6\"', 8.99, 750, 'premium_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(54, 'Matte Postcard', 'PC006', 7, 'Postcards with elegant matte finish', '4\" x 6\"', 7.49, 900, 'matte_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(55, 'Glossy Postcard', 'PC007', 7, 'Postcards with vibrant glossy finish', '4\" x 6\"', 7.49, 900, 'glossy_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(56, 'Textured Postcard', 'PC008', 7, 'Postcards printed on textured paper for a premium feel', '4\" x 6\"', 8.49, 700, 'textured_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(57, 'Mini Postcard', 'PC009', 7, 'Compact postcards for quick messages', '3.5\" x 5\"', 5.99, 1200, 'mini_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(58, 'Oversized Postcard', 'PC010', 7, 'Extra large postcards that stand out in the mail', '6\" x 9\"', 10.99, 600, 'oversized_postcard.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(59, 'Standard Letterhead', 'LH001', 8, 'Standard letterheads on 100gsm bond paper', 'A4', 12.99, 500, 'standard_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(60, 'Premium Letterhead', 'LH002', 8, 'Premium letterheads on 120gsm textured paper', 'A4', 15.99, 400, 'premium_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(61, 'Watermarked Letterhead', 'LH003', 8, 'Letterheads with subtle watermark', 'A4', 17.99, 350, 'watermarked_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(62, 'Colored Letterhead', 'LH004', 8, 'Letterheads printed on light colored paper', 'A4', 14.99, 450, 'colored_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(63, 'Executive Letterhead', 'LH005', 8, 'Executive letterheads with gold or silver accents', 'A4', 18.99, 300, 'executive_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(64, 'Digital Letterhead', 'LH006', 8, 'Digital letterhead templates for electronic communications', 'A4 (Digital PDF)', 9.99, 1000, 'digital_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(65, 'Legal Letterhead', 'LH007', 8, 'Legal size letterheads for official documents', 'Legal (8.5\" x 14\")', 14.99, 400, 'legal_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(66, 'Embossed Letterhead', 'LH008', 8, 'Letterheads with embossed logo or text', 'A4', 20.99, 250, 'embossed_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(67, 'Eco-friendly Letterhead', 'LH009', 8, 'Letterheads printed on recycled paper', 'A4', 13.99, 500, 'eco_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50'),
(68, 'Double-sided Letterhead', 'LH010', 8, 'Letterheads printed on both sides for versatility', 'A4', 16.99, 350, 'doublesided_letterhead.jpg', '2025-03-24 19:28:50', '2025-03-24 19:28:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `role` enum('customer','admin') NOT NULL DEFAULT 'customer',
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `address`, `role`, `is_admin`, `created_at`) VALUES
(1, 'Admin User', 'admin@multicolor.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1234567890', '123 Admin Street, Admin City', 'admin', 0, '2025-03-24 19:51:22'),
(2, 'John Doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543210', '456 Customer Lane, Customer Town', 'customer', 0, '2025-03-24 19:51:22'),
(3, 'Jane Smith', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '5555555555', '789 Buyer Avenue, Buyer City', 'customer', 0, '2025-03-24 19:51:22'),
(4, 'Athiramar', 'athiramar1@gmail.com', '$2y$10$u0ARW4BwfGbdqapOS72gU.2lB.v0IHjZUZVG5marwPepjSH5nBIMK', NULL, NULL, 'customer', 1, '2025-03-25 02:25:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
