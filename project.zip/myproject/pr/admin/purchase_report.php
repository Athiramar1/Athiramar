<?php
// Include admin header
require_once 'includes/admin_header.php';

// Default date range (last 30 days)
$end_date = date('Y-m-d');
$start_date = date('Y-m-d', strtotime('-30 days'));

// Process date range filter
if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
}

// Get purchase summary for the selected period
$purchase_query = "SELECT 
                  o.id as order_id,
                  o.created_at as purchase_date,
                  u.username as customer_name,
                  u.email as customer_email,
                  o.total_amount as purchase_amount,
                  o.status as order_status,
                  GROUP_CONCAT(CONCAT(p.name, ' (', oi.quantity, ')') SEPARATOR ', ') as products
                  FROM orders o
                  JOIN users u ON o.user_id = u.id
                  JOIN order_items oi ON o.id = oi.order_id
                  JOIN products p ON oi.product_id = p.id
                  WHERE DATE(o.created_at) BETWEEN '$start_date' AND '$end_date'
                  GROUP BY o.id
                  ORDER BY o.created_at DESC";
$purchase_result = mysqli_query($conn, $purchase_query);
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Purchase Report</h2>
        <div>
            <a href="manage_orders.php" class="btn btn-primary">
                <i class="fas fa-shopping-cart"></i> Manage Orders
            </a>
        </div>
    </div>
    
    <!-- Date Range Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="" method="get" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="start_date" class="form-label">Start Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                <div class="col-md-4">
                    <label for="end_date" class="form-label">End Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Apply Filter</button>
                </div>
            </form>
            <div class="mt-3">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('today')">Today</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('yesterday')">Yesterday</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('7days')">Last 7 Days</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('30days')">Last 30 Days</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('month')">This Month</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('year')">This Year</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Purchase Details Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Purchase Details</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Products</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($purchase = mysqli_fetch_assoc($purchase_result)): ?>
                            <tr>
                                <td>#<?php echo $purchase['order_id']; ?></td>
                                <td><?php echo date('d M Y', strtotime($purchase['purchase_date'])); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($purchase['customer_name']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($purchase['customer_email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($purchase['products']); ?></td>
                                <td>₹<?php echo number_format($purchase['purchase_amount'], 2); ?></td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    switch($purchase['order_status']) {
                                        case 'pending':
                                            $status_class = 'bg-warning';
                                            break;
                                        case 'processing':
                                            $status_class = 'bg-info';
                                            break;
                                        case 'completed':
                                            $status_class = 'bg-success';
                                            break;
                                        case 'cancelled':
                                            $status_class = 'bg-danger';
                                            break;
                                    }
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>">
                                        <?php echo ucfirst($purchase['order_status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="manage_orders.php?id=<?php echo $purchase['order_id']; ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    // Date range functions
    function setDateRange(range) {
        const today = new Date();
        let startDate = new Date();
        let endDate = new Date();
        
        switch(range) {
            case 'today':
                // Start and end are both today
                break;
            case 'yesterday':
                startDate.setDate(today.getDate() - 1);
                endDate.setDate(today.getDate() - 1);
                break;
            case '7days':
                startDate.setDate(today.getDate() - 6);
                break;
            case '30days':
                startDate.setDate(today.getDate() - 29);
                break;
            case 'month':
                startDate = new Date(today.getFullYear(), today.getMonth(), 1);
                endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                break;
            case 'year':
                startDate = new Date(today.getFullYear(), 0, 1);
                endDate = new Date(today.getFullYear(), 11, 31);
                break;
        }
        
        document.getElementById('start_date').value = formatDate(startDate);
        document.getElementById('end_date').value = formatDate(endDate);
        
        // Submit the form
        document.querySelector('form').submit();
    }
    
    function formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?> 