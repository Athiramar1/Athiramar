<?php
// Include admin header
require_once 'includes/admin_header.php';

// Get total products count
$products_query = "SELECT COUNT(*) as total_products FROM products";
$products_result = mysqli_query($conn, $products_query);
$products_data = mysqli_fetch_assoc($products_result);
$total_products = $products_data['total_products'];

// Get total stock count
$stock_query = "SELECT SUM(stock) as total_stock FROM products";
$stock_result = mysqli_query($conn, $stock_query);
$stock_data = mysqli_fetch_assoc($stock_result);
$total_stock = $stock_data['total_stock'] ? $stock_data['total_stock'] : 0;

// Check if order_items table exists
$table_check_query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'offset_printing' AND table_name = 'order_items'";
$table_check_result = mysqli_query($conn, $table_check_query);
$table_exists = mysqli_fetch_array($table_check_result)[0];

// Get ordered products count
$ordered_products = 0;
if ($table_exists) {
    $ordered_query = "SELECT COUNT(*) as ordered_products FROM order_items";
    $ordered_result = mysqli_query($conn, $ordered_query);
    $ordered_data = mysqli_fetch_assoc($ordered_result);
    $ordered_products = $ordered_data['ordered_products'];
}

// Stock left calculation
$stock_left = $total_stock - $ordered_products;
if ($stock_left < 0) $stock_left = 0;

// Check if orders table exists
$table_check_query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'offset_printing' AND table_name = 'orders'";
$table_check_result = mysqli_query($conn, $table_check_query);
$table_exists = mysqli_fetch_array($table_check_result)[0];

// Get total orders count
$total_orders = 0;
if ($table_exists) {
    $total_orders_query = "SELECT COUNT(*) as total_orders FROM orders";
    $total_orders_result = mysqli_query($conn, $total_orders_query);
    $total_orders_data = mysqli_fetch_assoc($total_orders_result);
    $total_orders = $total_orders_data['total_orders'];
}

// Get total customers count
$customers_query = "SELECT COUNT(*) as total_customers FROM users WHERE is_admin = 0";
$customers_result = mysqli_query($conn, $customers_query);
$customers_data = mysqli_fetch_assoc($customers_result);
$total_customers = $customers_data['total_customers'];

// Get total revenue
$total_revenue = 0;
if ($table_exists) {
    $revenue_query = "SELECT SUM(total_amount) as total_revenue FROM orders WHERE status = 'completed'";
    $revenue_result = mysqli_query($conn, $revenue_query);
    $revenue_data = mysqli_fetch_assoc($revenue_result);
    $total_revenue = $revenue_data['total_revenue'] ? $revenue_data['total_revenue'] : 0;
}
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-xl-3 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Products</p>
                                <h5 class="font-weight-bolder mb-0">
                                    <?php echo $total_products; ?>
                                </h5>
                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-primary shadow text-center rounded-circle">
                                <i class="fas fa-box text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Stock Available</p>
                                <h5 class="font-weight-bolder mb-0">
                                    <?php echo $stock_left; ?>
                                </h5>
                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-success shadow text-center rounded-circle">
                                <i class="fas fa-cubes text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Orders</p>
                                <h5 class="font-weight-bolder mb-0">
                                    <?php echo $total_orders; ?>
                                </h5>
                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-danger shadow text-center rounded-circle">
                                <i class="fas fa-shopping-cart text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Customers</p>
                                <h5 class="font-weight-bolder mb-0">
                                    <?php echo $total_customers; ?>
                                </h5>
                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-warning shadow text-center rounded-circle">
                                <i class="fas fa-users text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-lg-12 mb-lg-0 mb-4">
            <div class="card">
                <div class="card-header pb-0">
                    <h6>Recent Orders</h6>
                </div>
                <div class="card-body p-3">
                    <div class="table-responsive">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Order ID</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Customer</th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Amount</th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($table_exists) {
                                    $recent_orders_query = "SELECT o.id, o.total_amount, o.status, o.created_at, u.username 
                                                          FROM orders o 
                                                          JOIN users u ON o.user_id = u.id 
                                                          ORDER BY o.created_at DESC 
                                                          LIMIT 5";
                                    $recent_orders_result = mysqli_query($conn, $recent_orders_query);
                                    
                                    if (mysqli_num_rows($recent_orders_result) > 0) {
                                        while ($order = mysqli_fetch_assoc($recent_orders_result)) {
                                            // Status color
                                            $status_color = 'bg-secondary';
                                            if ($order['status'] == 'completed') {
                                                $status_color = 'bg-success';
                                            } elseif ($order['status'] == 'processing') {
                                                $status_color = 'bg-info';
                                            } elseif ($order['status'] == 'pending') {
                                                $status_color = 'bg-warning';
                                            } elseif ($order['status'] == 'cancelled') {
                                                $status_color = 'bg-danger';
                                            }
                                            ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex px-3 py-1">
                                                        <div class="d-flex flex-column justify-content-center">
                                                            <h6 class="mb-0 text-sm">#<?php echo $order['id']; ?></h6>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <p class="text-sm font-weight-bold mb-0"><?php echo htmlspecialchars($order['username']); ?></p>
                                                </td>
                                                <td class="align-middle text-center text-sm">
                                                    <p class="text-sm font-weight-bold mb-0">₹<?php echo number_format($order['total_amount'], 2); ?></p>
                                                </td>
                                                <td class="align-middle text-center">
                                                    <span class="badge badge-sm <?php echo $status_color; ?>"><?php echo ucfirst($order['status']); ?></span>
                                                </td>
                                                <td>
                                                    <p class="text-sm font-weight-bold mb-0"><?php echo date('d M Y', strtotime($order['created_at'])); ?></p>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        echo '<tr><td colspan="5" class="text-center">No recent orders found</td></tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="5" class="text-center">Orders table does not exist yet</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
