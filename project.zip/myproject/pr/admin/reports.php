<?php
// Include admin header
require_once 'includes/admin_header.php';

// Default date range (last 30 days)
$end_date = date('Y-m-d');
$start_date = date('Y-m-d', strtotime('-30 days'));

// Process date range filter
if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
}

// Get sales summary for the selected period
$sales_query = "SELECT 
                COUNT(*) as total_orders,
                SUM(total_amount) as total_sales,
                AVG(total_amount) as average_order,
                COUNT(DISTINCT user_id) as unique_customers
                FROM orders 
                WHERE DATE(created_at) BETWEEN '$start_date' AND '$end_date'";
$sales_result = mysqli_query($conn, $sales_query);
$sales_data = mysqli_fetch_assoc($sales_result);

// Get sales by date for chart
$daily_sales_query = "SELECT 
                     DATE(created_at) as order_date,
                     COUNT(*) as order_count,
                     SUM(total_amount) as daily_sales
                     FROM orders 
                     WHERE DATE(created_at) BETWEEN '$start_date' AND '$end_date'
                     GROUP BY DATE(created_at)
                     ORDER BY order_date";
$daily_sales_result = mysqli_query($conn, $daily_sales_query);

// Prepare data for charts
$dates = [];
$sales_amounts = [];
$order_counts = [];

while ($row = mysqli_fetch_assoc($daily_sales_result)) {
    $dates[] = date('d M', strtotime($row['order_date']));
    $sales_amounts[] = $row['daily_sales'];
    $order_counts[] = $row['order_count'];
}

// Get sales by payment method
$payment_result = null;

// Get top selling products
$top_products_query = "SELECT 
                      p.id, p.name, p.price,
                      SUM(oi.quantity) as total_quantity,
                      SUM(oi.quantity * oi.price) as total_sales
                      FROM order_items oi
                      JOIN products p ON oi.product_id = p.id
                      JOIN orders o ON oi.order_id = o.id
                      WHERE DATE(o.created_at) BETWEEN '$start_date' AND '$end_date'
                      GROUP BY p.id
                      ORDER BY total_quantity DESC
                      LIMIT 10";

// Initialize $top_products_result as null
$top_products_result = null;

try {
    // Try the first query
$top_products_result = mysqli_query($conn, $top_products_query);
    
    // If query fails, set to empty result set
        if (!$top_products_result) {
            // Create empty result set
        $empty_query = "SELECT 1 as id, '' as name, 0 as price, 0 as total_quantity, 0 as total_sales WHERE 1=0";
            $top_products_result = mysqli_query($conn, $empty_query);
            
        echo "<div class='alert alert-warning'>Could not retrieve top selling products.</div>";
    }
} catch (Exception $e) {
    // Handle any other errors
    $empty_query = "SELECT 1 as id, '' as name, 0 as price, 0 as total_quantity, 0 as total_sales WHERE 1=0";
    $top_products_result = mysqli_query($conn, $empty_query);
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}

// Get sales by category
$category_query = "SELECT 
                  c.name as category_name,
                  COUNT(DISTINCT o.id) as order_count,
                  SUM(oi.quantity) as total_quantity,
                  SUM(oi.quantity * oi.price) as total_sales
                  FROM order_items oi
                  JOIN products p ON oi.product_id = p.id
                  JOIN categories c ON p.category_id = c.id
                  JOIN orders o ON oi.order_id = o.id
                  WHERE DATE(o.created_at) BETWEEN '$start_date' AND '$end_date'
                  GROUP BY c.id
                  ORDER BY total_sales DESC";
$category_result = mysqli_query($conn, $category_query);
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="admin-header mb-4">
        <h2>Sales Reports</h2>
        <div>
            <a href="manage_orders.php?start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" class="btn btn-primary">
                <i class="fas fa-shopping-cart"></i> View Orders
            </a>
        </div>
    </div>
    
    <!-- Date Range Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="" method="get" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="start_date" class="form-label">Start Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                <div class="col-md-4">
                    <label for="end_date" class="form-label">End Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Apply Filter</button>
                </div>
            </form>
            <div class="mt-3">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('today')">Today</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('yesterday')">Yesterday</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('7days')">Last 7 Days</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('30days')">Last 30 Days</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('month')">This Month</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setDateRange('year')">This Year</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Sales Summary Cards -->
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Sales</h5>
                    <h2 class="mb-0">₹<?php echo number_format($sales_data['total_sales'] ?? 0, 2); ?></h2>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <small>For period: <?php echo date('d M Y', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Orders</h5>
                    <h2 class="mb-0"><?php echo $sales_data['total_orders'] ?? 0; ?></h2>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <small>Average Order: ₹<?php echo number_format($sales_data['average_order'] ?? 0, 2); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-dark h-100">
                <div class="card-body">
                    <h5 class="card-title">Avg. Daily Sales</h5>
                    <?php
                    $days = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;
                    $avg_daily = ($sales_data['total_sales'] ?? 0) / $days;
                    ?>
                    <h2 class="mb-0">₹<?php echo number_format($avg_daily, 2); ?></h2>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <small>Over <?php echo $days; ?> days</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Sales by Category -->
    <div class="card mb-4">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">Sales by Category</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Orders</th>
                                    <th>Items Sold</th>
                                    <th>Total Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total_category_sales = 0;
                                $category_data = [];
                                
                                // Calculate total sales first
                                mysqli_data_seek($category_result, 0);
                                while ($category = mysqli_fetch_assoc($category_result)) {
                                    $total_category_sales += $category['total_sales'];
                                    $category_data[] = $category;
                                }
                                
                                foreach ($category_data as $category) {
                                ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($category['category_name']); ?></td>
                                        <td><?php echo $category['order_count']; ?></td>
                                        <td><?php echo $category['total_quantity']; ?></td>
                                        <td>₹<?php echo number_format($category['total_sales'], 2); ?></td>
                                    </tr>
                                <?php 
                                }
                                
                                if (empty($category_data)) {
                                    echo '<tr><td colspan="5" class="text-center">No sales data available for the selected period.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-4">
                    <canvas id="categoryChart" height="250"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Inventory Report -->
    <div class="card mb-4">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0">Inventory Status</h5>
        </div>
        <div class="card-body">
            <?php
            // Get inventory status
            $inventory_query = "SELECT 
                              c.name as category_name,
                              COUNT(p.id) as product_count,
                              SUM(p.stock) as total_stock,
                              AVG(p.price) as avg_price,
                              SUM(p.stock * p.price) as inventory_value
                              FROM products p
                              JOIN categories c ON p.category_id = c.id
                              GROUP BY c.id
                              ORDER BY inventory_value DESC";
            $inventory_result = mysqli_query($conn, $inventory_query);
            ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Products</th>
                            <th>Total Stock</th>
                            <th>Inventory Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_inventory_value = 0;
                        while ($inventory = mysqli_fetch_assoc($inventory_result)) {
                            $total_inventory_value += $inventory['inventory_value'];
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($inventory['category_name']); ?></td>
                                <td><?php echo $inventory['product_count']; ?></td>
                                <td><?php echo $inventory['total_stock']; ?></td>
                                <td>₹<?php echo number_format($inventory['inventory_value'], 2); ?></td>
                            </tr>
                        <?php 
                        }
                        ?>
                        <tr class="table-dark">
                            <td colspan="4" class="text-end"><strong>Total Inventory Value:</strong></td>
                            <td><strong>₹<?php echo number_format($total_inventory_value, 2); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Date range functions
    function setDateRange(range) {
        const today = new Date();
        let startDate = new Date();
        let endDate = new Date();
        
        switch(range) {
            case 'today':
                // Start and end are both today
                break;
            case 'yesterday':
                startDate.setDate(today.getDate() - 1);
                endDate.setDate(today.getDate() - 1);
                break;
            case '7days':
                startDate.setDate(today.getDate() - 6);
                break;
            case '30days':
                startDate.setDate(today.getDate() - 29);
                break;
            case 'month':
                startDate = new Date(today.getFullYear(), today.getMonth(), 1);
                endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                break;
            case 'year':
                startDate = new Date(today.getFullYear(), 0, 1);
                endDate = new Date(today.getFullYear(), 11, 31);
                break;
        }
        
        document.getElementById('start_date').value = formatDate(startDate);
        document.getElementById('end_date').value = formatDate(endDate);
        
        // Submit the form
        document.querySelector('form').submit();
    }
    
    function formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
</script>

<?php
// Include admin footer
require_once 'includes/admin_footer.php';
?>
