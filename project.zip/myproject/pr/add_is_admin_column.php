<?php
// Include database connection
require_once 'admin/includes/db_connection.php';

// SQL to add is_admin column if it doesn't exist
$sql = "
    SELECT COUNT(*) as column_exists 
    FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'users' 
    AND COLUMN_NAME = 'is_admin'
";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['column_exists'] == 0) {
    // Column doesn't exist, add it
    $alter_sql = "ALTER TABLE users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0";
    
    if (mysqli_query($conn, $alter_sql)) {
        echo "Success: 'is_admin' column has been added to the 'users' table.";
    } else {
        echo "Error adding column: " . mysqli_error($conn);
    }
} else {
    echo "The 'is_admin' column already exists in the 'users' table.";
}

// Close connection
mysqli_close($conn);
?> 