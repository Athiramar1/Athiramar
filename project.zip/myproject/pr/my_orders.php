<?php
// Include header
require_once 'includes/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page
    echo '<script>window.location.href = "login.php?redirect=my_orders.php";</script>';
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user's orders with pagination
$records_per_page = 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// Check if tables exist
$check_order_status = mysqli_query($conn, "SHOW TABLES LIKE 'order_status'");
$order_status_exists = mysqli_num_rows($check_order_status) > 0;

$check_service_status = mysqli_query($conn, "SHOW TABLES LIKE 'service_status'");
$service_status_exists = mysqli_num_rows($check_service_status) > 0;

// Count total orders for pagination
$count_query = "SELECT COUNT(*) as total FROM orders WHERE user_id = $user_id";
$count_result = mysqli_query($conn, $count_query);
$total_records = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get orders with pagination
if ($order_status_exists) {
    $orders_query = "SELECT o.*, os.name as status_name, os.color as status_color 
                    FROM orders o 
                    LEFT JOIN order_status os ON o.status = os.id 
                    WHERE o.user_id = $user_id 
                    ORDER BY o.created_at DESC 
                    LIMIT $offset, $records_per_page";
} else {
    $orders_query = "SELECT o.*, 
                    CASE o.status 
                        WHEN 1 THEN 'Pending' 
                        WHEN 2 THEN 'Processing' 
                        WHEN 3 THEN 'Shipped' 
                        WHEN 4 THEN 'Delivered' 
                        WHEN 5 THEN 'Cancelled'
                        ELSE 'Unknown' 
                    END as status_name,
                    CASE o.status 
                        WHEN 1 THEN 'warning' 
                        WHEN 2 THEN 'primary' 
                        WHEN 3 THEN 'info' 
                        WHEN 4 THEN 'success' 
                        WHEN 5 THEN 'danger'
                        ELSE 'secondary' 
                    END as status_color
                    FROM orders o 
                    WHERE o.user_id = $user_id 
                    ORDER BY o.created_at DESC 
                    LIMIT $offset, $records_per_page";
}
$orders_result = mysqli_query($conn, $orders_query);

// Check if service_orders table exists
$check_service_orders = mysqli_query($conn, "SHOW TABLES LIKE 'service_orders'");
$service_orders_exists = mysqli_num_rows($check_service_orders) > 0;

if ($service_orders_exists) {
    // Get user's service orders with pagination
    $service_count_query = "SELECT COUNT(*) as total FROM service_orders WHERE user_id = $user_id";
    $service_count_result = mysqli_query($conn, $service_count_query);
    $service_total_records = mysqli_fetch_assoc($service_count_result)['total'];
    $service_total_pages = ceil($service_total_records / $records_per_page);

    // Get service orders with pagination
    if ($service_status_exists) {
        $service_orders_query = "SELECT so.*, s.name as service_name, ss.name as status_name, ss.color as status_color 
                                FROM service_orders so 
                                LEFT JOIN services s ON so.service_id = s.id 
                                LEFT JOIN service_status ss ON so.status = ss.id 
                                WHERE so.user_id = $user_id 
                                ORDER BY so.created_at DESC 
                                LIMIT $offset, $records_per_page";
    } else {
        $service_orders_query = "SELECT so.*, s.name as service_name,
                                CASE so.status 
                                    WHEN 1 THEN 'Pending' 
                                    WHEN 2 THEN 'Confirmed' 
                                    WHEN 3 THEN 'Awaiting Customer' 
                                    WHEN 4 THEN 'Customer Replied' 
                                    WHEN 5 THEN 'In Progress'
                                    WHEN 6 THEN 'Completed'
                                    WHEN 7 THEN 'Cancelled'
                                    ELSE 'Unknown' 
                                END as status_name,
                                CASE so.status 
                                    WHEN 1 THEN 'warning' 
                                    WHEN 2 THEN 'primary' 
                                    WHEN 3 THEN 'info' 
                                    WHEN 4 THEN 'secondary' 
                                    WHEN 5 THEN 'primary'
                                    WHEN 6 THEN 'success'
                                    WHEN 7 THEN 'danger'
                                    ELSE 'secondary' 
                                END as status_color
                                FROM service_orders so 
                                LEFT JOIN services s ON so.service_id = s.id 
                                WHERE so.user_id = $user_id 
                                ORDER BY so.created_at DESC 
                                LIMIT $offset, $records_per_page";
    }
    $service_orders_result = mysqli_query($conn, $service_orders_query);
} else {
    $service_total_records = 0;
    $service_total_pages = 0;
    $service_orders_result = false;
}
?>

<!-- Breadcrumb Section -->
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <h2>My Orders</h2>
                    <div class="breadcrumb-option">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <span>My Orders</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<?php if (false): // Removed notice about missing tables ?>
<div class="container mt-4">
    <div class="alert alert-warning">
        <p><strong>Notice:</strong> Some required database tables are missing. Please run the setup script to create them.</p>
        <a href="admin/includes/create_tables.php" class="btn btn-primary">Run Setup Script</a>
    </div>
</div>
<?php endif; ?>

<!-- Order History Section -->
<section class="order-history-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="products-tab" data-bs-toggle="tab" data-bs-target="#products" type="button" role="tab" aria-controls="products" aria-selected="true">Product Orders</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="services-tab" data-bs-toggle="tab" data-bs-target="#services" type="button" role="tab" aria-controls="services" aria-selected="false">Service Requests</button>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content" id="myTabContent">
                            <!-- Product Orders Tab -->
                            <div class="tab-pane fade show active" id="products" role="tabpanel" aria-labelledby="products-tab">
                                <?php if (mysqli_num_rows($orders_result) > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Order #</th>
                                                    <th>Date</th>
                                                    <th>Items</th>
                                                    <th>Total</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($order = mysqli_fetch_assoc($orders_result)): ?>
                                                    <tr>
                                                        <td><?php echo $order['order_number']; ?></td>
                                                        <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                                        <td>
                                                            <?php
                                                            // Get total items in this order
                                                            $items_query = "SELECT COUNT(*) as total_items FROM order_items WHERE order_id = " . $order['id'];
                                                            $items_result = mysqli_query($conn, $items_query);
                                                            $items_count = mysqli_fetch_assoc($items_result)['total_items'];
                                                            
                                                            // Get first product name to display
                                                            $product_query = "SELECT oi.*, p.name as product_name 
                                                                             FROM order_items oi 
                                                                             LEFT JOIN products p ON oi.product_id = p.id 
                                                                             WHERE oi.order_id = " . $order['id'] . " 
                                                                             LIMIT 1";
                                                            $product_result = mysqli_query($conn, $product_query);
                                                            
                                                            if (mysqli_num_rows($product_result) > 0) {
                                                                $product = mysqli_fetch_assoc($product_result);
                                                                $product_name = !empty($product['product_name']) ? $product['product_name'] : 
                                                                               (!empty($product['product_name']) ? $product['product_name'] : 'Product');
                                                                
                                                                echo $product_name;
                                                                if ($items_count > 1) {
                                                                    echo ' <span class="badge bg-secondary">+' . ($items_count - 1) . ' more</span>';
                                                                }
                                                            } else {
                                                                echo $items_count . ' item' . ($items_count > 1 ? 's' : '');
                                                            }
                                                            ?>
                                                        </td>
                                                        <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $order['status_color']; ?>">
                                                                <?php echo $order['status_name']; ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-info">
                                                                View Details
                                                            </a>
                                                            <a href="shop.php?reorder=<?php echo $order['id']; ?>" class="btn btn-sm btn-success">
                                                                Order Again
                                                            </a>
                                                            <?php if ($order['status'] == 1): // Only show cancel button for pending orders ?>
                                                            <button class="btn btn-sm btn-danger delete-order" data-id="<?php echo $order['id']; ?>">
                                                                Cancel
                                                            </button>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <!-- Pagination for Product Orders -->
                                    <?php if ($total_pages > 1): ?>
                                    <nav aria-label="Page navigation">
                                        <ul class="pagination justify-content-center mt-4">
                                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&tab=products">Previous</a>
                                            </li>
                                            
                                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $total_pages); $i++): ?>
                                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                                    <a class="page-link" href="?page=<?php echo $i; ?>&tab=products"><?php echo $i; ?></a>
                                                </li>
                                            <?php endfor; ?>
                                            
                                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&tab=products">Next</a>
                                            </li>
                                        </ul>
                                    </nav>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <p class="mb-0">You haven't placed any product orders yet.</p>
                                        <a href="shop.php" class="btn btn-primary mt-3">Shop Now</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Service Orders Tab -->
                            <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="services-tab">
                                <?php if (mysqli_num_rows($service_orders_result) > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Request #</th>
                                                    <th>Date</th>
                                                    <th>Service</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($service_order = mysqli_fetch_assoc($service_orders_result)): ?>
                                                    <tr>
                                                        <td><?php echo $service_order['order_number']; ?></td>
                                                        <td><?php echo date('d M Y', strtotime($service_order['created_at'])); ?></td>
                                                        <td><?php echo htmlspecialchars($service_order['service_name']); ?></td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $service_order['status_color']; ?>">
                                                                <?php echo $service_order['status_name']; ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <a href="service_request_details.php?id=<?php echo $service_order['id']; ?>" class="btn btn-sm btn-info">
                                                                View Details
                                                            </a>
                                                            <?php if ($service_order['status'] <= 2): // Only show cancel button for pending/confirmed requests ?>
                                                            <button class="btn btn-sm btn-danger delete-service-request" data-id="<?php echo $service_order['id']; ?>">
                                                                Cancel
                                                            </button>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <!-- Pagination for Service Orders -->
                                    <?php if ($service_total_pages > 1): ?>
                                    <nav aria-label="Page navigation">
                                        <ul class="pagination justify-content-center mt-4">
                                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&tab=services">Previous</a>
                                            </li>
                                            
                                            <?php for ($i = max(1, $page - 2); $i <= min($page + 2, $service_total_pages); $i++): ?>
                                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                                    <a class="page-link" href="?page=<?php echo $i; ?>&tab=services"><?php echo $i; ?></a>
                                                </li>
                                            <?php endfor; ?>
                                            
                                            <li class="page-item <?php echo $page >= $service_total_pages ? 'disabled' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&tab=services">Next</a>
                                            </li>
                                        </ul>
                                    </nav>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <p class="mb-0">You haven't requested any services yet.</p>
                                        <a href="services.php" class="btn btn-primary mt-3">Browse Services</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- JavaScript to handle tab navigation via URL parameter -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check for tab parameter in URL
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('tab');
    
    if (tab === 'services') {
        // Activate services tab
        document.getElementById('services-tab').click();
    }
    
    // Add event listeners for service request delete buttons
    document.querySelectorAll('.delete-service-request').forEach(button => {
        button.addEventListener('click', function() {
            const requestId = this.getAttribute('data-id');
            if (confirm('Are you sure you want to cancel this service request? This action cannot be undone.')) {
                // Send AJAX request to delete the service request
                fetch('delete_service_request.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'id=' + requestId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Refresh the page to show updated status
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the service request.');
                });
            }
        });
    });
    
    // Add event listeners for product order delete buttons
    document.querySelectorAll('.delete-order').forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.getAttribute('data-id');
            if (confirm('Are you sure you want to cancel this order? This action cannot be undone.')) {
                // Send AJAX request to delete the order
                fetch('delete_order.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'id=' + orderId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Refresh the page to show updated status
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the order.');
                });
            }
        });
    });
});
</script>

<?php
// Include footer
require_once 'includes/footer.php';
?> 