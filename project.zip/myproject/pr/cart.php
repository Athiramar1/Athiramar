<?php
require_once 'includes/header.php';

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Process cart actions
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    // Remove item from cart
    if ($action === 'remove' && isset($_GET['index'])) {
        $index = intval($_GET['index']);
        if (isset($_SESSION['cart'][$index])) {
            unset($_SESSION['cart'][$index]);
            // Re-index the array
            $_SESSION['cart'] = array_values($_SESSION['cart']);
        }
    }
    
    // Update quantity
    if ($action === 'update' && isset($_POST['quantity'])) {
        $quantities = $_POST['quantity'];
        foreach ($quantities as $index => $quantity) {
            if (isset($_SESSION['cart'][$index])) {
                $_SESSION['cart'][$index]['quantity'] = max(1, intval($quantity));
            }
        }
    }
    
    // Clear cart
    if ($action === 'clear') {
        $_SESSION['cart'] = array();
    }
}

// Calculate cart totals
$cart_total = 0;
$cart_items = 0;

foreach ($_SESSION['cart'] as $item) {
    $cart_total += $item['price'] * $item['quantity'];
    $cart_items += $item['quantity'];
}
?>

<!-- Breadcrumb Section -->
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <h2>Shopping Cart</h2>
                    <div class="breadcrumb-option">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="shop.php">Shop</a>
                        <span>Cart</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<!-- Shopping Cart Section -->
<section class="shopping-cart spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="cart-table">
                    <?php if (count($_SESSION['cart']) > 0): ?>
                    <form action="cart.php?action=update" method="post">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($_SESSION['cart'] as $index => $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                    <td>
                                        <div class="quantity">
                                            <input type="number" name="quantity[<?php echo $index; ?>]" min="1" value="<?php echo $item['quantity']; ?>" class="form-control">
                                        </div>
                                    </td>
                                    <td>₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                    <td>
                                        <a href="cart.php?action=remove&index=<?php echo $index; ?>" class="btn btn-sm btn-danger">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div class="row mt-4">
                            <div class="col-lg-6">
                                <div class="cart-buttons">
                                    <a href="shop.php" class="btn btn-secondary">Continue Shopping</a>
                                    <button type="submit" class="btn btn-primary">Update Cart</button>
                                    <a href="cart.php?action=clear" class="btn btn-danger">Clear Cart</a>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="cart-total text-end">
                                    <h4>Cart Total: ₹<?php echo number_format($cart_total, 2); ?></h4>
                                    <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>
                                </div>
                            </div>
                        </div>
                    </form>
                    <?php else: ?>
                    <div class="alert alert-info">
                        <p>Your cart is empty.</p>
                        <a href="shop.php" class="btn btn-primary mt-3">Go to Shop</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shopping Cart Section End -->

<?php
require_once 'includes/footer.php';
?> 