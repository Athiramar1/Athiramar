<?php
// Set content type to text
header('Content-Type: text/plain');
echo "Delete Specific Invoice File\n";
echo "===========================\n\n";

// Get filename from query parameter
$filename = isset($_GET['file']) ? trim($_GET['file']) : '';

if (empty($filename)) {
    echo "ERROR: No filename provided\n";
    echo "Usage: delete_invoice_file.php?file=filename.pdf\n";
    exit;
}

// Validate filename (prevent directory traversal)
if (preg_match('/[\/\\\\]/', $filename)) {
    echo "ERROR: Invalid filename. File name should not contain slashes.\n";
    exit;
}

// Path to print_invoice directory and file
$directory = 'exports/print_invoice';
$file_path = $directory . '/' . $filename;

// Check if directory exists
if (!file_exists($directory)) {
    echo "ERROR: Directory does not exist: $directory\n";
    exit;
}

// Check if file exists
if (!file_exists($file_path)) {
    echo "ERROR: File not found: $filename\n";
    echo "\nAvailable files:\n";
    $files = glob($directory . '/*');
    if (count($files) > 0) {
        foreach ($files as $file) {
            echo "- " . basename($file) . "\n";
        }
    } else {
        echo "No files in directory.\n";
    }
    exit;
}

// Delete the file
echo "Deleting file: $filename... ";
if (unlink($file_path)) {
    echo "DELETED\n";
} else {
    echo "FAILED\n";
    echo "Error: " . error_get_last()['message'] . "\n";
}

echo "\n----------------------------------------\n";
echo "Operation completed at: " . date('Y-m-d H:i:s') . "\n";
?> 