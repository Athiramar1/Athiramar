<?php 
require_once 'includes/header.php';

// Display account deletion message
if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
    echo '<div class="container mt-3">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Your account has been successfully deleted. We\'re sorry to see you go!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          </div>';
}
?>

<!-- Carousel Section -->
<div id="mainCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="assets/images/1.jpg" class="d-block w-100" alt="Offset Printing Services">
            <div class="carousel-caption d-none d-md-block">
                <h2>Professional Offset Printing Services</h2>
                <p>High-quality printing solutions for all your business needs</p>
                <a href="services.php" class="btn btn-primary">Explore Services</a>
            </div>
        </div>
        <div class="carousel-item">
            <img src="assets/images/2.jpg" class="d-block w-100" alt="Business Cards and Brochures">
            <div class="carousel-caption d-none d-md-block">
                <h2>Business Cards & Brochures</h2>
                <p>Make a lasting impression with our premium printing options</p>
                <a href="services.php" class="btn btn-primary">View Products</a>
            </div>
        </div>
        <div class="carousel-item">
            <img src="assets/images/3.jpg" class="d-block w-100" alt="Custom Printing Solutions">
            <div class="carousel-caption d-none d-md-block">
                <h2>Custom Printing Solutions</h2>
                <p>Tailored to meet your specific requirements</p>
                <a href="contact.php" class="btn btn-primary">Contact Us</a>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<!-- Banner Section -->
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="banner">
                <img src="assets/images/4.jpg" alt="Quality Printing">
                <div class="banner-content">
                    <h3>Quality Printing Services</h3>
                    <p>We use state-of-the-art technology for the best results</p>
                    <a href="services.php" class="btn btn-light">Learn More</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="banner">
                <img src="assets/images/5.png" alt="Fast Turnaround">
                <div class="banner-content">
                    <h3>Fast Turnaround Time</h3>
                    <p>Get your prints delivered on time, every time</p>
                    <a href="contact.php" class="btn btn-light">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Product Categories Section -->
<div class="container mt-5">
    <h2 class="text-center mb-5">Product Categories</h2>
    <div class="row">
        <!-- Business Cards -->
        <div class="col-md-4 mb-4">
            <div class="card category-card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-id-card category-icon"></i>
                    <h3 class="card-title">Business Cards</h3>
                    <p class="card-text">Make a lasting impression with our premium business cards. Available in various paper stocks, finishes, and sizes to suit your professional needs. Our high-quality printing ensures your cards stand out from the competition.</p>
                    <a href="services.php#business-cards" class="btn btn-primary">View Options</a>
                </div>
            </div>
        </div>
        
        <!-- Brochures -->
        <div class="col-md-4 mb-4">
            <div class="card category-card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-book-open category-icon"></i>
                    <h3 class="card-title">Brochures</h3>
                    <p class="card-text">Showcase your products and services with our professionally designed brochures. Available in bi-fold, tri-fold, and z-fold options with customizable sizes and paper types. Perfect for marketing campaigns and information distribution.</p>
                    <a href="services.php#brochures" class="btn btn-primary">View Options</a>
                </div>
            </div>
        </div>
        
        <!-- Flyers -->
        <div class="col-md-4 mb-4">
            <div class="card category-card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-file category-icon"></i>
                    <h3 class="card-title">Flyers</h3>
                    <p class="card-text">Spread the word about your events, promotions, and announcements with our eye-catching flyers. Available in various sizes and paper options, our flyers are printed with vibrant colors to grab attention and deliver your message effectively.</p>
                    <a href="services.php#flyers" class="btn btn-primary">View Options</a>
                </div>
            </div>
        </div>
        
        <!-- Postcards -->
        <div class="col-md-6 mb-4">
            <div class="card category-card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-mail-bulk category-icon"></i>
                    <h3 class="card-title">Postcards</h3>
                    <p class="card-text">Send personalized messages with our high-quality postcards. Perfect for direct mail marketing, thank you notes, or special announcements. Choose from standard or custom sizes with various paper stocks and finishing options for a professional look.</p>
                    <a href="services.php#postcards" class="btn btn-primary">View Options</a>
                </div>
            </div>
        </div>
        
        <!-- Letterheads -->
        <div class="col-md-6 mb-4">
            <div class="card category-card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-file-alt category-icon"></i>
                    <h3 class="card-title">Letterheads</h3>
                    <p class="card-text">Enhance your business correspondence with our professional letterheads. Available in standard A4 size with premium paper options and customizable designs. Our letterheads help maintain your brand identity across all business communications.</p>
                    <a href="services.php#letterheads" class="btn btn-primary">View Options</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>
