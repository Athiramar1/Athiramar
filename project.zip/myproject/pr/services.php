<?php 
require_once 'includes/header.php';

// Get categories from database
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_query);

// Get products from database
$products_query = "SELECT p.*, c.name as category_name FROM products p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  ORDER BY p.category_id, p.name";
$products_result = mysqli_query($conn, $products_query);

// Create an array to store products by category
$products_by_category = array();
while ($product = mysqli_fetch_assoc($products_result)) {
    $category_id = $product['category_id'];
    if (!isset($products_by_category[$category_id])) {
        $products_by_category[$category_id] = array();
    }
    $products_by_category[$category_id][] = $product;
}

// Get services from database
$services_table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'services'");
if (mysqli_num_rows($services_table_exists) > 0) {
    $services_query = "SELECT * FROM services WHERE status = 1 ORDER BY name";
    $services_result = mysqli_query($conn, $services_query);
} else {
    // Table doesn't exist, use empty result
    $services_result = false;
}

// Check if required tables exist
$check_service_status = mysqli_query($conn, "SHOW TABLES LIKE 'service_status'");
$service_status_exists = mysqli_num_rows($check_service_status) > 0;

// Check if service_orders table exists
$check_service_orders = mysqli_query($conn, "SHOW TABLES LIKE 'service_orders'");
$service_orders_exists = mysqli_num_rows($check_service_orders) > 0;

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_service'])) {
    // Get form data
    $service_id = intval($_POST['service_id']);
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    $preferred_date = sanitize_input($_POST['preferred_date']);
    $preferred_time = sanitize_input($_POST['preferred_time']);
    $requirements = sanitize_input($_POST['requirements']);
    
    // Validate form data
    $errors = [];
    if (empty($service_id)) {
        $errors[] = "Service is required";
    }
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }
    if (empty($phone)) {
        $errors[] = "Phone number is required";
    }
    if (empty($address)) {
        $errors[] = "Address is required";
    }
    if (empty($preferred_date)) {
        $errors[] = "Preferred date is required";
    }
    if (empty($preferred_time)) {
        $errors[] = "Preferred time is required";
    }
    
    if (empty($errors)) {
        // Check if service exists
        $service_check = "SELECT * FROM services WHERE id = $service_id AND status = 1";
        $service_result = mysqli_query($conn, $service_check);
        
        if (mysqli_num_rows($service_result) > 0) {
            // Generate order number
            $order_number = 'SRV-' . date('Ymd') . '-' . rand(1000, 9999);
            
            // Get user ID if logged in
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
            
            // Insert service order
            $insert_query = "INSERT INTO service_orders (service_id, user_id, order_number, name, email, phone, address, 
                            preferred_date, preferred_time, requirements, status, created_at) 
                            VALUES ($service_id, $user_id, '$order_number', '$name', '$email', '$phone', '$address', 
                            '$preferred_date', '$preferred_time', '$requirements', 1, NOW())";
            
            if (mysqli_query($conn, $insert_query)) {
                $service_order_id = mysqli_insert_id($conn);
                
                if ($user_id > 0) {
                    // If user is logged in, redirect to service request details
                    $_SESSION['success'] = "Your service request has been submitted successfully";
                    header("Location: my_orders.php?tab=services");
                    exit;
                } else {
                    // If user is not logged in, show success message
                    $success_message = "Your service request has been submitted successfully. Our team will contact you soon.";
                }
            } else {
                $error_message = "Error: " . mysqli_error($conn);
            }
        } else {
            $error_message = "Invalid service selected";
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}

// Handle add to my orders functionality
if (isset($_GET['add_to_orders']) && !empty($_GET['add_to_orders']) && isset($_SESSION['user_id'])) {
    $service_id = intval($_GET['add_to_orders']);
    
    // Check if service exists
    $service_check = "SELECT * FROM services WHERE id = $service_id AND status = 1";
    $service_result = mysqli_query($conn, $service_check);
    
    if (mysqli_num_rows($service_result) > 0) {
        $service = mysqli_fetch_assoc($service_result);
        
        // Set session to prefill service request form
        $_SESSION['prefill_service'] = [
            'service_id' => $service_id,
            'service_name' => $service['name']
        ];
        
        // Redirect to service request form
        echo '<script>
            $(document).ready(function() {
                $("#serviceRequestModal").modal("show");
            });
        </script>';
    }
}
?>

<!-- Services Banner -->
<div class="container-fluid p-0">
    <div class="banner">
        <img src="assets/images/service1.jpg" alt="Our Services">
        <div class="banner-content">
            <h1>Our Printing Services</h1>
            <p>High-quality offset printing solutions for all your business needs</p>
        </div>
    </div>
</div>

<!-- Category Icons -->
<div class="container mt-5">
    <div class="row text-center">
        <div class="col-12 mb-4">
            <h2>Product Categories</h2>
            <p>Browse our wide range of printing services</p>
        </div>
        
        <div class="col-12">
            <div class="d-flex justify-content-center flex-wrap">
                <button class="btn btn-outline-primary m-2 category-filter active" data-category="all">
                    <i class="fas fa-th-large"></i> All Categories
                </button>
                
                <?php while ($category = mysqli_fetch_assoc($categories_result)): ?>
                <button class="btn btn-outline-primary m-2 category-filter" data-category="<?php echo $category['id']; ?>" id="<?php echo strtolower(str_replace(' ', '-', $category['name'])); ?>">
                    <?php 
                    $icon = '';
                    switch(strtolower($category['name'])) {
                        case 'business cards':
                            $icon = 'fas fa-id-card';
                            break;
                        case 'brochures':
                            $icon = 'fas fa-book-open';
                            break;
                        case 'flyers':
                            $icon = 'fas fa-file';
                            break;
                        case 'postcards':
                            $icon = 'fas fa-mail-bulk';
                            break;
                        case 'letterheads':
                            $icon = 'fas fa-file-alt';
                            break;
                        default:
                            $icon = 'fas fa-print';
                    }
                    ?>
                    <i class="<?php echo $icon; ?>"></i> <?php echo $category['name']; ?>
                </button>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>

<!-- Products Section -->
<div class="container mt-5">
    <div class="row">
        <?php 
        // If no products in database, show sample products
        if (mysqli_num_rows($products_result) == 0) {
            // Sample products for each category
            $sample_products = [
                // Business Cards
                [
                    'category_id' => 1,
                    'category_name' => 'Business Cards',
                    'products' => [
                        ['name' => 'Standard Business Card', 'size' => '3.5" x 2"', 'price' => 499, 'description' => 'Classic business cards printed on 300gsm art card with matte or glossy finish.'],
                        ['name' => 'Premium Business Card', 'size' => '3.5" x 2"', 'price' => 799, 'description' => 'Premium business cards with spot UV coating on 350gsm art card.'],
                        ['name' => 'Square Business Card', 'size' => '2.5" x 2.5"', 'price' => 599, 'description' => 'Unique square-shaped business cards to stand out from the crowd.'],
                        ['name' => 'Folded Business Card', 'size' => '3.5" x 4" (folded)', 'price' => 899, 'description' => 'Folded business cards with more space for information.'],
                        ['name' => 'Rounded Corner Business Card', 'size' => '3.5" x 2"', 'price' => 549, 'description' => 'Business cards with rounded corners for a modern look.'],
                        ['name' => 'Textured Business Card', 'size' => '3.5" x 2"', 'price' => 699, 'description' => 'Business cards printed on textured paper for an elegant feel.'],
                        ['name' => 'Metallic Business Card', 'size' => '3.5" x 2"', 'price' => 999, 'description' => 'Luxury business cards with metallic ink printing.'],
                        ['name' => 'Transparent Business Card', 'size' => '3.5" x 2"', 'price' => 1299, 'description' => 'Modern transparent business cards for a unique impression.'],
                        ['name' => 'Eco-friendly Business Card', 'size' => '3.5" x 2"', 'price' => 649, 'description' => 'Business cards printed on recycled paper.'],
                        ['name' => 'Mini Business Card', 'size' => '2.5" x 1.5"', 'price' => 449, 'description' => 'Compact business cards that fit in any wallet.']
                    ]
                ],
                // Brochures
                [
                    'category_id' => 2,
                    'category_name' => 'Brochures',
                    'products' => [
                        ['name' => 'Bi-fold Brochure', 'size' => 'A4 (folded to A5)', 'price' => 1499, 'description' => 'Standard bi-fold brochures printed on 130gsm art paper.'],
                        ['name' => 'Tri-fold Brochure', 'size' => 'A4 (folded to DL)', 'price' => 1699, 'description' => 'Popular tri-fold brochures with three panels on each side.'],
                        ['name' => 'Z-fold Brochure', 'size' => 'A4 (folded to DL)', 'price' => 1799, 'description' => 'Z-fold brochures with unique folding style for creative layouts.'],
                        ['name' => 'Gate-fold Brochure', 'size' => 'A4 (folded)', 'price' => 1999, 'description' => 'Gate-fold brochures with center panels that open like gates.'],
                        ['name' => 'Roll-fold Brochure', 'size' => 'A4 (folded)', 'price' => 1899, 'description' => 'Roll-fold brochures with multiple panels folded in sequence.'],
                        ['name' => 'Square Brochure', 'size' => '210mm x 210mm', 'price' => 1599, 'description' => 'Square brochures for a modern and unique presentation.'],
                        ['name' => 'A5 Brochure', 'size' => 'A5', 'price' => 1299, 'description' => 'Compact A5 size brochures for concise information.'],
                        ['name' => 'A3 Brochure', 'size' => 'A3 (folded to A4)', 'price' => 2499, 'description' => 'Large format A3 brochures folded to A4 size.'],
                        ['name' => 'Glossy Brochure', 'size' => 'A4', 'price' => 1599, 'description' => 'Brochures printed on glossy 170gsm art paper for vibrant colors.'],
                        ['name' => 'Matte Brochure', 'size' => 'A4', 'price' => 1599, 'description' => 'Brochures printed on matte 170gsm art paper for elegant look.']
                    ]
                ],
                // Flyers
                [
                    'category_id' => 3,
                    'category_name' => 'Flyers',
                    'products' => [
                        ['name' => 'A6 Flyer', 'size' => 'A6 (105mm x 148mm)', 'price' => 899, 'description' => 'Compact A6 size flyers perfect for handouts.'],
                        ['name' => 'A5 Flyer', 'size' => 'A5 (148mm x 210mm)', 'price' => 1099, 'description' => 'Standard A5 size flyers for promotions and events.'],
                        ['name' => 'A4 Flyer', 'size' => 'A4 (210mm x 297mm)', 'price' => 1499, 'description' => 'Large A4 size flyers with ample space for information.'],
                        ['name' => 'DL Flyer', 'size' => 'DL (99mm x 210mm)', 'price' => 999, 'description' => 'DL size flyers that fit in standard envelopes.'],
                        ['name' => 'Square Flyer', 'size' => '148mm x 148mm', 'price' => 1199, 'description' => 'Square flyers for a unique and modern look.'],
                        ['name' => 'Double-sided Flyer', 'size' => 'A5', 'price' => 1299, 'description' => 'A5 flyers printed on both sides for more content.'],
                        ['name' => 'Premium Flyer', 'size' => 'A5', 'price' => 1399, 'description' => 'Premium flyers printed on 250gsm art paper with glossy finish.'],
                        ['name' => 'Economy Flyer', 'size' => 'A5', 'price' => 899, 'description' => 'Budget-friendly flyers printed on 130gsm art paper.'],
                        ['name' => 'Folded Flyer', 'size' => 'A4 (folded to A5)', 'price' => 1599, 'description' => 'Folded flyers with more space for content.'],
                        ['name' => 'Mini Flyer', 'size' => '74mm x 105mm', 'price' => 799, 'description' => 'Mini flyers for quick information distribution.']
                    ]
                ],
                // Postcards
                [
                    'category_id' => 4,
                    'category_name' => 'Postcards',
                    'products' => [
                        ['name' => 'Standard Postcard', 'size' => '4" x 6"', 'price' => 699, 'description' => 'Standard size postcards printed on 300gsm art card.'],
                        ['name' => 'Large Postcard', 'size' => '5" x 7"', 'price' => 899, 'description' => 'Large postcards with more space for your message.'],
                        ['name' => 'Square Postcard', 'size' => '5" x 5"', 'price' => 799, 'description' => 'Square postcards for a modern and unique look.'],
                        ['name' => 'Double-sided Postcard', 'size' => '4" x 6"', 'price' => 799, 'description' => 'Postcards printed on both sides with full color.'],
                        ['name' => 'Premium Postcard', 'size' => '4" x 6"', 'price' => 899, 'description' => 'Premium postcards with spot UV coating for highlights.'],
                        ['name' => 'Matte Postcard', 'size' => '4" x 6"', 'price' => 749, 'description' => 'Postcards with elegant matte finish.'],
                        ['name' => 'Glossy Postcard', 'size' => '4" x 6"', 'price' => 749, 'description' => 'Postcards with vibrant glossy finish.'],
                        ['name' => 'Textured Postcard', 'size' => '4" x 6"', 'price' => 849, 'description' => 'Postcards printed on textured paper for a premium feel.'],
                        ['name' => 'Mini Postcard', 'size' => '3.5" x 5"', 'price' => 599, 'description' => 'Compact postcards for quick messages.'],
                        ['name' => 'Oversized Postcard', 'size' => '6" x 9"', 'price' => 1099, 'description' => 'Extra large postcards that stand out in the mail.']
                    ]
                ],
                // Letterheads
                [
                    'category_id' => 5,
                    'category_name' => 'Letterheads',
                    'products' => [
                        ['name' => 'Standard Letterhead', 'size' => 'A4', 'price' => 1299, 'description' => 'Standard letterheads printed on 100gsm bond paper.'],
                        ['name' => 'Premium Letterhead', 'size' => 'A4', 'price' => 1599, 'description' => 'Premium letterheads printed on 120gsm textured paper.'],
                        ['name' => 'Watermarked Letterhead', 'size' => 'A4', 'price' => 1799, 'description' => 'Letterheads with subtle watermark for added security.'],
                        ['name' => 'Colored Letterhead', 'size' => 'A4', 'price' => 1499, 'description' => 'Letterheads printed on light colored paper.'],
                        ['name' => 'Executive Letterhead', 'size' => 'A4', 'price' => 1899, 'description' => 'Executive letterheads with gold or silver accents.'],
                        ['name' => 'Digital Letterhead', 'size' => 'A4 (Digital PDF)', 'price' => 999, 'description' => 'Digital letterhead templates for electronic communications.'],
                        ['name' => 'Legal Letterhead', 'size' => 'Legal (8.5" x 14")', 'price' => 1499, 'description' => 'Legal size letterheads for official documents.'],
                        ['name' => 'Embossed Letterhead', 'size' => 'A4', 'price' => 2099, 'description' => 'Letterheads with embossed logo or text for a premium feel.'],
                        ['name' => 'Eco-friendly Letterhead', 'size' => 'A4', 'price' => 1399, 'description' => 'Letterheads printed on recycled paper.'],
                        ['name' => 'Double-sided Letterhead', 'size' => 'A4', 'price' => 1699, 'description' => 'Letterheads printed on both sides for versatility.']
                    ]
                ]
            ];
            
            foreach ($sample_products as $category) {
                echo '<div class="col-12 mb-5" id="' . strtolower(str_replace(' ', '-', $category['category_name'])) . '">';
                echo '<h2 class="border-bottom pb-2">' . $category['category_name'] . '</h2>';
                echo '<div class="row">';
                
                foreach ($category['products'] as $product) {
                    echo '<div class="col-md-4 mb-4 product-item" data-category="' . $category['category_id'] . '">';
                    echo '<div class="card product-card h-100">';
                    echo '<img src="assets/images/product-placeholder.jpg" class="card-img-top product-img" alt="' . $product['name'] . '">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . $product['name'] . '</h5>';
                    echo '<p class="card-text">' . $product['description'] . '</p>';
                    if (isset($product['size']) && !empty($product['size'])) {
                        echo '<p><strong>Size:</strong> ' . $product['size'] . '</p>';
                    }
                    echo '<p class="text-primary fw-bold">₹' . number_format($product['price'], 2) . '</p>';
                    echo '<div class="d-flex gap-2">';
                    echo '<a href="contact.php?product_name=' . urlencode($product['name']) . '&price=' . $product['price'] . '" class="btn btn-primary flex-grow-1">Buy Now</a>';
                    echo '</div>';
                    echo '</div></div></div>';
                }
                
                echo '</div></div>';
            }
        } else {
            // Reset the pointer to the beginning of the result set
            mysqli_data_seek($products_result, 0);
            
            // Group products by category
            $current_category = null;
            
            while ($product = mysqli_fetch_assoc($products_result)) {
                if ($current_category != $product['category_id']) {
                    // Close previous category div if not the first one
                    if ($current_category !== null) {
                        echo '</div></div>';
                    }
                    
                    $current_category = $product['category_id'];
                    echo '<div class="col-12 mb-5" id="' . strtolower(str_replace(' ', '-', $product['category_name'])) . '">';
                    echo '<h2 class="border-bottom pb-2">' . $product['category_name'] . '</h2>';
                    echo '<div class="row">';
                }
                
                echo '<div class="col-md-4 mb-4 product-item" data-category="' . $product['category_id'] . '">';
                echo '<div class="card product-card h-100">';
                if (!empty($product['image'])) {
                    echo '<img src="' . $product['image'] . '" class="card-img-top product-img" alt="' . $product['name'] . '">';
                } else {
                    echo '<img src="assets/images/product-placeholder.jpg" class="card-img-top product-img" alt="' . $product['name'] . '">';
                }
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . $product['name'] . '</h5>';
                echo '<p class="card-text">' . $product['description'] . '</p>';
                if (isset($product['size']) && !empty($product['size'])) {
                    echo '<p><strong>Size:</strong> ' . $product['size'] . '</p>';
                }
                echo '<p class="text-primary fw-bold">₹' . number_format($product['price'], 2) . '</p>';
                echo '<div class="d-flex gap-2">';
                echo '<a href="contact.php?product_name=' . urlencode($product['name']) . '&price=' . $product['price'] . '&product=' . $product['id'] . '" class="btn btn-primary flex-grow-1">Buy Now</a>';
                echo '</div>';
                echo '</div></div></div>';
            }
            
            // Close the last category div
            if ($current_category !== null) {
                echo '</div></div>';
            }
        }
        ?>
    </div>
</div>

<!-- Services Section -->
<section class="services-section spad">
    <div class="container">
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h2>Professional Printing Services</h2>
                    <p>We offer a wide range of high-quality printing services to meet your needs.</p>
                </div>
            </div>
        </div>
        
        <!-- Services List -->
        <div class="row">
            <?php if ($services_result && mysqli_num_rows($services_result) > 0): ?>
                <?php while ($service = mysqli_fetch_assoc($services_result)): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card service-card h-100">
                            <?php if (!empty($service['image'])): ?>
                                <img src="<?php echo $service['image']; ?>" class="card-img-top" alt="<?php echo $service['name']; ?>">
                            <?php else: ?>
                                <img src="assets/images/service-placeholder.jpg" class="card-img-top" alt="<?php echo $service['name']; ?>">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $service['name']; ?></h5>
                                <p class="card-text"><?php echo nl2br($service['description']); ?></p>
                                <div class="price mb-3">Starting at ₹<?php echo number_format($service['price'], 2); ?></div>
                                <div class="d-flex justify-content-between">
                                    <button class="btn btn-primary request-service-btn" data-bs-toggle="modal" data-bs-target="#serviceRequestModal" data-service-id="<?php echo $service['id']; ?>" data-service-name="<?php echo $service['name']; ?>">
                                        Request Service
                                    </button>
                                    <?php if (isset($_SESSION['user_id'])): ?>
                                    <a href="manage_orders.php?add_service=<?php echo $service['id']; ?>" class="btn btn-outline-primary">
                                        Add to My Orders
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-body text-center py-5">
                            <h3>Our Services</h3>
                            <p class="mb-4">We offer a wide range of professional printing services. Please contact us for more information.</p>
                            <div class="mt-3">
                                <a href="contact.php" class="btn btn-primary">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="row mt-5">
            <div class="col-lg-12 text-center">
                <h4>Already requested a service?</h4>
                <p>You can view and track your service requests in your account.</p>
                <a href="my_orders.php?tab=services" class="btn btn-secondary">
                    <i class="fas fa-clipboard-list me-2"></i> View My Service Requests
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Service Request Modal -->
<div class="modal fade" id="serviceRequestModal" tabindex="-1" aria-labelledby="serviceRequestModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="serviceRequestModalLabel">Request Service</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="services.php" method="post" id="serviceRequestForm">
                    <input type="hidden" name="service_id" id="service_id" value="<?php echo isset($_SESSION['prefill_service']) ? $_SESSION['prefill_service']['service_id'] : ''; ?>">
                    
                    <div class="mb-3">
                        <label for="service_name" class="form-label">Service</label>
                        <input type="text" class="form-control" id="service_name" readonly value="<?php echo isset($_SESSION['prefill_service']) ? $_SESSION['prefill_service']['service_name'] : ''; ?>">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="name" name="name" required value="<?php echo isset($_SESSION['user_name']) ? $_SESSION['user_name'] : ''; ?>">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required value="<?php echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="preferred_date" class="form-label">Preferred Date</label>
                            <input type="date" class="form-control" id="preferred_date" name="preferred_date" required min="<?php echo date('Y-m-d'); ?>">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="preferred_time" class="form-label">Preferred Time</label>
                            <select class="form-select" id="preferred_time" name="preferred_time" required>
                                <option value="">Select Time</option>
                                <option value="Morning (9AM - 12PM)">Morning (9AM - 12PM)</option>
                                <option value="Afternoon (12PM - 3PM)">Afternoon (12PM - 3PM)</option>
                                <option value="Evening (3PM - 6PM)">Evening (3PM - 6PM)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="requirements" class="form-label">Special Requirements</label>
                        <textarea class="form-control" id="requirements" name="requirements" rows="4"></textarea>
                    </div>
                    
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" name="request_service">Submit Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for Service Request Modal -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle service request button click
    document.querySelectorAll('.request-service-btn').forEach(button => {
        button.addEventListener('click', function() {
            const serviceId = this.getAttribute('data-service-id');
            const serviceName = this.getAttribute('data-service-name');
            
            document.getElementById('service_id').value = serviceId;
            document.getElementById('service_name').value = serviceName;
        });
    });
    
    // Set minimum date for preferred date
    document.getElementById('preferred_date').min = new Date().toISOString().split('T')[0];
});
</script>

<?php
// Clear prefill data after showing modal
if (isset($_SESSION['prefill_service'])) {
    unset($_SESSION['prefill_service']);
}

require_once 'includes/footer.php';
?>
