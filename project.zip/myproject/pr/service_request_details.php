<?php
// Include header
require_once 'includes/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page
    echo '<script>window.location.href = "login.php?redirect=my_orders.php";</script>';
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if service request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Invalid service request ID.";
    header("Location: my_orders.php?tab=services");
    exit;
}

$request_id = intval($_GET['id']);

// Get service request details
$request_query = "SELECT so.*, s.name as service_name, s.price as service_price, s.description as service_description, s.image as service_image,
                CASE so.status 
                    WHEN 1 THEN 'Pending' 
                    WHEN 2 THEN 'Confirmed' 
                    WHEN 3 THEN 'Awaiting Customer' 
                    WHEN 4 THEN 'Customer Replied' 
                    WHEN 5 THEN 'In Progress'
                    WHEN 6 THEN 'Completed'
                    WHEN 7 THEN 'Cancelled'
                    ELSE 'Unknown' 
                END as status_name,
                CASE so.status 
                    WHEN 1 THEN 'warning' 
                    WHEN 2 THEN 'primary' 
                    WHEN 3 THEN 'info' 
                    WHEN 4 THEN 'secondary' 
                    WHEN 5 THEN 'primary'
                    WHEN 6 THEN 'success'
                    WHEN 7 THEN 'danger'
                    ELSE 'secondary' 
                END as status_color
                FROM service_orders so
                LEFT JOIN services s ON so.service_id = s.id
                WHERE so.id = $request_id AND so.user_id = $user_id";
$request_result = mysqli_query($conn, $request_query);

// Check if service request exists and belongs to the user
if (!$request_result || mysqli_num_rows($request_result) == 0) {
    $_SESSION['error'] = "Service request not found or you don't have permission to view it.";
    header("Location: my_orders.php?tab=services");
    exit;
}

$request = mysqli_fetch_assoc($request_result);

// Get messages related to this service request if any
$messages_query = "SELECT * FROM service_messages WHERE service_order_id = $request_id ORDER BY created_at ASC";
$messages_result = mysqli_query($conn, $messages_query);
$has_messages = ($messages_result && mysqli_num_rows($messages_result) > 0);

// Handle form submission for new message
$message_sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && !empty($_POST['message'])) {
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    
    // Insert the new message
    $insert_query = "INSERT INTO service_messages (service_order_id, user_id, message, is_admin, created_at) 
                    VALUES ($request_id, $user_id, '$message', 0, NOW())";
    $insert_result = mysqli_query($conn, $insert_query);
    
    if ($insert_result) {
        // Update service order status to "Customer Replied" if it was "Awaiting Customer"
        if ($request['status'] == 3) {
            $update_query = "UPDATE service_orders SET status = 4, updated_at = NOW() WHERE id = $request_id";
            mysqli_query($conn, $update_query);
            $request['status'] = 4;
            $request['status_name'] = 'Customer Replied';
            $request['status_color'] = 'secondary';
        }
        
        $message_sent = true;
        echo "<script>window.location.href = window.location.href;</script>";
        exit;
    }
}
?>

<!-- Breadcrumb Section -->
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <h2>Service Request Details</h2>
                    <div class="breadcrumb-option">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="my_orders.php?tab=services">My Service Requests</a>
                        <span>Request #<?php echo $request['order_number']; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<!-- Service Request Details Section -->
<section class="service-details-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Service Request #<?php echo $request['order_number']; ?></h4>
                        <span class="badge bg-<?php echo $request['status_color']; ?>"><?php echo $request['status_name']; ?></span>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5>Request Information</h5>
                                <p><strong>Date Requested:</strong> <?php echo date('d M Y, h:i A', strtotime($request['created_at'])); ?></p>
                                <p><strong>Service:</strong> <?php echo htmlspecialchars($request['service_name']); ?></p>
                                <p><strong>Price:</strong> ₹<?php echo number_format($request['service_price'], 2); ?></p>
                                <p><strong>Requirements:</strong> <?php echo nl2br(htmlspecialchars($request['requirements'])); ?></p>
                                <?php if (!empty($request['deadline'])): ?>
                                <p><strong>Deadline:</strong> <?php echo date('d M Y', strtotime($request['deadline'])); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="service-image-container">
                                    <?php if (!empty($request['service_image'])): ?>
                                        <img src="<?php echo $request['service_image']; ?>" alt="<?php echo htmlspecialchars($request['service_name']); ?>" class="img-fluid rounded">
                                    <?php else: ?>
                                        <img src="assets/images/service-placeholder.jpg" alt="<?php echo htmlspecialchars($request['service_name']); ?>" class="img-fluid rounded">
                                    <?php endif; ?>
                                </div>
                                <div class="service-description mt-3">
                                    <h5>Service Description</h5>
                                    <p><?php echo nl2br(htmlspecialchars($request['service_description'])); ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Communication Section -->
                        <div class="communication-section mt-5">
                            <h5>Communication</h5>
                            
                            <?php if ($has_messages): ?>
                                <div class="messages-container p-3 bg-light rounded mb-4" style="max-height: 400px; overflow-y: auto;">
                                    <?php while ($message = mysqli_fetch_assoc($messages_result)): ?>
                                        <div class="message <?php echo $message['is_admin'] ? 'admin-message' : 'user-message'; ?> mb-3">
                                            <div class="message-content p-3 rounded <?php echo $message['is_admin'] ? 'bg-primary text-white' : 'bg-white border'; ?>">
                                                <p class="mb-1"><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                                                <small class="text-<?php echo $message['is_admin'] ? 'light' : 'muted'; ?> d-block text-end">
                                                    <?php echo date('d M Y, h:i A', strtotime($message['created_at'])); ?>
                                                </small>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <p>No messages yet. Use the form below to send a message regarding your service request.</p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($request['status'] != 6 && $request['status'] != 7): // Not completed or cancelled ?>
                                <form method="post" action="">
                                    <div class="form-group mb-3">
                                        <label for="message">Send a Message</label>
                                        <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Send Message</button>
                                </form>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mt-4">
                            <a href="my_orders.php?tab=services" class="btn btn-secondary">Back to Service Requests</a>
                            <?php if ($request['status'] == 1): // Pending ?>
                                <button class="btn btn-danger float-end delete-service-request" data-id="<?php echo $request['id']; ?>">
                                    Cancel Request
                                </button>
                            <?php endif; ?>
                            <a href="services.php" class="btn btn-primary float-end me-2">
                                Request More Services
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Scroll to bottom of messages container
    const messagesContainer = document.querySelector('.messages-container');
    if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    // Handle service request delete/cancel
    document.querySelectorAll('.delete-service-request').forEach(button => {
        button.addEventListener('click', function() {
            const requestId = this.getAttribute('data-id');
            if (confirm('Are you sure you want to cancel this service request? This action cannot be undone.')) {
                // Send AJAX request to delete the service request
                fetch('delete_service_request.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'id=' + requestId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Service request cancelled successfully.');
                        window.location.href = 'my_orders.php?tab=services';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the service request.');
                });
            }
        });
    });
});
</script>

<style>
.user-message {
    padding-right: 20%;
}
.admin-message {
    padding-left: 20%;
}
</style>

<?php
// Include footer
require_once 'includes/footer.php';
?> 