<?php
require_once 'includes/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page
    echo '<script>window.location.href = "login.php?redirect=my_orders.php";</script>';
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Invalid order ID.";
    header("Location: my_orders.php");
    exit;
}

$order_id = intval($_GET['id']);

// Get order details
$order_query = "SELECT o.*, 
                CASE o.status 
                    WHEN 1 THEN 'Pending' 
                    WHEN 2 THEN 'Processing' 
                    WHEN 3 THEN 'Shipped' 
                    WHEN 4 THEN 'Delivered' 
                    WHEN 5 THEN 'Cancelled'
                    ELSE 'Unknown' 
                END as status_name,
                CASE o.status 
                    WHEN 1 THEN 'warning' 
                    WHEN 2 THEN 'primary' 
                    WHEN 3 THEN 'info' 
                    WHEN 4 THEN 'success' 
                    WHEN 5 THEN 'danger'
                    ELSE 'secondary' 
                END as status_color
                FROM orders o
                WHERE o.id = $order_id AND o.user_id = $user_id";
$order_result = mysqli_query($conn, $order_query);

// Check if order exists and belongs to the user
if (mysqli_num_rows($order_result) == 0) {
    $_SESSION['error'] = "Order not found or you don't have permission to view it.";
    header("Location: my_orders.php");
    exit;
}

$order = mysqli_fetch_assoc($order_result);

// Get order items
$items_query = "SELECT oi.*, p.name as product_name, p.description as product_description, p.image as product_image
               FROM order_items oi
               LEFT JOIN products p ON oi.product_id = p.id
               WHERE oi.order_id = $order_id";
$items_result = mysqli_query($conn, $items_query);

// Check if order_status_history table exists
$check_history_table = mysqli_query($conn, "SHOW TABLES LIKE 'order_status_history'");
$history_table_exists = mysqli_num_rows($check_history_table) > 0;

// Get order status history if available
if ($history_table_exists) {
    $history_query = "SELECT * FROM order_status_history WHERE order_id = $order_id ORDER BY created_at DESC";
    $history_result = mysqli_query($conn, $history_query);
    $has_history = ($history_result && mysqli_num_rows($history_result) > 0);
} else {
    // Create the order_status_history table
    $create_history_table = "CREATE TABLE order_status_history (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT NOT NULL,
        status INT NOT NULL,
        comments TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    mysqli_query($conn, $create_history_table);
    $has_history = false;
    $history_result = false;
}

// Check if payments table exists
$check_payments_table = mysqli_query($conn, "SHOW TABLES LIKE 'payments'");
$payments_table_exists = mysqli_num_rows($check_payments_table) > 0;

// Get payment information if available
if ($payments_table_exists) {
    $payment_query = "SELECT * FROM payments WHERE order_id = $order_id ORDER BY payment_date DESC";
    $payment_result = mysqli_query($conn, $payment_query);
    $has_payment = ($payment_result && mysqli_num_rows($payment_result) > 0);
} else {
    // Create the payments table
    $create_payments_table = "CREATE TABLE payments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        payment_method VARCHAR(50) NOT NULL,
        transaction_id VARCHAR(100),
        payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(50) DEFAULT 'Completed'
    )";
    mysqli_query($conn, $create_payments_table);
    $has_payment = false;
    $payment_result = false;
}
?>

<!-- Breadcrumb Section -->
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <h2>Order Details</h2>
                    <div class="breadcrumb-option">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="my_orders.php">My Orders</a>
                        <span>Order #<?php echo $order['order_number']; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<!-- Order Details Section -->
<section class="order-details-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Order #<?php echo $order['order_number']; ?></h4>
                        <span class="badge bg-<?php echo $order['status_color']; ?>"><?php echo $order['status_name']; ?></span>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5>Order Information</h5>
                                <p><strong>Order Date:</strong> <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>
                                <p><strong>Order Total:</strong> ₹<?php echo number_format($order['total_amount'], 2); ?></p>
                                <?php if (!empty($order['shipping_address'])): ?>
                                <p><strong>Shipping Address:</strong> <?php echo nl2br($order['shipping_address']); ?></p>
                                <?php endif; ?>
                                <?php if (!empty($order['billing_address'])): ?>
                                <p><strong>Billing Address:</strong> <?php echo nl2br($order['billing_address']); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <h5>Payment Information</h5>
                                <?php if ($has_payment): ?>
                                    <?php $payment = mysqli_fetch_assoc($payment_result); ?>
                                    <p><strong>Payment Method:</strong> <?php echo $payment['payment_method']; ?></p>
                                    <p><strong>Payment Date:</strong> <?php echo date('d M Y', strtotime($payment['payment_date'])); ?></p>
                                    <p><strong>Transaction ID:</strong> <?php echo $payment['transaction_id']; ?></p>
                                    <p><strong>Amount Paid:</strong> ₹<?php echo number_format($payment['amount'], 2); ?></p>
                                <?php else: ?>
                                    <p>No payment information available. Please contact us for payment options.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <h5>Order Items</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th width="60">Image</th>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th class="text-end">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $subtotal = 0;
                                    while ($item = mysqli_fetch_assoc($items_result)): 
                                        $product_name = !empty($item['product_name']) ? $item['product_name'] : $item['product_name'];
                                        $item_total = $item['price'] * $item['quantity'];
                                        $subtotal += $item_total;
                                    ?>
                                    <tr>
                                        <td>
                                            <?php if (!empty($item['product_image'])): ?>
                                                <img src="<?php echo $item['product_image']; ?>" alt="<?php echo $product_name; ?>" class="img-thumbnail" width="50">
                                            <?php else: ?>
                                                <img src="assets/images/product-placeholder.jpg" alt="<?php echo $product_name; ?>" class="img-thumbnail" width="50">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div><?php echo $product_name; ?></div>
                                            <?php if (!empty($item['product_description'])): ?>
                                                <small class="text-muted"><?php echo substr($item['product_description'], 0, 100); ?><?php echo (strlen($item['product_description']) > 100) ? '...' : ''; ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                        <td><?php echo $item['quantity']; ?></td>
                                        <td class="text-end">₹<?php echo number_format($item_total, 2); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                        <td class="text-end">₹<?php echo number_format($subtotal, 2); ?></td>
                                    </tr>
                                    <?php if (!empty($order['shipping_cost'])): ?>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Shipping:</strong></td>
                                        <td class="text-end">₹<?php echo number_format($order['shipping_cost'], 2); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php if (!empty($order['tax_amount'])): ?>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Tax:</strong></td>
                                        <td class="text-end">₹<?php echo number_format($order['tax_amount'], 2); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Grand Total:</strong></td>
                                        <td class="text-end"><strong>₹<?php echo number_format($order['total_amount'], 2); ?></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                        <?php if ($has_history): ?>
                        <h5 class="mt-4">Order Status History</h5>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Comments</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($history = mysqli_fetch_assoc($history_result)): ?>
                                    <tr>
                                        <td><?php echo date('d M Y, h:i A', strtotime($history['created_at'])); ?></td>
                                        <td>
                                            <?php 
                                            $status_name = '';
                                            $status_color = '';
                                            switch ($history['status']) {
                                                case 1: $status_name = 'Pending'; $status_color = 'warning'; break;
                                                case 2: $status_name = 'Processing'; $status_color = 'primary'; break;
                                                case 3: $status_name = 'Shipped'; $status_color = 'info'; break;
                                                case 4: $status_name = 'Delivered'; $status_color = 'success'; break;
                                                case 5: $status_name = 'Cancelled'; $status_color = 'danger'; break;
                                                default: $status_name = 'Unknown'; $status_color = 'secondary'; break;
                                            }
                                            ?>
                                            <span class="badge bg-<?php echo $status_color; ?>"><?php echo $status_name; ?></span>
                                        </td>
                                        <td><?php echo $history['comments']; ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                        
                        <div class="mt-4">
                            <a href="my_orders.php" class="btn btn-secondary">Back to Orders</a>
                            <?php if ($order['status'] == 1): // Pending ?>
                                <button class="btn btn-danger float-end delete-order" data-id="<?php echo $order['id']; ?>">
                                    Cancel Order
                                </button>
                            <?php endif; ?>
                            <a href="shop.php?reorder=<?php echo $order['id']; ?>" class="btn btn-primary float-end me-2">
                                Order Again
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle order delete/cancel
    document.querySelectorAll('.delete-order').forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.getAttribute('data-id');
            if (confirm('Are you sure you want to cancel this order? This action cannot be undone.')) {
                // Send AJAX request to delete the order
                fetch('delete_order.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'id=' + orderId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Order cancelled successfully.');
                        window.location.href = 'my_orders.php';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the order.');
                });
            }
        });
    });
});
</script>

<?php
require_once 'includes/footer.php';
?> 