<?php
// Include database connection
require_once 'includes/db_connection.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize input
    if (!isset($_POST['service_order_id']) || empty($_POST['service_order_id']) || 
        !isset($_POST['message']) || empty($_POST['message'])) {
        $_SESSION['error'] = "All fields are required";
        header("Location: my_orders.php?tab=services");
        exit;
    }
    
    $service_order_id = intval($_POST['service_order_id']);
    $message = trim($_POST['message']);
    
    // Check if service order exists and belongs to the user
    $check_query = "SELECT * FROM service_orders WHERE id = $service_order_id AND user_id = $user_id";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) == 0) {
        $_SESSION['error'] = "Invalid service request";
        header("Location: my_orders.php?tab=services");
        exit;
    }
    
    // Insert message
    $message = mysqli_real_escape_string($conn, $message);
    $insert_query = "INSERT INTO service_messages (service_order_id, message, is_admin, created_at) 
                    VALUES ($service_order_id, '$message', 0, NOW())";
    
    if (mysqli_query($conn, $insert_query)) {
        // Update service order status to "Customer Replied" if currently "Awaiting Customer"
        $status_query = "SELECT status_id FROM service_orders WHERE id = $service_order_id";
        $status_result = mysqli_query($conn, $status_query);
        $current_status = mysqli_fetch_assoc($status_result)['status_id'];
        
        // Assuming status ID 3 is "Awaiting Customer" and 4 is "Customer Replied"
        if ($current_status == 3) {
            $update_query = "UPDATE service_orders SET status_id = 4 WHERE id = $service_order_id";
            mysqli_query($conn, $update_query);
        }
        
        $_SESSION['success'] = "Your message has been sent successfully";
    } else {
        $_SESSION['error'] = "Error sending message: " . mysqli_error($conn);
    }
    
    // Redirect back to service request details
    header("Location: service_request_details.php?id=$service_order_id");
    exit;
} else {
    // If not a POST request, redirect to my orders page
    header("Location: my_orders.php?tab=services");
    exit;
}
?> 